package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.keywords.NativeElementSupport;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.lang.reflect.Proxy;
import java.util.*;

public class NativeKeywordRegressionTest {
    private WebElement element(Map<String,String> attributes, String text, List<String> calls, String failedPhase) {
        return (WebElement) Proxy.newProxyInstance(WebElement.class.getClassLoader(), new Class[]{WebElement.class}, (proxy, method, args) -> {
            String name = method.getName();
            calls.add(name);
            if (name.equals(failedPhase)) throw new org.openqa.selenium.TimeoutException("remote timeout");
            if (name.equals("getAttribute")) return attributes.get(args[0]);
            if (name.equals("getText")) return text;
            return null;
        });
    }
    @Test public void iosInputUsesValueAndPreservesEmptyValue() {
        Assert.assertEquals(NativeElementSupport.text(element(Map.of("type","XCUIElementTypeTextField","value","123","label","Amount"),"Amount",new ArrayList<>(),null),true),"123");
        Assert.assertEquals(NativeElementSupport.text(element(Map.of("type","XCUIElementTypeSecureTextField","value","","label","Password"),"Password",new ArrayList<>(),null),true),"");
    }
    @Test public void nativeLabelFallbackDoesNotUseIdentifier() {
        Assert.assertEquals(NativeElementSupport.text(element(Map.of("type","XCUIElementTypeStaticText","label","Balance","name","balance_id"),"",new ArrayList<>(),null),true),"Balance");
        Assert.assertEquals(NativeElementSupport.text(element(Map.of("text","Balance"),"",new ArrayList<>(),null),false),"Balance");
    }
    @Test public void typingFocusesThenClearsThenTypesOnBothPlatforms() {
        for (boolean ios : new boolean[]{true,false}) {
            List<String> calls = new ArrayList<>();
            NativeElementSupport.replace(element(Map.of("type","XCUIElementTypeTextField"),"",calls,null),"123",ios);
            Assert.assertEquals(calls.subList(calls.size()-3,calls.size()), List.of("click","clear","sendKeys"));
        }
    }
    @Test public void clearFailureRetainsCauseAndNeverTypes() {
        List<String> calls = new ArrayList<>();
        try {
            NativeElementSupport.replace(element(Map.of(),"",calls,"clear"),"123",false);
            Assert.fail("Expected failure");
        } catch (IllegalStateException error) {
            Assert.assertTrue(error.getMessage().contains("clear"));
            Assert.assertTrue(error.getCause() instanceof org.openqa.selenium.TimeoutException);
            Assert.assertFalse(calls.contains("sendKeys"));
        }
    }
    @Test public void rejectsNonEditableIosTargetBeforeMutation() {
        List<String> calls = new ArrayList<>();
        Assert.expectThrows(IllegalStateException.class, () -> NativeElementSupport.replace(element(Map.of("type","XCUIElementTypeStaticText"),"",calls,null),"123",true));
        Assert.assertFalse(calls.contains("click"));
    }
    @Test public void supportsNativeStrategiesAndRejectsUnknownPrefixes() {
        Assert.assertEquals(((org.openqa.selenium.By.Remotable) NativeElementSupport.locator("iospredicate|type == 'XCUIElementTypeTextField'")).getRemoteParameters().using(), "-ios predicate string");
        Assert.assertEquals(((org.openqa.selenium.By.Remotable) NativeElementSupport.locator("iosclasschain|**/XCUIElementTypeButton")).getRemoteParameters().using(), "-ios class chain");
        Assert.assertEquals(((org.openqa.selenium.By.Remotable) NativeElementSupport.locator("androiduiautomator|new UiSelector().text(\"OK\")")).getRemoteParameters().using(), "-android uiautomator");
        NativeElementSupport.locator("//A | //B");
        Assert.expectThrows(IllegalArgumentException.class, () -> NativeElementSupport.locator("unknown|something"));
    }
}
