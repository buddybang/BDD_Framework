//package com.mashreq.automation.tcoe.stepdefinitions.API;
//
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.keywords.IActionLogger;
//import com.mashreq.automation.tcoe.keywords.WebAPI;
//import com.mashreq.automation.tcoe.pages.API.UserAPIPage;
//import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * Cucumber step definitions for the User API domain.
// *
// * Wiring:  ScenarioContext  →  WebAPI  →  UserAPIPage  →  step methods
// * All HTTP interactions are delegated to UserAPIPage; this class contains
// * only glue code — no assertions or RestAssured calls directly.
// */
//public class UserAPISteps {
//
//    private final ScenarioContext ctx;
//    private final UserAPIPage userAPIPage;
//
//    // ---------------------------------------------------------------
//    // CONSTRUCTION
//    // ---------------------------------------------------------------
//
//    /**
//     * Cucumber PicoContainer injects ScenarioContext automatically.
//     * WebAPI and UserAPIPage are wired here so they share the same context
//     * and logger for the lifetime of the scenario.
//     *
//     * FIX: UserAPIPage constructor now receives (ctx, logger, webAPI) as required
//     *      by BaseAPIPage — the old code only passed webAPI, breaking the super() call.
//     */
//    public UserAPISteps(ScenarioContext ctx) {
//        this.ctx = ctx;
//        IActionLogger logger = new FeatureStepCollector();
//        WebAPI webAPI = new WebAPI(ctx, logger);
//        this.userAPIPage = new UserAPIPage(ctx, logger, webAPI);
//    }
//
//    // ---------------------------------------------------------------
//    // SETUP
//    // ---------------------------------------------------------------
//
//    /**
//     * Initialises the session with an Authorization header.
//     * Content-Type is already set internally by WebAPI — only auth-specific
//     * headers belong here.
//     */
//    @Given("the User API is initialized")
//    public void initUserApi() {
//        userAPIPage.setAuthHeader(ctx.getAuthToken());
//    }
//
//    // ---------------------------------------------------------------
//    // HTTP ACTION STEPS
//    // ---------------------------------------------------------------
//
//    /**
//     * Sends a GET request to the given endpoint.
//     */
//    @When("I send a GET request to {string}")
//    public void sendGetRequest(String endpoint) {
//        userAPIPage.getUser(endpoint);
//    }
//
//    /**
//     * Sends a POST request with a name/job body to the given endpoint.
//     */
//    @When("I send a POST request to {string} with name {string} and job {string}")
//    public void sendPostRequest(String endpoint, String name, String job) {
//        Map<String, String> body = new HashMap<>();
//        body.put("name", name);
//        body.put("job", job);
//        userAPIPage.createUser(endpoint, body);
//    }
//
//    /**
//     * Sends a PUT request with a name/job body to the given endpoint.
//     *
//     * FIX: old code called userAPIPage.put() which does not exist on UserAPIPage.
//     *      Correct method is userAPIPage.updateUser().
//     */
//    @When("I send a PUT request to {string} with name {string} and job {string}")
//    public void sendPutRequest(String endpoint, String name, String job) {
//        Map<String, String> body = new HashMap<>();
//        body.put("name", name);
//        body.put("job", job);
//        userAPIPage.updateUser(endpoint, body);
//    }
//
//    /**
//     * Sends a DELETE request to the given endpoint.
//     *
//     * FIX: old code called userAPIPage.delete() which does not exist on UserAPIPage.
//     *      Correct method is userAPIPage.deleteUser().
//     */
//    @When("I send a DELETE request to {string}")
//    public void sendDeleteRequest(String endpoint) {
//        userAPIPage.deleteUser(endpoint);
//    }
//
//    // ---------------------------------------------------------------
//    // VALIDATION STEPS
//    // ---------------------------------------------------------------
//
//    /**
//     * Asserts the HTTP status code of the last response.
//     *
//     * FIX: duplicate step definitions — @Then("the API status code should be {int}")
//     *      and @Then("the response status code should be {int}") both called
//     *      validateStatus/verifyStatusCode. Merged into one canonical step.
//     *      Update .feature files to use this form.
//     *
//     * FIX: old code called userAPIPage.validateStatus() — method was renamed
//     *      to validateStatusCode() in the fixed UserAPIPage.
//     */
//    @Then("the response status code should be {int}")
//    public void verifyStatusCode(int expectedCode) {
//        userAPIPage.validateStatusCode(expectedCode);
//    }
//
//    /**
//     * Asserts the value of a JSON field in the last response.
//     *
//     * FIX: old code called userAPIPage.verifyResponseField() which never existed.
//     *      Correct method is userAPIPage.validateField().
//     */
//    @Then("the response field {string} should be {string}")
//    public void verifyResponseField(String jsonPath, String expectedValue) {
//        userAPIPage.validateField(jsonPath, expectedValue);
//    }
//
//    /**
//     * Asserts that a JSON field in the last response is not null or empty.
//     */
//    @Then("the response field {string} should not be empty")
//    public void verifyResponseFieldNotEmpty(String jsonPath) {
//        userAPIPage.validateFieldNotEmpty(jsonPath);
//    }
//}