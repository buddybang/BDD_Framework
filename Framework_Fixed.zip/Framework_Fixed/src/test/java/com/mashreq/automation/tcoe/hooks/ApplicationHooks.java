//
//package com.mashreq.automation.tcoe.hooks;
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
//import com.mashreq.automation.tcoe.driver.MobileDriverManager;
//import com.mashreq.automation.tcoe.users.UserCredentialsManager;
//import com.mashreq.automation.tcoe.users.UserPair;
//import com.mashreq.automation.tcoe.utils.*;
//import com.mashreq.automation.tcoe.driver.DriverManager;
//import com.microsoft.playwright.Page;
//import com.mongodb.MapReduceCommand;
//import io.appium.java_client.AppiumDriver;
//import io.cucumber.java.*;
//import org.apache.commons.io.FileUtils;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//
//import java.io.File;
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.text.SimpleDateFormat;
//import java.time.Duration;
//import java.time.Instant;
//import java.util.Collection;
//import java.util.Date;
//import java.util.concurrent.atomic.AtomicInteger;
//
//
//public class ApplicationHooks {
//
//    private final ScenarioContext ctx; // Pico injects per-scenario
//    private Instant scenarioStartTime;
//    private static Instant suiteStartTime; //Parallel Time Fix
//
//
//    // Thread-safe scenario counter
//    private static AtomicInteger scenarioCounter = new AtomicInteger(0);
//
//    public ApplicationHooks(ScenarioContext ctx) {
//        this.ctx = ctx;
//    }
//
//    @BeforeAll
//    public static void beforeAll() throws IOException {
//        ReportUtils.backupReportsAndLogsDirectories();
//        suiteStartTime = Instant.now(); //Parallel Time Fix
//    }
//
//    //    @Before
////    public void setup(Scenario scenario) {
////        // CHECKOUT USER FIRST
////        UserPair userPair = UserCredentialsManager.getInstance().checkoutUserPair();
////        ctx.setUserPair(userPair);
////
////        ScenarioContext.set(ctx);
////        String caseId = ScenarioContext.consumePendingCaseId();
////        ctx.setTestCaseId(caseId);
////
////        String rawName = scenario.getName();
////        String[] parts = rawName.split("\\|");
////
////        if (parts.length >= 3) {
////            String module = parts[0].trim();
////            String scnId  = parts[1].trim();
////            String description = parts[2].trim();
////
////            ctx.setCurrentModule(module);
////            ctx.setScenarioId(scnId);
////
////
////            // ======================= LOG FILENAME LOGIC =======================
////            StringBuilder fileNameBuilder = new StringBuilder();
////            fileNameBuilder.append(module).append("_").append(scnId);
////
////            String currentTestCaseId = ctx.getTestCaseId();
////            if (currentTestCaseId != null && !currentTestCaseId.trim().isEmpty()) {
////                fileNameBuilder.append("_").append(currentTestCaseId);
////            }
////
////            String sanitizedFileName = fileNameBuilder.toString().replaceAll("[^a-zA-Z0-9_]", "_");
////            String threadContextName = module + "_" + scnId; // For cleaner console logs
////
////            LogUtils.startScenario(threadContextName, "Log_" + sanitizedFileName);
////
////            // Build the entire log block into a single string before printing.
////            StringBuilder scenarioStartLog = new StringBuilder();
////            scenarioStartLog.append("\n-----------------------------------------------------------------\n");
////            scenarioStartLog.append("SCENARIO STARTED\n");
////            scenarioStartLog.append(String.format("  - Module:         %s\n", module));
////            scenarioStartLog.append(String.format("  - Scenario ID:    %s\n", scnId));
////            scenarioStartLog.append(String.format("  - Description:    %s\n", description));
////            scenarioStartLog.append(String.format("  - User Pair ID:   %s\n", userPair.getPairId()));
////            scenarioStartLog.append(String.format("  - Tags:           %s\n", String.join(", ", scenario.getSourceTagNames())));
////            scenarioStartLog.append("-----------------------------------------------------------------");
////
////            // Make a single, atomic call to the logger.
////            LogUtils.info(scenarioStartLog.toString());
////
////        } else {
////            // Fallback for scenarios that don't follow the naming convention.
////            String logFileName = rawName.replaceAll("[^a-zA-Z0-9_]", "_");
////            LogUtils.startScenario(logFileName, "Log_" + logFileName);
////
////            StringBuilder scenarioStartLog = new StringBuilder();
////            scenarioStartLog.append("\n-----------------------------------------------------------------\n");
////            scenarioStartLog.append("SCENARIO STARTED: ").append(logFileName).append("\n");
////            scenarioStartLog.append(String.format("  - User Pair ID:   %s\n", userPair.getPairId()));
////            scenarioStartLog.append("  - Tags: ").append(String.join(", ", scenario.getSourceTagNames())).append("\n");
////            scenarioStartLog.append("-----------------------------------------------------------------");
////            LogUtils.info(scenarioStartLog.toString());
////        }
////    // ── Driver init — routed by scenario tag ────────────────────────
////        Collection<String> tags = scenario.getSourceTagNames();
////
////        if (tags.contains("@Mobile")) {
////            MobileDriverManager.initDriver();
////            ctx.setMobileDriver(MobileDriverManager.getDriver());
////            LogUtils.info("Mobile Driver started: " + MobileDriverManager.getDeviceDetails());
////
////        } else if (tags.contains("@API")) {
////            LogUtils.info("API scenario — no UI driver initialised.");
////
////        } else {
////            // Default: Web (Playwright)
////            DriverManager.initDriver();
////            Page page = DriverManager.getPage();
////            ctx.setPage(page);
////            LogUtils.info("Web Driver started: " + DriverManager.getBrowserVersion());
////        }
////        // ────────────────────────────────────────────────────────────────
////
////    }
//    @Before
//    public void setup(Scenario scenario) {
//
//        // START TIME
//        scenarioStartTime = Instant.now();
//
//        // CHECKOUT USER FIRST
//        UserPair userPair = UserCredentialsManager.getInstance().checkoutUserPair();
//        ctx.setUserPair(userPair);
//
//        ScenarioContext.set(ctx);
//
//        String caseId = ScenarioContext.consumePendingCaseId();
//        ctx.setTestCaseId(caseId);
//
//        String rawName = scenario.getName();
//
//        String[] parts = rawName.split("\\|");
//
//        if (parts.length >= 3) {
//
//            String module = parts[0].trim();
//            String scnId = parts[1].trim();
//            String description = parts[2].trim();
//
//            ctx.setCurrentModule(module);
//            ctx.setScenarioId(scnId);
//
//            StringBuilder fileNameBuilder = new StringBuilder();
//
//            fileNameBuilder.append(module)
//                    .append("_")
//                    .append(scnId);
//
//            String currentTestCaseId = ctx.getTestCaseId();
//
//            if (currentTestCaseId != null
//                    && !currentTestCaseId.trim().isEmpty()) {
//
//                fileNameBuilder.append("_")
//                        .append(currentTestCaseId);
//            }
//
//            String sanitizedFileName =
//                    fileNameBuilder.toString()
//                            .replaceAll("[^a-zA-Z0-9-_]", "_");
//
//            String threadContextName =
//                    module + "_" + scnId;
//
//            LogUtils.startScenario(
//                    threadContextName,
//                    "Log_" + sanitizedFileName
//            );
//
//            StringBuilder scenarioStartLog =
//                    new StringBuilder();
//
//            scenarioStartLog.append("\n-----------------------------------------------------------------\n");
//            scenarioStartLog.append("SCENARIO STARTED\n");
//            scenarioStartLog.append(String.format("  - Module:         %s\n", module));
//            scenarioStartLog.append(String.format("  - Scenario ID:    %s\n", scnId));
//            scenarioStartLog.append(String.format("  - Description:    %s\n", description));
//            scenarioStartLog.append(String.format("  - User Pair ID:   %s\n", userPair.getPairId()));
//            scenarioStartLog.append(String.format("  - Tags:           %s\n",
//                    String.join(", ", scenario.getSourceTagNames())));
//            scenarioStartLog.append("-----------------------------------------------------------------");
//
//            LogUtils.info(scenarioStartLog.toString());
//
//        } else {
//
//            String logFileName =
//                    rawName.replaceAll("[^a-zA-Z0-9-_]", "_");
//
//            LogUtils.startScenario(
//                    logFileName,
//                    "Log_" + logFileName
//            );
//
//            StringBuilder scenarioStartLog =
//                    new StringBuilder();
//
//            scenarioStartLog.append("\n-----------------------------------------------------------------\n");
//            scenarioStartLog.append("SCENARIO STARTED: ")
//                    .append(logFileName)
//                    .append("\n");
//
//            scenarioStartLog.append(String.format(
//                    "  - User Pair ID:   %s\n",
//                    userPair.getPairId()
//            ));
//
//            scenarioStartLog.append("  - Tags: ")
//                    .append(String.join(", ",
//                            scenario.getSourceTagNames()))
//                    .append("\n");
//
//            scenarioStartLog.append("-----------------------------------------------------------------");
//
//            LogUtils.info(scenarioStartLog.toString());
//        }
//
//        Collection<String> tags =
//                scenario.getSourceTagNames();
//
//        if (tags.contains("@Mobile")) {
//
//            MobileDriverManager.initDriver();
//
//            ctx.setMobileDriver(
//                    MobileDriverManager.getDriver()
//            );
//
//            LogUtils.info(
//                    "Mobile Driver started: "
//                            + MobileDriverManager.getDeviceDetails()
//            );
//
//        } else if (tags.contains("@API")) {
//
//            LogUtils.info(
//                    "API scenario — no UI driver initialised."
//            );
//
//        } else {
//
//            DriverManager.initDriver();
//
//            Page page = DriverManager.getPage();
//
//            ctx.setPage(page);
//
//            LogUtils.info(
//                    "Web Driver started: "
//                            + DriverManager.getBrowserVersion()
//            );
//        }
//    }
//
////    @AfterStep
////    public void afterStep(Scenario scenario) {
////        takeScreenshot(ctx.getScenarioId());
////    }
//
//    @AfterStep
//    public void afterStep(Scenario scenario) {
//
////        String screenshotPath =
////                takeScreenshot(ctx.getScenarioId());
////
////        ScreenshotContextHolder
////                .publishLastScreenshotPath(screenshotPath);
//    }
//
//    @After
//    public void afterScenario(Scenario scenario) {
//        UserPair userPairToCheckin = null; // Hold the user pair to be checked in.
////        Path finalVideo = null;
//        try {
//            Instant scenarioEndTime = Instant.now();
//            Duration scenarioDuration = Duration.between(scenarioStartTime, scenarioEndTime);
//
//            if (scenario.isFailed()) {
//                takeScreenshot(ctx.getScenarioId());
//            }
//
////            Path finalVideo = DriverManager.closeDriver(ctx.getScenarioId());
////            if (finalVideo != null) {
////                FeatureStepCollector.setVideoPath(finalVideo.toString());
////            }
////
////            StringBuilder scenarioEndLog = new StringBuilder();
////            scenarioEndLog.append("\n-----------------------------------------------------------------\n");
////            scenarioEndLog.append("SCENARIO FINISHED\n");
////
////            // Get the user pair to log its ID before it's checked in.
////            userPairToCheckin = ctx.getUserPair();
////            if (userPairToCheckin != null) {
////                scenarioEndLog.append(String.format("  - User Pair ID:   %s (returned to pool)\n", userPairToCheckin.getPairId()));
////            }
////
////            scenarioEndLog.append("  - Name:           ").append(scenario.getName()).append("\n");
////            scenarioEndLog.append("  - Status:         ").append(scenario.getStatus()).append("\n");
////            scenarioEndLog.append(String.format("  - Duration:       %d seconds (%d ms)\n", scenarioDuration.toSeconds(), scenarioDuration.toMillis()));
////            scenarioEndLog.append("-----------------------------------------------------------------\n");
////
////            LogUtils.info(scenarioEndLog.toString());
////
//        } finally {
//            // This code will run ALWAYS, even if closeDriver() or logging fails.
//            // ── Driver teardown — always runs, prevents resource leaks ────
//            try {
//                Collection<String> tags = scenario.getSourceTagNames();
//                Path finalVideo = null;
//                if (tags.contains("@Mobile")) {
//                    finalVideo = MobileDriverManager.quitDriver();
//                } else if (!tags.contains("@API")) {
//                    finalVideo = DriverManager.closeDriver(ctx.getScenarioId());
//                }
//                if (finalVideo != null) {
//                    FeatureStepCollector.setVideoPath(finalVideo.toString());
//                }
//            } catch (Exception driverEx) {
//                LogUtils.warn("Driver teardown failed (non-fatal): " + driverEx.getMessage());
//            }
//            // ─────────────────────────────────────────────────────────────
//            // Check in the user pair. This is the most critical step.
//            if (userPairToCheckin != null) {
//                UserCredentialsManager.getInstance().checkinUserPair(userPairToCheckin);
//            } else {
//                // Fallback in case the user pair was not retrieved in the try block
//                UserPair finalUserPair = ctx.getUserPair();
//                if (finalUserPair != null) {
//                    UserCredentialsManager.getInstance().checkinUserPair(finalUserPair);
//                }
//            }
//
//            // Clear the scenario context for the next test on this thread.
//            ScenarioContext.clear();
//            LogUtils.endScenario();
//            scenarioCounter.incrementAndGet();
//        }
//
//    }
//
//
//    @AfterAll
//    public static void afterAll() {
//        // --- Parallel Time Fix: Calculate the total wall-clock duration of the suite ---
//        Instant suiteEndTime = Instant.now();
//        long suiteDurationMillis = 0;
//        if (suiteStartTime != null) {
//            suiteDurationMillis = Duration.between(suiteStartTime, suiteEndTime).toMillis();
//        }
//        // Use a final variable so it can be accessed in the aggregator call
//        final long finalSuiteDuration = suiteDurationMillis;
//        LogUtils.info(String.format("Total Suite Wall-Clock Duration: %d seconds.", Duration.ofMillis(finalSuiteDuration).toSeconds()));
//        // --- END Parallel Time Fix ---
//        LogUtils.info("Waiting for all scenario JSON files to be saved...");
//
//        String aggregatorDirPath = FeatureAggregator.getScenarioDir();
//        File aggregatorDir = new File(aggregatorDirPath);
//        int expectedCount = scenarioCounter.get();
//
//        // Give the file system a brief, initial moment to settle down.
//        try {
//            Thread.sleep(2000); // Start with a 2-second grace period.
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//
//        int attempts = 0;
//        final int MAX_ATTEMPTS = 30; // Wait for a maximum of 30 seconds.
//
//        while (attempts < MAX_ATTEMPTS) {
//            if (!aggregatorDir.exists()) {
//                LogUtils.warn("Scenario directory does not exist yet. Waiting...");
//                sleepForOneSecond();
//                attempts++;
//                continue;
//            }
//
//            File[] files = aggregatorDir.listFiles(f -> f.getName().endsWith(".js"));
//
//            if (files != null && files.length >= expectedCount) {
//                // Now, check if all found files are non-empty. This is the crucial new step.
//                boolean allFilesHaveContent = true;
//                for (File file : files) {
//                    if (file.length() == 0) {
//                        allFilesHaveContent = false;
//                        break; // Found an empty file, so we need to wait longer.
//                    }
//                }
//
//                if (allFilesHaveContent) {
//                    LogUtils.info("All " + files.length + " scenario files appear to be ready.");
//                    break; // Success! Exit the loop.
//                }
//            }
//
//            // If we're here, either not enough files or some are empty. Wait and retry.
//            LogUtils.info("Waiting for scenario files... Found " + (files != null ? files.length : 0) + "/" + expectedCount);
//            sleepForOneSecond();
//            attempts++;
//        }
//
//        if (attempts >= MAX_ATTEMPTS) {
//            LogUtils.warn("Timeout waiting for all scenario JSON files to be completely written. Aggregator may miss some data.");
//        }
//
//        LogUtils.info("Generating aggregated reports...");
//        String buildNumber = System.getenv("Build.BuildId");
//
//        if (buildNumber == null || buildNumber.isEmpty()) {
//            buildNumber = "local_" + java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
//                    .format(java.time.LocalDateTime.now());
//        }
//
//        LogUtils.info("BuildNumber:" + buildNumber);
//        FeatureAggregator.generateReports(buildNumber, finalSuiteDuration);
//        LogUtils.info("Aggregated reports generation completed.");
//    }
//
//    // Helper method to avoid repeating the try-catch block
//    private static void sleepForOneSecond() {
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            Thread.currentThread().interrupt();
//        }
//    }
//
//    //    /**
////     * Takes a screenshot and attaches it to the Allure report.
////     * This method is designed to be resilient and will not fail the test
////     * if a screenshot cannot be taken (e.g., if the browser is already closed).
////     *
////     * @param scenario       The current Cucumber scenario.
////     * @param screenshotName The name for the screenshot attachment.
////     * @return
////     */
//    public static String takeScreenshot(String scenarioId) {
//
//        try {
//
//            // =====================================================
//            // SAFE STEP / ACTION NUMBER
//            // =====================================================
//
//            Integer step = ScreenshotContextHolder.getStepNo();
//            Integer action = ScreenshotContextHolder.getActionNo();
//
//            step = (step == null) ? 1 : step;
//            action = (action == null) ? 1 : action;
//
//            // =====================================================
//            // PROJECT ROOT
//            // =====================================================
//
//            Path projectRoot = Paths.get(
//                    System.getProperty("user.dir")
//            ).toAbsolutePath();
//
//            // =====================================================
//            // REPORTS ROOT
//            // =====================================================
//
//            Path reportsRoot = projectRoot
//                    .resolve("reports")
//                    .resolve("latest")
//                    .resolve("custom-report");
//
//            // =====================================================
//            // SCREENSHOT DIRECTORY
//            // =====================================================
//
//            Path screenshotsDir = reportsRoot
//                    .resolve("screenshots")
//                    .resolve(scenarioId);
//
//            Files.createDirectories(screenshotsDir);
//
//            // =====================================================
//            // SAFE SCENARIO NAME
//            // =====================================================
//
//            String safeScenarioId =
//                    (scenarioId == null || scenarioId.isBlank())
//                            ? "scenario"
//                            : scenarioId.replaceAll(
//                            "[^a-zA-Z0-9._-]",
//                            "_"
//                    );
//
//            // =====================================================
//            // FILE NAME
//            // =====================================================
//
//            long currentTimeMillis = System.currentTimeMillis();
//
//            String fileName = String.format(
//                    "%s_%d_%d_%d.png",
//                    safeScenarioId,
//                    step,
//                    action,
//                    currentTimeMillis
//            );
//
//            Path destinationPath =
//                    screenshotsDir.resolve(fileName);
//
//            // =====================================================
//            // MOBILE SCREENSHOT
//            // =====================================================
//
//            AppiumDriver mobileDriver =
//                    MobileDriverManager.getDriver();
//
//            if (mobileDriver != null) {
//
//                File srcFile =
//                        ((TakesScreenshot) mobileDriver)
//                                .getScreenshotAs(OutputType.FILE);
//
//                FileUtils.copyFile(
//                        srcFile,
//                        destinationPath.toFile()
//                );
//
//                Path relativePath =
//                        projectRoot.relativize(
//                                destinationPath.toAbsolutePath()
//                        );
//
//                String finalPath =
//                        "./" + relativePath.toString()
//                                .replace("\\", "/");
//
//// IMPORTANT
//
//
//                LogUtils.info(
//                        "Mobile screenshot captured: "
//                                + finalPath
//                );
//
//                return finalPath;
//            }
//
//            // =====================================================
//            // WEB SCREENSHOT
//            // =====================================================
//
//            Page page = DriverManager.getPage();
//
//            if (page != null && !page.isClosed()) {
//
//                page.screenshot(
//                        new Page.ScreenshotOptions()
//                                .setPath(destinationPath)
//                                .setFullPage(true)
//                );
//
//                Path relativePath =
//                        projectRoot.relativize(
//                                destinationPath.toAbsolutePath()
//                        );
//
//                String finalPath =
//                        "./" + relativePath.toString()
//                                .replace("\\", "/");
//
//                // VERY IMPORTANT
//                ScreenshotContextHolder
//                        .publishLastScreenshotPath(finalPath);
//
//                LogUtils.info(
//                        "Web screenshot captured: "
//                                + finalPath
//                );
//
//                return finalPath;
//            }
//
//            LogUtils.warn(
//                    "No active Web or Mobile driver found."
//            );
//
//            return "";
//
//        } catch (Exception e) {
//
//            LogUtils.error(
//                    "Exception while taking screenshot: "
//                            + e.getMessage(),
//                    e
//            );
//
//            return "";
//        }
//    }
//
//
////    public static String takeScreenshot(
////            Scenario scenario,
////            String screenshotName
////    ) {
////
////        try {
////
////            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS")
////                    .format(new Date());
////
////            String fileName = screenshotName.replaceAll("\\s+", "_")
////                    + "_" + timestamp + ".png";
////
////            String screenshotDir = System.getProperty("user.dir")
////                    + "/reports/latest/custom-report/screenshots/";
////
////            File dir = new File(screenshotDir);
////
////            if (!dir.exists()) {
////                dir.mkdirs();
////            }
////
////            String fullPath = screenshotDir + fileName;
////
////            // ================= MOBILE =================
////
////            AppiumDriver mobileDriver = MobileDriverManager.getDriver();
////
////            if (mobileDriver != null) {
////
////                File src = ((TakesScreenshot) mobileDriver)
////                        .getScreenshotAs(OutputType.FILE);
////
////                File dest = new File(fullPath);
////
////                FileUtils.copyFile(src, dest);
////
////                byte[] screenshotBytes = FileUtils.readFileToByteArray(dest);
////
////                scenario.attach(screenshotBytes, "image/png", screenshotName);
////
////                LogUtils.info("Mobile screenshot captured: " + fullPath);
////
////                // IMPORTANT
////                FeatureStepCollector.addScreenshot(fullPath);
////
////                return fullPath;
////            }
////
////            // ================= WEB =================
////
////            Page page = DriverManager.getPage();
////
////            if (page == null || page.isClosed()) {
////
////                LogUtils.warn(
////                        "Could not take screenshot. Page was null or already closed."
////                );
////
////                return null;
////            }
////
////            page.screenshot(
////                    new Page.ScreenshotOptions()
////                            .setFullPage(true)
////                            .setPath(Path.of(fullPath))
////            );
////
////            byte[] screenshotBytes = java.nio.file.Files.readAllBytes(
////                    Path.of(fullPath)
////            );
////
////            scenario.attach(screenshotBytes, "image/png", screenshotName);
////
////            LogUtils.info("Web screenshot captured: " + fullPath);
////
////            // IMPORTANT
////            FeatureStepCollector.addScreenshot(fullPath);
////
////            return fullPath;
////
////        } catch (Exception e) {
////
////            LogUtils.error(
////                    "Exception occurred while taking screenshot: "
////                            + e.getMessage()
////            );
////
////            return null;
////        }
////    }
//
//
//}
//
//
//

package com.mashreq.automation.tcoe.hooks;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.driver.DriverManager;
import com.mashreq.automation.tcoe.driver.MobileDriverManager;
import com.mashreq.automation.tcoe.users.UserCredentialsManager;
import com.mashreq.automation.tcoe.users.UserPair;
import com.mashreq.automation.tcoe.utils.FeatureAggregator;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.CaptureHelpers;
import com.mashreq.automation.tcoe.utils.MobileFailureSupport;
import com.mashreq.automation.tcoe.utils.SafeDiagnostics;
import com.mashreq.automation.tcoe.utils.ReportUtils;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

public class ApplicationHooks {

    private final ScenarioContext ctx;

    private Instant scenarioStartTime;

    private static Instant suiteStartTime;

    // Thread-safe scenario counter
    private static final AtomicInteger scenarioCounter =
            new AtomicInteger(0);

    public ApplicationHooks(ScenarioContext ctx) {
        this.ctx = ctx;
    }

    // ================================================================
    // BEFORE ALL
    // ================================================================

    @BeforeAll
    public static void beforeAll() throws IOException {

        ReportUtils.backupReportsAndLogsDirectories();

        suiteStartTime = Instant.now();
    }

    // ================================================================
    // BEFORE SCENARIO
    // ================================================================

    @Before
    public void setup(Scenario scenario) {

        // ============================================================
        // START TIME
        // ============================================================

        scenarioStartTime = Instant.now();

        // ============================================================
        // CHECKOUT USER FIRST
        // ============================================================

        // Maker/checker pairs are only used by web (Flexcube) scenarios. Mobile and API
        // scenarios skip the pool, so they never queue behind web tests and can run in
        // parallel on BrowserStack.
        Collection<String> scenarioTags =
                scenario.getSourceTagNames();
        ctx.setMobileScenario(scenarioTags.contains("@Mobile"));

        boolean needsUserPair =
                !scenarioTags.contains("@Mobile")
                        && !scenarioTags.contains("@API");

        UserPair userPair = null;

        if (needsUserPair) {

            userPair =
                    UserCredentialsManager
                            .getInstance()
                            .checkoutUserPair();
        }

        final String userPairId =
                userPair != null
                        ? userPair.getPairId()
                        : "n/a (not required)";

        ctx.setUserPair(userPair);

        ScenarioContext.set(ctx);

        // ============================================================
        // TEST CASE ID
        // ============================================================

        String caseId =
                ScenarioContext.consumePendingCaseId();

        ctx.setTestCaseId(caseId);

        // ============================================================
        // SCENARIO NAME
        // ============================================================

        String rawName =
                scenario.getName();

        String[] parts =
                rawName.split("\\|");

        if (parts.length >= 3) {

            String module =
                    parts[0].trim();

            String scnId =
                    parts[1].trim();

            String description =
                    parts[2].trim();

            ctx.setCurrentModule(module);
            ctx.setScenarioId(scnId);

            StringBuilder fileNameBuilder =
                    new StringBuilder();

            fileNameBuilder
                    .append(module)
                    .append("_")
                    .append(scnId);

            String currentTestCaseId =
                    ctx.getTestCaseId();

            if (currentTestCaseId != null
                    && !currentTestCaseId.trim().isEmpty()) {

                fileNameBuilder
                        .append("_")
                        .append(currentTestCaseId);
            }

            String sanitizedFileName =
                    fileNameBuilder
                            .toString()
                            .replaceAll(
                                    "[^a-zA-Z0-9-_]",
                                    "_"
                            );

            String threadContextName =
                    module + "_" + scnId;

            LogUtils.startScenario(
                    threadContextName,
                    "Log_" + sanitizedFileName
            );

            StringBuilder scenarioStartLog =
                    new StringBuilder();

            scenarioStartLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioStartLog.append(
                    "SCENARIO STARTED\n"
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Module:         %s\n",
                            module
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Scenario ID:    %s\n",
                            scnId
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Description:    %s\n",
                            description
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - User Pair ID:   %s\n",
                            userPairId
                    )
            );

            scenarioStartLog.append(
                    String.format(
                            "  - Tags:           %s\n",
                            String.join(
                                    ", ",
                                    scenario.getSourceTagNames()
                            )
                    )
            );

            scenarioStartLog.append(
                    "-----------------------------------------------------------------"
            );

            LogUtils.info(
                    scenarioStartLog.toString()
            );

        } else {

            String logFileName =
                    rawName.replaceAll(
                            "[^a-zA-Z0-9-_]",
                            "_"
                    );

            LogUtils.startScenario(
                    logFileName,
                    "Log_" + logFileName
            );

            StringBuilder scenarioStartLog =
                    new StringBuilder();

            scenarioStartLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioStartLog.append(
                    "SCENARIO STARTED: "
            );

            scenarioStartLog
                    .append(logFileName)
                    .append("\n");

            scenarioStartLog.append(
                    String.format(
                            "  - User Pair ID:   %s\n",
                            userPairId
                    )
            );

            scenarioStartLog.append(
                    "  - Tags: "
            );

            scenarioStartLog
                    .append(
                            String.join(
                                    ", ",
                                    scenario.getSourceTagNames()
                            )
                    )
                    .append("\n");

            scenarioStartLog.append(
                    "-----------------------------------------------------------------"
            );

            LogUtils.info(
                    scenarioStartLog.toString()
            );
        }

        // ============================================================
        // DRIVER INITIALIZATION
        // ============================================================

        Collection<String> tags =
                scenario.getSourceTagNames();

        if (tags.contains("@Mobile")) {

            MobileDriverManager.initDriver();

            ctx.setMobileDriver(
                    MobileDriverManager.getDriver()
            );

            LogUtils.info(
                    "Mobile Driver started: "
                            + MobileDriverManager.getDeviceDetails()
            );

        } else if (tags.contains("@API")) {

            LogUtils.info(
                    "API scenario — no UI driver initialised."
            );

        } else {

            DriverManager.initDriver();

            Page page =
                    DriverManager.getPage();

            ctx.setPage(page);

            LogUtils.info(
                    "Web Driver started: "
                            + DriverManager.getBrowserVersion()
            );
        }
    }

    // ================================================================
    // AFTER STEP
    // ================================================================

    @AfterStep
    public void afterStep(Scenario scenario) {

        // Intentionally empty.
        //
        // Screenshot handling is performed from afterScenario()
        // when the scenario has failed.
    }

    // ================================================================
    // AFTER SCENARIO
    // ================================================================

    @After
    public void afterScenario(Scenario scenario) {

        UserPair userPairToCheckin = null;

        try {

            // ========================================================
            // SCENARIO DURATION
            // ========================================================

            Instant scenarioEndTime =
                    Instant.now();

            Duration scenarioDuration =
                    Duration.between(
                            scenarioStartTime,
                            scenarioEndTime
                    );

            // ========================================================
            // FAILURE SCREENSHOT
            // ========================================================

            if (scenario.isFailed()) {

                String failurePath = ctx.isMobileScenario()
                        ? MobileFailureSupport.captureFailure(ctx) : takeScreenshot(ctx.getScenarioId());
                if (!failurePath.isBlank()) {
                    ScreenshotContextHolder.publishLastScreenshotPath(failurePath);
                    com.mashreq.automation.tcoe.utils.FeatureStepCollector.attachScreenshotToLastAction(failurePath);
                }
            }

            // ========================================================
            // SCENARIO END LOG
            // ========================================================

            StringBuilder scenarioEndLog =
                    new StringBuilder();

            scenarioEndLog.append(
                    "\n-----------------------------------------------------------------\n"
            );

            scenarioEndLog.append(
                    "SCENARIO FINISHED\n"
            );

            // ========================================================
            // USER PAIR
            // ========================================================

            userPairToCheckin =
                    ctx.getUserPair();

            if (userPairToCheckin != null) {

                scenarioEndLog.append(
                        String.format(
                                "  - User Pair ID:   %s (returned to pool)\n",
                                userPairToCheckin.getPairId()
                        )
                );
            }

            // ========================================================
            // SCENARIO INFORMATION
            // ========================================================

            scenarioEndLog.append(
                    "  - Name:           "
            );

            scenarioEndLog
                    .append(scenario.getName())
                    .append("\n");

            scenarioEndLog.append(
                    "  - Status:         "
            );

            scenarioEndLog
                    .append(scenario.getStatus())
                    .append("\n");

            scenarioEndLog.append(
                    String.format(
                            "  - Duration:       %d seconds (%d ms)\n",
                            scenarioDuration.toSeconds(),
                            scenarioDuration.toMillis()
                    )
            );

            scenarioEndLog.append(
                    "-----------------------------------------------------------------\n"
            );

            LogUtils.info(
                    scenarioEndLog.toString()
            );

        } catch (Exception e) {

            /*
             * Do not allow logging/screenshot problems to prevent
             * driver teardown and user check-in.
             */
            LogUtils.warn(
                    "Error while processing scenario completion: "
                            + e.getMessage()
            );

        } finally {

            // ========================================================
            // DRIVER TEARDOWN
            // ========================================================

            try {

                Collection<String> tags =
                        scenario.getSourceTagNames();

                if (tags.contains("@Mobile")) {

                    /*
                     * MobileDriverManager.quitDriver()
                     * only quits the Appium driver.
                     *
                     * No video processing is performed.
                     */
                    MobileDriverManager.quitDriver(
                            scenario.getStatus() == io.cucumber.java.Status.PASSED,
                            scenario.isFailed()
                                    ? "Failed: " + scenario.getName()
                                    : "Passed: " + scenario.getName()
                    );

                    // The manager logs skipped, successful and failed quit outcomes separately.

                } else if (!tags.contains("@API")) {

                    /*
                     * Web driver cleanup.
                     */
                    DriverManager.closeDriver(
                            ctx.getScenarioId()
                    );

                    LogUtils.info(
                            "Web driver closed successfully."
                    );

                } else {

                    LogUtils.info(
                            "API scenario — no UI driver to close."
                    );
                }

            } catch (Exception driverEx) {

                LogUtils.warn(
                        "Driver teardown failed (non-fatal): "
                                + driverEx.getMessage()
                );
            }

            // ========================================================
            // CHECK USER BACK INTO POOL
            // ========================================================

            if (userPairToCheckin != null) {

                UserCredentialsManager
                        .getInstance()
                        .checkinUserPair(
                                userPairToCheckin
                        );

            } else {

                /*
                 * Fallback in case the user pair was not assigned
                 * to userPairToCheckin before an exception occurred.
                 */
                UserPair finalUserPair =
                        ctx.getUserPair();

                if (finalUserPair != null) {

                    UserCredentialsManager
                            .getInstance()
                            .checkinUserPair(
                                    finalUserPair
                            );
                }
            }

            // ========================================================
            // CLEAR SCENARIO CONTEXT
            // ========================================================

            ScenarioContext.clear();

            // ========================================================
            // END SCENARIO LOG
            // ========================================================

            LogUtils.endScenario();

            // ========================================================
            // INCREMENT SCENARIO COUNTER
            // ========================================================

            scenarioCounter.incrementAndGet();
        }
    }

    // ================================================================
    // AFTER ALL
    // ================================================================

    @AfterAll
    public static void afterAll() {

        // ============================================================
        // SUITE DURATION
        // ============================================================

        Instant suiteEndTime =
                Instant.now();

        long suiteDurationMillis = 0;

        if (suiteStartTime != null) {

            suiteDurationMillis =
                    Duration.between(
                            suiteStartTime,
                            suiteEndTime
                    ).toMillis();
        }

        final long finalSuiteDuration =
                suiteDurationMillis;

        LogUtils.info(
                String.format(
                        "Total Suite Wall-Clock Duration: %d seconds.",
                        Duration
                                .ofMillis(finalSuiteDuration)
                                .toSeconds()
                )
        );

        // ============================================================
        // WAIT FOR SCENARIO FILES
        // ============================================================

        LogUtils.info(
                "Waiting for all scenario JSON files to be saved..."
        );

        String aggregatorDirPath =
                FeatureAggregator.getScenarioDir();

        File aggregatorDir =
                new File(
                        aggregatorDirPath
                );

        int expectedCount =
                scenarioCounter.get();

        // ============================================================
        // INITIAL GRACE PERIOD
        // ============================================================

        try {

            Thread.sleep(2000);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }

        // ============================================================
        // WAIT FOR FILES
        // ============================================================

        int attempts = 0;

        final int MAX_ATTEMPTS = 30;

        while (attempts < MAX_ATTEMPTS) {

            if (!aggregatorDir.exists()) {

                LogUtils.warn(
                        "Scenario directory does not exist yet. Waiting..."
                );

                sleepForOneSecond();

                attempts++;

                continue;
            }

            File[] files =
                    aggregatorDir.listFiles(
                            f -> f.getName().endsWith(".js")
                    );

            if (files != null
                    && files.length >= expectedCount) {

                boolean allFilesHaveContent =
                        true;

                for (File file : files) {

                    if (file.length() == 0) {

                        allFilesHaveContent =
                                false;

                        break;
                    }
                }

                if (allFilesHaveContent) {

                    LogUtils.info(
                            "All "
                                    + files.length
                                    + " scenario files appear to be ready."
                    );

                    break;
                }
            }

            LogUtils.info(
                    "Waiting for scenario files... Found "
                            + (files != null
                            ? files.length
                            : 0)
                            + "/"
                            + expectedCount
            );

            sleepForOneSecond();

            attempts++;
        }

        // ============================================================
        // TIMEOUT
        // ============================================================

        if (attempts >= MAX_ATTEMPTS) {

            LogUtils.warn(
                    "Timeout waiting for all scenario JSON files "
                            + "to be completely written. "
                            + "Aggregator may miss some data."
            );
        }

        // ============================================================
        // GENERATE REPORTS
        // ============================================================

        LogUtils.info(
                "Generating aggregated reports..."
        );

        String buildNumber =
                System.getenv(
                        "Build.BuildId"
                );

        if (buildNumber == null
                || buildNumber.isEmpty()) {

            buildNumber =
                    "local_"
                            + java.time.format.DateTimeFormatter
                            .ofPattern(
                                    "yyyyMMdd_HHmmss"
                            )
                            .format(
                                    java.time.LocalDateTime.now()
                            );
        }

        LogUtils.info(
                "BuildNumber:" + buildNumber
        );

        FeatureAggregator.generateReports(
                buildNumber,
                finalSuiteDuration
        );

        LogUtils.info(
                "Aggregated reports generation completed."
        );
    }

    // ================================================================
    // SLEEP HELPER
    // ================================================================

    private static void sleepForOneSecond() {

        try {

            Thread.sleep(1000);

        } catch (InterruptedException e) {

            Thread.currentThread().interrupt();
        }
    }

    // ================================================================
    // SCREENSHOT
    // ================================================================

    /**
     * Takes a screenshot for the current scenario.
     *
     * Supports:
     * - Mobile Appium
     * - Web Playwright
     *
     * No video capture is performed.
     */
    public static String takeScreenshot(String scenarioId) {
        ScenarioContext current = ScenarioContext.get();
        if (current == null) {
            LogUtils.warn("Screenshot skipped: no scenario context.");
            return "";
        }
        try {
            String path;
            if (current.isMobileScenario()) {
                if (current.getMobileDriver() == null) {
                    LogUtils.info("Mobile screenshot skipped: no driver was created.");
                    return "";
                }
                path = current.getMobileFailure() == null
                        ? CaptureHelpers.takeMobileScreenshot(current.getMobileDriver(), scenarioId)
                        : MobileFailureSupport.captureFailure(current);
            } else {
                Page webPage = current.getPage();
                if (webPage == null || webPage.isClosed()) {
                    LogUtils.info("Web screenshot skipped: no active page.");
                    return "";
                }
                path = CaptureHelpers.takeScreenshot(webPage, scenarioId);
            }
            if (path != null && !path.isBlank()) ScreenshotContextHolder.publishLastScreenshotPath(path);
            return path == null ? "" : path;
        } catch (Exception error) {
            if (current.isMobileScenario()) MobileFailureSupport.diagnosticFailed(current, "hook screenshot", error);
            else LogUtils.warn("Web screenshot failed: " + SafeDiagnostics.stackTrace(error));
            return "";
        }
    }
}
