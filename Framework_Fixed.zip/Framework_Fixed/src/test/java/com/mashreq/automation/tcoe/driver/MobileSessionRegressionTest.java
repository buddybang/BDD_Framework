package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.hooks.ApplicationHooks;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.utils.CaptureHelpers;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
import com.mashreq.automation.tcoe.utils.MobileFailureSupport;
import com.mashreq.automation.tcoe.utils.SafeDiagnostics;
import com.sun.net.httpserver.HttpServer;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.remote.http.ClientConfig;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** Offline regression checks; never connects to BrowserStack. */
public class MobileSessionRegressionTest {
    @Test
    public void failedSetupScreenshot() {
        ScenarioContext ctx = new ScenarioContext();
        ctx.setMobileScenario(true);
        ScenarioContext.set(ctx);
        try {
            Assert.assertEquals(ApplicationHooks.takeScreenshot("offline_setup_failure"), "");
        } finally {
            ScenarioContext.clear();
        }
    }

    @AfterMethod
    public void clearContext() {
        MobileDriverManager.quitDriver();
        ScenarioContext.clear();
        ScreenshotContextHolder.clear();
    }

    @Test
    public void distinguishesLookupTransportAndSessionFailures() {
        Assert.assertEquals(MobileFailureSupport.classify(new TimeoutException("element not visible")),
                MobileFailureSupport.Kind.LOCATOR_TIMEOUT);
        Assert.assertEquals(MobileFailureSupport.classify(new TimeoutException("HTTP timed out",
                new java.util.concurrent.TimeoutException())), MobileFailureSupport.Kind.TRANSPORT_TIMEOUT);
        Assert.assertEquals(MobileFailureSupport.classify(new IOException("closed")), MobileFailureSupport.Kind.TRANSPORT_FAILURE);
        Assert.assertEquals(MobileFailureSupport.classify(new NoSuchSessionException("deleted")), MobileFailureSupport.Kind.INVALID_SESSION);
    }

    @Test
    public void setupFailureHasNoDriverAndDoesNotAttemptWebScreenshot() {
        ScenarioContext ctx = mobileContext();
        System.setProperty("MOBILE_EXECUTION_MODE", "invalid-offline-test-mode");
        try {
            RuntimeException failure = Assert.expectThrows(RuntimeException.class, MobileDriverManager::initDriver);
            Assert.assertTrue(SafeDiagnostics.stackTrace(failure).contains("java.lang.IllegalArgumentException"));
            Assert.assertEquals(ctx.getMobileFailureCategory(), "SETUP_FAILURE");
            Assert.assertNull(MobileDriverManager.getDriver());
            Assert.assertNull(ctx.getMobileDriver());
            Assert.assertEquals(ApplicationHooks.takeScreenshot(ctx.getScenarioId()), "");
        } finally { System.clearProperty("MOBILE_EXECUTION_MODE"); }
    }

    @Test
    public void capturesOneFailureScreenshotAndPreservesFirstCause() {
        ScenarioContext ctx = mobileContext();
        MobileFailureSupport.record(ctx, "lookup", new TimeoutException("original lookup failure"));
        AtomicInteger attempts = new AtomicInteger();
        Assert.assertEquals(MobileFailureSupport.captureFailure(ctx, () -> {
            attempts.incrementAndGet(); return "evidence.png";
        }), "evidence.png");
        Assert.assertEquals(MobileFailureSupport.captureFailure(ctx, () -> {
            attempts.incrementAndGet(); return "duplicate.png";
        }), "");
        MobileFailureSupport.diagnosticFailed(ctx, "screenshot", new IOException("secondary failure"));
        Assert.assertEquals(attempts.get(), 1);
        Assert.assertTrue(ctx.getMobileFailure().getMessage().contains("original lookup failure"));
    }

    @Test
    public void transportFailureSkipsDiagnostics() {
        ScenarioContext ctx = mobileContext();
        MobileFailureSupport.record(ctx, "findElement", new IOException("connection interrupted"));
        AtomicInteger attempts = new AtomicInteger();
        MobileFailureSupport.captureFailure(ctx, () -> { attempts.incrementAndGet(); return ""; });
        Assert.assertEquals(attempts.get(), 0);
        Assert.assertFalse(ctx.isMobileSessionUsable());
    }

    @Test
    public void redactsCompleteExceptionChainWithoutLosingFrames() {
        IOException root = new IOException("accessKey: test-secret, https://user:password@host/wd/hub");
        RuntimeException outer = new RuntimeException("Authorization: Basic dXNlcjpwYXNz", root);
        outer.addSuppressed(new IOException("password=another-secret"));
        Throwable safe = SafeDiagnostics.sanitized(outer);
        String trace = SafeDiagnostics.stackTrace(safe);
        Assert.assertFalse(trace.contains("test-secret"));
        Assert.assertFalse(trace.contains("another-secret"));
        Assert.assertFalse(trace.contains("dXNlcjpwYXNz"));
        Assert.assertFalse(trace.contains("user:password@"));
        Assert.assertTrue(trace.contains("java.io.IOException"));
        Assert.assertEquals(safe.getCause().getStackTrace(), root.getStackTrace());
        Assert.assertEquals(safe.getSuppressed().length, 1);
    }

    @Test
    public void timeoutConfigurationAndCloudCapabilitiesAreSafe() throws Exception {
        System.setProperty("MOBILE_HTTP_READ_TIMEOUT_SECONDS", "7");
        try {
            ClientConfig config = MobileDriverManager.createBrowserStackClientConfig();
            Assert.assertNull(config.baseUri().getUserInfo());
            Assert.assertNull(config.credentials(), "Authentication uses a preemptive HTTP filter, not a JDK Authenticator");
            Assert.assertEquals(config.readTimeout(), Duration.ofSeconds(7));
            String caps = MobileDriverManager.getBrowserStackAndroidOptions().asMap().toString();
            Assert.assertFalse(caps.contains("accessKey"));
            Assert.assertFalse(caps.contains("userName"));
            System.setProperty("MOBILE_HTTP_READ_TIMEOUT_SECONDS", "0");
            Assert.expectThrows(IllegalArgumentException.class,
                    () -> MobileDriverManager.httpConfig(new URL("http://localhost")));
        } finally {
            System.clearProperty("MOBILE_HTTP_READ_TIMEOUT_SECONDS");
        }
    }

    @Test
    public void actualMissingElementKeepsCauseAndCapturesOnce() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            try {
                MobileUI ui = new MobileUI(ctx, new FeatureStepCollector(), Duration.ofMillis(10));
                AssertionError failure = Assert.expectThrows(AssertionError.class,
                        () -> ui.verifyText("id|missing", "expected"));
                Assert.assertTrue(SafeDiagnostics.stackTrace(failure).contains("org.openqa.selenium.TimeoutException"));
                Assert.assertEquals(ctx.getMobileFailureCategory(), "LOCATOR_TIMEOUT");
                MobileFailureSupport.captureFailure(ctx);
                ApplicationHooks.takeScreenshot(ctx.getScenarioId());
                Assert.assertEquals(server.screenshots.get(), 1);
            } finally { driver.quit(); }
        }
    }

    @Test
    public void brokenScreenshotIsSecondaryAndSessionCanContinue() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            server.truncateScreenshot = true;
            try {
                Assert.assertEquals(CaptureHelpers.takeMobileScreenshot(driver, ctx.getScenarioId()), "");
                Assert.assertTrue(ctx.isMobileDiagnosticsSuppressed());
                Assert.assertTrue(ctx.isMobileSessionUsable());
                Assert.assertNull(ctx.getMobileFailure());
                Assert.assertEquals(driver.getPageSource(), "<hierarchy/>");
                CaptureHelpers.takeMobileScreenshot(driver, ctx.getScenarioId());
                Assert.assertEquals(server.screenshots.get(), 1);
            } finally { driver.quit(); }
        }
    }

    @Test
    public void failedTransportUsesRestStatusAndStillQuitsOnce() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            bindManager(driver);
            MobileFailureSupport.record(ctx, "findElement", new IOException("closed"));
            MobileDriverManager.quitDriver(false, "lookup failed", server.apiConfig());
            MobileDriverManager.quitDriver(false, "duplicate teardown");
            Assert.assertEquals(server.statusCalls.get(), 0);
            Assert.assertEquals(server.restStatusCalls.get(), 1);
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertNull(MobileDriverManager.getDriver());
            Assert.assertNull(ctx.getMobileDriver());
        }
    }

    @Test
    public void usableSessionMarksStatusThenQuits() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            bindManager(driver);
            MobileDriverManager.quitDriver(false, "Reason with quotes \" and newline\n");
            Assert.assertEquals(server.statusCalls.get(), 1);
            Assert.assertEquals(server.deletes.get(), 1);
        }
    }

    @Test
    public void deadSessionDuringStatusFallsBackToRest() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            bindManager(driver);
            server.failStatus = true;
            MobileDriverManager.quitDriver(false, "action failed", server.apiConfig());
            Assert.assertEquals(server.statusCalls.get(), 1);
            Assert.assertEquals(server.restStatusCalls.get(), 1);
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertTrue(server.resultBody.get().contains("failed"));
        }
    }

    @Test
    public void failedResultApiLeavesPendingJournalAndStillCleansUp() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            bindManager(driver);
            MobileFailureSupport.record(ctx, "action", new NoSuchSessionException("dead session"));
            server.failRest = true;
            MobileDriverManager.quitDriver(false, "failed", server.apiConfig());
            var result = new com.fasterxml.jackson.databind.ObjectMapper().readTree(
                    java.nio.file.Paths.get("target", "browserstack-status", "offline-session.json").toFile());
            Assert.assertFalse(result.get("confirmed").asBoolean());
            Assert.assertEquals(result.get("status").asText(), "failed");
            Assert.assertEquals(server.deletes.get(), 1);
            Assert.assertNull(ctx.getMobileDriver());
        }
    }

    @Test
    public void recordedActionFailureCannotBeReportedAsPassed() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            ScenarioContext ctx = mobileContext();
            AppiumDriver driver = server.driver();
            ctx.setMobileDriver(driver);
            bindManager(driver);
            MobileFailureSupport.record(ctx, "click", new IllegalStateException("action failed"));
            MobileDriverManager.quitDriver(true, "passed", server.apiConfig());
            Assert.assertTrue(server.resultBody.get().contains("failed"));
            Assert.assertEquals(server.deletes.get(), 1);
        }
    }

    @Test
    public void parallelScenariosDoNotShareFailureState() throws Exception {
        ExecutorService workers = Executors.newFixedThreadPool(2);
        try {
            var failed = workers.submit(() -> {
                ScenarioContext ctx = mobileContext();
                try { MobileFailureSupport.record(ctx, "lookup", new IOException("closed")); return ctx.isMobileSessionUsable(); }
                finally { ScenarioContext.clear(); }
            });
            var healthy = workers.submit(() -> {
                ScenarioContext ctx = mobileContext();
                try { return ctx.isMobileSessionUsable() && ctx.getMobileFailure() == null; }
                finally { ScenarioContext.clear(); }
            });
            Assert.assertFalse(failed.get());
            Assert.assertTrue(healthy.get());
        } finally { workers.shutdownNow(); }
    }

    private static ScenarioContext mobileContext() {
        ScenarioContext ctx = new ScenarioContext();
        ctx.setMobileScenario(true);
        ctx.setScenarioId("offline_mobile_regression");
        ScenarioContext.set(ctx);
        return ctx;
    }

    @SuppressWarnings("unchecked")
    private static void bindManager(AppiumDriver driver) throws Exception {
        var field = MobileDriverManager.class.getDeclaredField("DRIVER");
        field.setAccessible(true);
        ((ThreadLocal<AppiumDriver>) field.get(null)).set(driver);
        var mode = MobileDriverManager.class.getDeclaredField("EXECUTION_MODE");
        mode.setAccessible(true);
        ((ThreadLocal<String>) mode.get(null)).set("browserstack");
    }

    /** Exercises real Appium/Selenium HTTP code against loopback, never the cloud. */
    private static final class FakeAppium implements AutoCloseable {
        private final HttpServer server;
        private final ExecutorService workers = Executors.newCachedThreadPool();
        final AtomicInteger screenshots = new AtomicInteger();
        final AtomicInteger deletes = new AtomicInteger();
        final AtomicInteger statusCalls = new AtomicInteger();
        final AtomicInteger restStatusCalls = new AtomicInteger();
        final AtomicReference<String> resultBody = new AtomicReference<>();
        volatile boolean failStatus;
        volatile boolean failRest;
        final AtomicReference<String> authorization = new AtomicReference<>();
        volatile boolean truncateScreenshot;

        FakeAppium() throws IOException {
            server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
            server.setExecutor(workers);
            server.createContext("/", exchange -> {
                String path = exchange.getRequestURI().getPath();
                String method = exchange.getRequestMethod();
                String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                authorization.set(exchange.getRequestHeaders().getFirst("Authorization"));
                String body = "{\"value\":null}";
                int status = 200;
                if ("PUT".equals(method) && path.startsWith("/app-automate/sessions/")) {
                    restStatusCalls.incrementAndGet();
                    resultBody.set(requestBody);
                    status = failRest ? 503 : 200;
                } else if ("POST".equals(method) && "/session".equals(path)) {
                    body = "{\"value\":{\"sessionId\":\"offline-session\",\"capabilities\":{\"platformName\":\"Android\"}}}";
                } else if (path.endsWith("/element")) {
                    status = 404;
                    body = "{\"value\":{\"error\":\"no such element\",\"message\":\"missing element\",\"stacktrace\":\"\"}}";
                } else if (path.endsWith("/screenshot")) {
                    screenshots.incrementAndGet();
                    if (truncateScreenshot) {
                        exchange.sendResponseHeaders(200, 1000);
                        exchange.getResponseBody().write("broken".getBytes(StandardCharsets.UTF_8));
                        exchange.close();
                        return;
                    }
                    body = "{\"value\":\"aW1hZ2U=\"}";
                } else if (path.endsWith("/source")) {
                    body = "{\"value\":\"<hierarchy/>\"}";
                } else if (path.endsWith("/execute/sync")) {
                    statusCalls.incrementAndGet();
                    resultBody.set(requestBody);
                    if (failStatus) {
                        status = 404;
                        body = "{\"value\":{\"error\":\"invalid session id\",\"message\":\"session died\",\"stacktrace\":\"\"}}";
                    }
                } else if ("DELETE".equals(method)) {
                    deletes.incrementAndGet();
                }
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
                exchange.sendResponseHeaders(status, bytes.length);
                exchange.getResponseBody().write(bytes);
                exchange.close();
            });
            server.start();
        }

        ClientConfig apiConfig() throws Exception {
            return MobileDriverManager.withCredentials(ClientConfig.defaultConfig()
                    .baseUrl(new URL("http://127.0.0.1:" + server.getAddress().getPort()))
                    .connectionTimeout(Duration.ofSeconds(1)).readTimeout(Duration.ofSeconds(1)), "offline-user", "offline-key");
        }

        AppiumDriver driver() throws Exception {
            URL endpoint = new URL("http://127.0.0.1:" + server.getAddress().getPort());
            ClientConfig config = MobileDriverManager.withCredentials(ClientConfig.defaultConfig().baseUrl(endpoint)
                    .connectionTimeout(Duration.ofSeconds(1)).readTimeout(Duration.ofSeconds(1)),
                    "offline-user", "offline-password");
            AppiumDriver driver = new AndroidDriver(new TimedAppiumCommandExecutor(config), new UiAutomator2Options());
            Assert.assertNotNull(authorization.get(), "HTTP client must send authentication without credentials in URL/capabilities");
            return driver;
        }

        @Override public void close() { server.stop(0); workers.shutdownNow(); }
    }
}
