package com.mashreq.automation.tcoe.listeners;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import io.cucumber.plugin.ConcurrentEventListener;
import io.cucumber.plugin.event.*;

import java.util.*;

import com.mashreq.automation.tcoe.utils.FeatureStepCollector;

public class StepEventListener implements ConcurrentEventListener {

    private final Map<String, FeatureInfo> featureInfoMap = new HashMap<>();

    private static class FeatureInfo {
        String name;
        String description;
        String keyword;
        List<String> tags = new ArrayList<>();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestSourceRead.class, this::handleFeatureRead);
        publisher.registerHandlerFor(TestCaseStarted.class, this::handleScenarioStarted);
        publisher.registerHandlerFor(TestStepStarted.class, this::handleStepStarted);
        publisher.registerHandlerFor(TestStepFinished.class, this::handleStepFinished);
        publisher.registerHandlerFor(TestCaseFinished.class, this::handleScenarioFinished);
    }

    // ---------------- Feature ----------------
    private void handleFeatureRead(TestSourceRead event) {
        String source = event.getSource();
        String uri = event.getUri().toString();
        FeatureInfo info = new FeatureInfo();
        String[] lines = source.split("\n");
        boolean inDescription = false;
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty())
                continue; // Tags at the top
            if (line.startsWith("@") && !inDescription && info.name == null) {
                String[] tags = line.split("\\s+");
                info.tags.addAll(Arrays.asList(tags));
                continue;
            } // Feature line
            if (line.startsWith("Feature:")) {
                info.keyword = "Feature";
                info.name = line.substring("Feature:".length()).trim();
                inDescription = true;
                continue;
            } // Feature description lines
            if (inDescription) {
                if (line.startsWith("Scenario:") || line.startsWith("@")) {
                    inDescription = false;
                } else {
                    if (info.description == null) {
                        info.description = line;
                    } else {
                        info.description += "\n" + line;
                    }
                }
            }
        }
        featureInfoMap.put(uri, info);
    }

    // ---------------- Scenario ----------------
    private void handleScenarioStarted(TestCaseStarted event) {
        TestCase testCase = event.getTestCase();
        String id = String.valueOf(testCase.getId());

        // Parse module and scenarioId
        String rawName = testCase.getName();
        String modulePart = null;
        String scenarioIdPart = null;
        if (rawName != null) {
            String[] parts = rawName.split("\\|");
            if (parts.length >= 2) {
                modulePart = parts[0].trim();
                scenarioIdPart = parts[1].trim();
            }
        }

        List<String> scenarioTags = new ArrayList<>(testCase.getTags());
        String uri = testCase.getUri().toString();
        FeatureInfo info = featureInfoMap.get(uri);

        // Pass modulePart to setFeature
        FeatureStepCollector.setFeature(
                modulePart,
                info != null ? info.name : null,
                info != null ? info.description : null,
                info != null ? info.keyword : null,
                uri,
                info != null ? info.tags : new ArrayList<>()
        );

        FeatureStepCollector.startScenario(
                id,
                testCase.getName(),
                scenarioTags
        );

        FeatureStepCollector.setScenarioMetadata(modulePart, scenarioIdPart);
        ScenarioContext.setPendingCaseId(id);
    }

    private void handleScenarioFinished(TestCaseFinished event) {
        FeatureStepCollector.endScenario();
    }

    // ---------------- Step ----------------
    private void handleStepStarted(TestStepStarted event) {
        if (event.getTestStep() instanceof PickleStepTestStep step) {
            String keyword = step.getStep().getKeyword();
            String text = step.getStep().getText();
            StepArgument argument = step.getStep().getArgument();

            if (argument instanceof DataTableArgument) {
                DataTableArgument tableArg = (DataTableArgument) argument;
                // Get the cells directly as a List of Lists
                List<List<String>> cells = tableArg.cells();

                // Call the NEW overloaded method, passing the List<List<String>>
                FeatureStepCollector.startStep(keyword, text, cells);
            } else {
                // For steps without a DataTable, call the original method
                FeatureStepCollector.startStep(keyword, text);
            }
        }
    }

    private void handleStepFinished(TestStepFinished event) {
        if (event.getTestStep() instanceof PickleStepTestStep) {
            Result result = event.getResult();
            FeatureStepCollector.endStep(result.getStatus().name(),
                    result.getError() != null ? result.getError().getMessage() : null
            );
        }
    }
}