<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Automation Execution Dashboard</title>

    <style>
        /* === Original CSS (restored & kept) === */
        html { height: 100%; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f5f5f5; color: #333; line-height: 1.4; display: flex; flex-direction: column; min-height: 100%; }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; flex-grow: 1; }
        .header { background: white; padding: 15px 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); color: #333; font-size: 18px; font-weight: 600; }
        .main-sections { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 30px; }
        .section { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); height: 300px; display: flex; flex-direction: column; }
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid #eee; }
        .section-title { font-size: 16px; color: #666; font-weight: 500; }
        .chart-container { display: flex; align-items: center; gap: 20px; flex: 1; }
        .chart-wrapper { position: relative; width: 140px; height: 140px; flex-shrink: 0; }
        .chart-center { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; font-size: 28px; font-weight: bold; color: #333; }
        .legend { flex: 1; }
        .legend-item { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 13px; }
        .legend-label { display: flex; align-items: center; gap: 8px; }
        .legend-color { width: 12px; height: 12px; border-radius: 50%; }
        .legend-text { color: #666; }
        .legend-value { color: #333; font-weight: 500; }
        .run-info-container { flex: 1; overflow-y: auto; padding-right: 15px; }
        .run-info-table { width: 100%; }
        .info-item { display: flex; justify-content: space-between; font-size: 13px; padding: 8px 0; border-bottom: 1px solid #f1f3f4; }
        .info-item:last-child { border-bottom: none; }
        .info-label { color: #666; font-weight: 500; }
        .info-value { color: #333; font-weight: 500; text-align: right; }
        .history-section { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .history-chart-container { padding: 20px; background-color: #fff; height: 280px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); position: relative;}
        .history-chart-container canvas { width: 100% !important; height: 210px !important; display: block; }
        .history-chart-container .chart-wrapper { padding-bottom: 16px; }
        .history-chart-title { text-align: center; margin-bottom: 1rem; color: #666; font-weight: 500; font-size: 16px; }
        .data-table .history-cell { padding-left: 15px; width: 160px; }
        .run-history { display: flex; gap: 6px; align-items: center; justify-content: flex-start; }
        .run-dot { width: 14px; height: 14px; border-radius: 50%; border: 1px solid rgba(0,0,0,0.1); display:inline-block; }
        .run-dot.passed { background-color: #28a745; border-color: rgba(0,0,0,0.05); }
        .run-dot.failed { background-color: #dc3545; border-color: rgba(0,0,0,0.05); }
        .run-dot.skipped { background-color: #17a2b8; border-color: rgba(0,0,0,0.05); }
        .run-dot.placeholder { background: #e9ecef; border: 1px solid rgba(0,0,0,0.04); opacity: 0.95; }
        .features-overview { background: white; border-radius: 8px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-top: 30px; margin-bottom: 30px; }
        .overview-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .overview-title { font-size: 16px; color: #666; margin-bottom: 0; }
        .filter-controls { display: flex; align-items: center; gap: 12px; }
        #statusFilter { border: 1px solid #007bff; padding: 8px 12px; border-radius: 6px; font-size: 13px; background-color: white; cursor: pointer; color: #333; }
        .search-box { position: relative; }
        #searchInput { border: 1px solid #ddd; padding: 9px 12px 9px 35px; border-radius: 6px; font-size: 13px; width: 250px; }
        .search-box::before { content: ''; position: absolute; left: 12px; top: 50%; transform: translateY(-50%); width: 14px; height: 14px; background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="%23888" class="bi bi-search" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.414 1.414l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85zM6.5 11a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>'); background-repeat: no-repeat; background-size: contain; }
        #searchInput::placeholder { color: #aaa; }

        .table-wrapper { overflow-x: auto; }

        .data-table { width: 100%; border-collapse: collapse; font-size: 12px; table-layout: fixed; min-width: 900px; }
        .data-table th { background: #f8f9fa; padding: 10px 8px; border-bottom: 1px solid #e9ecef; color: #666; font-weight: 500; position: relative; vertical-align: middle; }
        .data-table th.main-col-header { text-align: center; background-color: #f1f3f4; }
        .data-table td { padding: 8px; border-bottom: 1px solid #f1f3f4; vertical-align: middle; }
        .data-table tr:hover { background: #f8f9fa; }
        .data-table tfoot td { font-weight: 500; background: #f8f9fa; }
        .data-table tfoot tr:first-child td { border-top: 2px solid #e9ecef; }
        .status-badge { display: inline-block; padding: 3px 8px; font-size: 11px; font-weight: bold; border-radius: 4px; text-transform: uppercase; border: 1px solid transparent; min-width: 65px; text-align: center; }
        .status-badge-passed { background-color: #e9f7ec; color: #28a745; border-color: #a3d9b1; }
        .status-badge-failed { background-color: #fceeee; color: #dc3545; border-color: #f3c6cb; }
        .status-badge-skipped { background-color: #e8f6f8; color: #17a2b8; border-color: #b3e6ed; }
        .feature-link { color: #007bff; text-decoration: none; }
        .feature-link:hover { text-decoration: underline; }
        .footer { text-align: center; padding: 20px; margin-top: 20px; color: #666; font-size: 13px; }
        .passed-color { background: #28a745; }
        .failed-color { background: #dc3545; }
        .skipped-color { background: #17a2b8; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .feature-name-col { width: 30%; max-width: 400px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; text-align: left; }
        .status-col { width: 90px; }
        .duration-col { width: 80px; }

        /* === FIX: Updated styling for remark text === */
        .history-remark {
            text-align: left;
            color: #6c757d;
            font-style: italic;
            font-size: 11px; /* Smaller font */
            padding: 4px 0 16px 10px;
            margin-top: 5px;
        }

        .data-table th.col-separator,
        .data-table td.col-separator {
            border-right: 1px solid #e9ecef;
        }
        .data-table th.col-separator:last-child,
        .data-table td.col-separator:last-child { border-right: none; }

        @media (max-width: 1100px) {
            .main-sections { grid-template-columns: 1fr 1fr; }
            .history-section { grid-template-columns: 1fr; }
        }
        @media (max-width: 768px) {
            .container { padding: 10px; }
            .main-sections { grid-template-columns: 1fr; }
            .section { height: auto; }
            .chart-container { flex-direction: column; gap: 25px; }
            .overview-header { flex-direction: column; align-items: flex-start; gap: 15px; }
            .filter-controls { width: 100%; flex-direction: column; align-items: stretch; }
            #searchInput { width: 100%; }
        }
    </style>
</head>
<body>

<#-- FreeMarker defaults -->
<#assign DISPLAY_BACKUPS = (DISPLAY_BACKUPS?default(4)) />
<#assign DISPLAY_COUNT = DISPLAY_BACKUPS + 1 />

<#-- Safe JSON serializer: toJson(x) - produces JSON text (no HTML escaping) -->
<#function toJson x>
  <#if x??>
    <#if x?is_hash>
      <#assign s = "{" />
      <#list x?keys as k>
        <#assign s = s + '"' + (k?js_string) + '":' + toJson(x[k]) />
        <#if k_has_next><#assign s = s + ',' /></#if>
      </#list>
      <#return s + "}" />
    <#elseif x?is_sequence>
      <#assign s = "[" />
      <#list x as it>
        <#assign s = s + toJson(it) />
        <#if it_has_next><#assign s = s + ',' /></#if>
      </#list>
      <#return s + "]" />
    <#elseif x?is_string>
      <#return '"' + (x?js_string) + '"' />
    <#elseif x?is_number>
      <#return x?c />
    <#elseif x?is_boolean>
      <#return (x?string)?lower_case />
    <#else>
      <#return "null" />
    </#if>
  <#else>
    <#return "null" />
  </#if>
</#function>

    <div class="container">
        <div class="header">Automation Execution Dashboard</div>

        <div class="main-sections">
            <div class="section">
                <div class="section-header"><h2 class="section-title">Features</h2></div>
                <div class="chart-container">
                    <div class="chart-wrapper"><canvas id="featuresChart"></canvas><div class="chart-center">${featureSummary.total}</div></div>
                    <div class="legend">
                        <div class="legend-item"><div class="legend-label"><div class="legend-color passed-color"></div><span>Passed</span></div><span>${featureSummary.passed} [${featureSummary.passedPct}%]</span></div>
                        <div class="legend-item"><div class="legend-label"><div class="legend-color failed-color"></div><span>Failed</span></div><span>${featureSummary.failed} [${featureSummary.failedPct}%]</span></div>
                        <div class="legend-item"><div class="legend-label"><div class="legend-color skipped-color"></div><span>Skipped</span></div><span>${featureSummary.skipped} [${featureSummary.skippedPct}%]</span></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <div class="section-header"><h2 class="section-title">Scenarios</h2></div>
                <div class="chart-container">
                    <div class="chart-wrapper"><canvas id="scenariosChart"></canvas><div class="chart-center">${scenarioSummary.total}</div></div>
                    <div class="legend">
                        <div class="legend-item"><div class="legend-label"><div class="legend-color passed-color"></div><span>Passed</span></div><span>${scenarioSummary.passed} [${scenarioSummary.passedPct}%]</span></div>
                        <div class="legend-item"><div class="legend-label"><div class="legend-color failed-color"></div><span>Failed</span></div><span>${scenarioSummary.failed} [${scenarioSummary.failedPct}%]</span></div>
                        <div class="legend-item"><div class="legend-label"><div class="legend-color skipped-color"></div><span>Skipped</span></div><span>${scenarioSummary.skipped} [${scenarioSummary.skippedPct}%]</span></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <div class="section-header"><h2 class="section-title">Run info</h2></div>
                <div class="run-info-container">
                    <div class="run-info-table">
                        <div class="info-item"><span>Project Name</span><span>${projectName}</span></div>
                        <div class="info-item"><span>Execution Date</span><span>${executionDate}</span></div>
                        <div class="info-item"><span>Total Suite Time</span><span>${totalDurationFormatted}</span></div>
                        <div class="info-item"><span>Environment</span><span>${environment}</span></div>
                        <div class="info-item"><span>Platform</span><span>${platform}</span></div>
                        <div class="info-item"><span>Browser</span><span>${browser}</span></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="history-section">
            <div class="history-chart-container">
                <h3 class="history-chart-title">Feature History (Last ${DISPLAY_COUNT} Runs)</h3>
                <canvas id="featureHistoryChart"></canvas>
            </div>
            <div class="history-chart-container">
                <h3 class="history-chart-title">Scenario History (Last ${DISPLAY_COUNT} Runs)</h3>
                <canvas id="scenarioHistoryChart"></canvas>
            </div>
        </div>

        <div id="historyRemark" class="history-remark" style="display:none;"></div>

        <div class="features-overview">
            <div class="overview-header">
                <h2 class="overview-title">Features overview</h2>
                <div class="filter-controls">
                    <div class="search-box"><input type="text" id="searchInput" placeholder="Search here..."></div>
                    <select id="statusFilter"><option value="all">All Statuses</option><option value="passed">Passed</option><option value="failed">Failed</option></select>
                </div>
            </div>

            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th rowspan="2" class="feature-name-col">Feature name</th>
                            <th rowspan="2" class="history-cell">History</th>
                            <th rowspan="2" class="col-separator text-center status-col">Status</th>
                            <th colspan="4" class="main-col-header col-separator">Scenarios</th>
                            <th colspan="4" class="main-col-header col-separator">Steps</th>
                            <th rowspan="2" class="text-right duration-col">Duration</th>
                        </tr>
                        <tr>
                            <th class="text-center">Total</th><th class="text-center">Passed</th><th class="text-center">Failed</th><th class="col-separator text-center">Skipped</th>
                            <th class="text-center">Total</th><th class="text-center">Passed</th><th class="text-center">Failed</th><th class="col-separator text-center">Skipped</th>
                        </tr>
                    </thead>
                    <tbody>
                        <#list features as feature>
                            <#-- pick history either feature.history or first scenario.history -->
                            <#if feature.history?has_content>
                                <#assign histSource = feature.history />
                            <#elseif feature.scenarios?has_content && feature.scenarios[0].history?has_content>
                                <#assign histSource = feature.scenarios[0].history />
                            <#else>
                                <#assign histSource = [] />
                            </#if>

                            <#-- render oldest -> newest dots (show up to DISPLAY_COUNT - server-side) -->
                            <#assign chronological = histSource?reverse />
                            <#assign start = chronological?size - DISPLAY_COUNT />
                            <#if start lt 0><#assign start = 0 /></#if>
                            <#assign trimmed = chronological[start..] />
                            <#assign padding = DISPLAY_COUNT - trimmed?size />

                            <#-- BUILD SAFE FILENAME PARTS FOR THE FEATURE LINK -->
                            <#-- safeModule: moduleName sanitized, fallback 'module' -->
                            <#assign safeModule = (feature.moduleName?default("module"))?replace('[^A-Za-z0-9_-]','_') />
                            <#-- idPart: prefer featureUUID, fallback to sanitized featureName -->
                            <#if feature.featureUUID?has_content>
                              <#assign idPart = feature.featureUUID />
                            <#else>
                              <#assign idPart = (feature.featureName?default("unknown_feature"))?replace('[^A-Za-z0-9_-]','_') />
                            </#if>


                            <tr data-status="${feature.status?lower_case}">
                                <td class="feature-name-col" title="${feature.featureName}">
                                    <a href="feature_${safeModule}_${idPart}.html" class="feature-link">${feature.featureName}</a>
                                </td>

                                <td class="history-cell">
                                  <div class="run-history">
                                    <#if padding gt 0>
                                      <#list 1..padding as _>
                                        <div class="run-dot placeholder" title="No run"></div>
                                      </#list>
                                    </#if>
                                    <#list trimmed as run>
                                      <#assign st = (run.status?string?lower_case)!'skipped' />
                                      <#if st == 'passed'>
                                        <div class="run-dot passed" title="Build: ${run.buildNumber?if_exists?html} - ${run.status?if_exists?html}"></div>
                                      <#elseif st == 'failed'>
                                        <div class="run-dot failed" title="Build: ${run.buildNumber?if_exists?html} - ${run.status?if_exists?html}"></div>
                                      <#else>
                                        <div class="run-dot skipped" title="Build: ${run.buildNumber?if_exists?html} - ${run.status?if_exists?html}"></div>
                                      </#if>
                                    </#list>
                                  </div>
                                </td>

                                <td class="col-separator text-center"><span class="status-badge status-badge-${feature.status?lower_case}">${feature.status}</span></td>
                                <td class="text-center">${feature.totalScenarios}</td>
                                <td class="text-center">${feature.passedScenarios}</td>
                                <td class="text-center">${feature.failedScenarios}</td>
                                <td class="col-separator text-center">${feature.totalScenarios - feature.passedScenarios - feature.failedScenarios}</td>
                                <td class="text-center">${feature.totalSteps}</td>
                                <td class="text-center">${feature.passedSteps}</td>
                                <td class="text-center">${feature.failedSteps}</td>
                                <td class="col-separator text-center">${feature.skippedSteps}</td>
                                <td class="text-right">${feature.durationFormatted}</td>
                            </tr>
                        </#list>

                        <tr id="no-results-row" style="display: none;"><td colspan="12" class="text-center" style="padding: 20px; color: #888;">No features match the current filter.</td></tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><strong>Totals</strong></td>
                            <td class="history-cell"></td>
                            <td class="col-separator"></td>
                            <td id="s-total" class="text-center"><strong>${scenarioSummary.total}</strong></td><td id="s-passed" class="text-center"><strong>${scenarioSummary.passed}</strong></td><td id="s-failed" class="text-center"><strong>${scenarioSummary.failed}</strong></td><td id="s-skipped" class="col-separator text-center"><strong>${scenarioSummary.skipped}</strong></td>
                            <td id="st-total" class="text-center"><strong>${stepSummary.total}</strong></td><td id="st-passed" class="text-center"><strong>${stepSummary.passed}</strong></td><td id="st-failed" class="text-center"><strong>${stepSummary.failed}</strong></td><td id="st-skipped" class="col-separator text-center"><strong>${stepSummary.skipped}</strong></td>
                            <td id="duration-total" class="text-right"><strong>${totalDurationFormatted}</strong></td>
                        </tr>
                        <tr class="percentage-row">
                            <td></td><td></td><td class="col-separator"></td><td class="text-center"></td>
                            <td id="s-passed-pct" class="text-center">(${scenarioSummary.passedPct}%)</td><td id="s-failed-pct" class="text-center">(${scenarioSummary.failedPct}%)</td><td id="s-skipped-pct" class="col-separator text-center">(${scenarioSummary.skippedPct}%)</td>
                            <td class="text-center"></td>
                            <td id="st-passed-pct" class="text-center">(${stepSummary.passedPct}%)</td><td id="st-failed-pct" class="text-center">(${stepSummary.failedPct}%)</td><td id="st-skipped-pct" class="col-separator text-center">(${stepSummary.skippedPct}%)</td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <div class="footer"><p>&copy; <span id="currentYear"></span> Custom Cucumber Report | All Rights Reserved.</p></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>

    <script>
        // Expose constants injected by FreeMarker
        const DISPLAY_BACKUPS = ${DISPLAY_BACKUPS?c};
        const DISPLAY_COUNT = ${DISPLAY_COUNT?c};

        // Emit server-side history as a JS literal safely using toJson(...) above.
        let historyData = [];
        (function() {
          try {
            const rawEmitted = ${toJson(historyJson)!'null'};
            if (rawEmitted === null) {
              historyData = [];
            } else if (typeof rawEmitted === 'string') {
              try {
                const parsed = JSON.parse(rawEmitted);
                historyData = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.runs) ? parsed.runs : []);
              } catch (err) {
                console.warn('historyData: server emitted a string but JSON.parse failed:', err);
                historyData = [];
              }
            } else if (Array.isArray(rawEmitted)) {
              historyData = rawEmitted;
            } else if (typeof rawEmitted === 'object') {
              historyData = Array.isArray(rawEmitted.runs) ? rawEmitted.runs
                         : Array.isArray(rawEmitted.history) ? rawEmitted.history
                         : Array.isArray(rawEmitted) ? rawEmitted
                         : [];
            } else {
              historyData = [];
            }
          } catch (err) {
            console.warn('historyData: unexpected normalization error', err);
            historyData = [];
          }
        })();

        document.addEventListener('DOMContentLoaded', function () {
            document.getElementById('currentYear').textContent = new Date().getFullYear();

            // small donuts
            try {
                new Chart(document.getElementById('featuresChart').getContext('2d'), {
                    type: 'doughnut',
                    data: { datasets: [{ data: [${featureSummary.passed?c}, ${featureSummary.failed?c}, ${featureSummary.skipped?c}], backgroundColor: ['rgba(40,167,69,0.9)', 'rgba(220,53,69,0.9)', 'rgba(23,162,184,0.9)'], borderWidth: 0 }] },
                    options: { cutout: '70%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, maintainAspectRatio: false }
                });
                new Chart(document.getElementById('scenariosChart').getContext('2d'), {
                    type: 'doughnut',
                    data: { datasets: [{ data: [${scenarioSummary.passed?c}, ${scenarioSummary.failed?c}, ${scenarioSummary.skipped?c}], backgroundColor: ['rgba(40,167,69,0.9)', 'rgba(220,53,69,0.9)', 'rgba(23,162,184,0.9)'], borderWidth: 0 }] },
                    options: { cutout: '70%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, maintainAspectRatio: false }
                });
            } catch (e) {
                console.warn("Mini doughnuts failed to render:", e);
            }

            let normalized = [];
            try {
                normalized = Array.isArray(historyData) ? historyData : [];
            } catch (err) {
                normalized = [];
            }

            try {
                renderHistoryCharts(normalized);
            } catch (err) {
                console.error('Rendering history charts failed:', err);
            }

            // Filtering controls
            const searchInput = document.getElementById('searchInput');
            const statusFilter = document.getElementById('statusFilter');
            const tableRows = document.querySelectorAll('.data-table tbody tr:not(#no-results-row)');
            const noResultsRow = document.getElementById('no-results-row');
            const tableFooter = document.querySelector('.data-table tfoot');

            function parseNumeric(text) {
                if (!text && text !== 0) return 0;
                text = String(text).trim().replace(/\u00A0/g, ''); // trim & NBSP

                // If both dot and comma present -> assume comma is thousands sep, remove commas
                if (text.indexOf('.') >= 0 && text.indexOf(',') >= 0) {
                    text = text.replace(/,/g, '');
                } else if (text.indexOf(',') >= 0 && text.indexOf('.') === -1) {
                    // If only comma present, decide whether it's decimal or thousands:
                    // If comma is followed by 1-2 digits at end (e.g. "1,5" or "12,34") -> treat as decimal
                    if (/,(\d{1,2})$/.test(text)) {
                        text = text.replace(',', '.');
                    } else {
                        // otherwise remove commas (thousands separator)
                        text = text.replace(/,/g, '');
                    }
                }
                // Remove any characters other than digits, dot, minus
                text = text.replace(/[^0-9.\-]/g, '');

                if (text === '' || text === '.' || text === '-' ) return 0;
                // prefer integer if no dot, otherwise parseFloat
                return (text.indexOf('.') >= 0) ? (parseFloat(text) || 0) : (parseInt(text, 10) || 0);
            }

            function updateTotals() {
                let visibleCount = 0;
                let sTotal = 0, sPassed = 0, sFailed = 0, sSkipped = 0;
                let stTotal = 0, stPassed = 0, stFailed = 0, stSkipped = 0;
                let durationSecs = 0;

                tableRows.forEach(row => {
                    if (row.style.display !== 'none') {
                        visibleCount++;
                        sTotal   += parseNumeric(row.cells[3].textContent) || 0;
                        sPassed  += parseNumeric(row.cells[4].textContent) || 0;
                        sFailed  += parseNumeric(row.cells[5].textContent) || 0;
                        sSkipped += parseNumeric(row.cells[6].textContent) || 0;
                        stTotal  += parseNumeric(row.cells[7].textContent) || 0;
                        stPassed += parseNumeric(row.cells[8].textContent) || 0;
                        stFailed += parseNumeric(row.cells[9].textContent) || 0;
                        stSkipped+= parseNumeric(row.cells[10].textContent) || 0;

                        const durationText = row.cells[11].textContent;
                        const minMatch = durationText.match(/(\d+)m/);
                        const secMatch = durationText.match(/(\d+)s/);
                        if (minMatch) durationSecs += parseInt(minMatch[1]) * 60;
                        if (secMatch) durationSecs += parseInt(secMatch[1]);
                    }
                });

                if (visibleCount === 0) {
                    tableFooter.style.display = 'none';
                    noResultsRow.style.display = '';
                } else {
                    tableFooter.style.display = '';
                    noResultsRow.style.display = 'none';

                    const pct = (val, total) => {
                        if (total === 0) return '(0.00%)';
                        return '(' + (val / total * 100).toFixed(2) + '%)';
                    };

                    document.getElementById('s-total').textContent = sTotal;
                    document.getElementById('s-passed').textContent = sPassed;
                    document.getElementById('s-failed').textContent = sFailed;
                    document.getElementById('s-skipped').textContent = sSkipped;
                    document.getElementById('st-total').textContent = stTotal;
                    document.getElementById('st-passed').textContent = stPassed;
                    document.getElementById('st-failed').textContent = stFailed;
                    document.getElementById('st-skipped').textContent = stSkipped;

                    const totalMins = Math.floor(durationSecs / 60);
                    const totalSecs = durationSecs % 60;
                    document.getElementById('duration-total').textContent = totalMins + 'm ' + totalSecs + 's';

                    document.getElementById('s-passed-pct').textContent = pct(sPassed, sTotal);
                    document.getElementById('s-failed-pct').textContent = pct(sFailed, sTotal);
                    document.getElementById('s-skipped-pct').textContent = pct(sSkipped, sTotal);
                    document.getElementById('st-passed-pct').textContent = pct(stPassed, stTotal);
                    document.getElementById('st-failed-pct').textContent = pct(stFailed, stTotal);
                    document.getElementById('st-skipped-pct').textContent = pct(stSkipped, stTotal);
                }
            }

            function applyFilters() {
                const searchTerm = searchInput.value.toLowerCase();
                const selectedStatus = statusFilter.value;
                tableRows.forEach(row => {
                    const rowStatus = row.dataset.status;
                    const statusMatch = (selectedStatus === 'all' || rowStatus === selectedStatus);
                    const searchMatch = row.textContent.toLowerCase().includes(searchTerm);
                    row.style.display = (statusMatch && searchMatch) ? '' : 'none';
                });
                updateTotals();
            }
            searchInput.addEventListener('input', applyFilters);
            statusFilter.addEventListener('change', applyFilters);
            updateTotals();
        });

        function renderHistoryCharts(allRunsData) {
            const runsInput = Array.isArray(allRunsData) ? allRunsData.slice() : [];
            runsInput.sort((a,b) => {
                const ta = a && a.executionTime ? new Date(a.executionTime).getTime() : 0;
                const tb = b && b.executionTime ? new Date(b.executionTime).getTime() : 0;
                return ta - tb;
            });

            const trimmed = runsInput.slice(Math.max(0, runsInput.length - DISPLAY_COUNT));
            const padding = Math.max(0, DISPLAY_COUNT - trimmed.length);
            const runsToPlot = Array.from({length: padding}).map(()=>null).concat(trimmed);

            const fullLabels = runsToPlot.map(r => r ? (r.buildNumber || '') : '');
            const shortLabels = runsToPlot.map((r, idx) => idx === runsToPlot.length - 1 ? 'Latest' : 'Last ' + (runsToPlot.length - 1 - idx));

            const featurePassed = runsToPlot.map(r => r ? (r.features ? r.features.reduce((s,f)=> s + (String((f.status||'')).toUpperCase()==='PASSED'?1:0), 0) : 0) : 0);
            const featureFailed = runsToPlot.map(r => r ? (r.features ? r.features.reduce((s,f)=> s + (String((f.status||'')).toUpperCase()==='FAILED'?1:0), 0) : 0) : 0);
            const scenarioPassed = runsToPlot.map(r => r ? (r.features ? r.features.reduce((s,f)=> s + (parseInt(f.passedScenarios||0,10)), 0) : 0) : 0);
            const scenarioFailed = runsToPlot.map(r => r ? (r.features ? r.features.reduce((s,f)=> s + (parseInt(f.failedScenarios||0,10)), 0) : 0) : 0);

            const featureSuccessRate = runsToPlot.map((r,i) => {
                if (!r) return null;
                const p = featurePassed[i]||0, f = featureFailed[i]||0, t = p+f;
                return t === 0 ? 0 : +((p / t) * 100).toFixed(2);
            });
            const scenarioSuccessRate = runsToPlot.map((r,i) => {
                if (!r) return null;
                const p = scenarioPassed[i]||0, f = scenarioFailed[i]||0, t = p+f;
                return t === 0 ? 0 : +((p / t) * 100).toFixed(2);
            });

            const isPlaceholder = runsToPlot.map(r => r === null);

            renderComboChart('featureHistoryChart', shortLabels, fullLabels, featurePassed, featureFailed, featureSuccessRate, { isPlaceholder });
            renderComboChart('scenarioHistoryChart', shortLabels, fullLabels, scenarioPassed, scenarioFailed, scenarioSuccessRate, { isPlaceholder });

            const actualRuns = Array.isArray(allRunsData) ? allRunsData.length : 0;
            const remarkEl = document.getElementById('historyRemark');
            if (remarkEl) {
                if (actualRuns < DISPLAY_COUNT) {
                    let remark = '';
                    if (actualRuns === 0) {
                        // Message for when there is no historical data at all.
                        remark = "Showing the last " + DISPLAY_COUNT + " runs. No data available yet; a trend will emerge with future executions.";
                    } else {
                        // Dynamically creates the message for 1 or more runs.
                        const executionText = actualRuns === 1 ? "execution" : "executions";
                        remark = "Showing the last " + DISPLAY_COUNT + " runs. Data available for " + actualRuns + " recent " + executionText + "; trend will improve with more history.";
                    }
                    remarkEl.style.display = 'block';
                    remarkEl.textContent = remark;
                } else {
                    remarkEl.style.display = 'none';
                }
            }
        }

        function renderComboChart(canvasId, shortLabels, fullLabels, passedData, failedData, successRateDataRaw, opts = {}) {
            const labels = shortLabels || [];
            const passCounts = passedData || [];
            const failCounts = failedData || [];
            const successPercent = (successRateDataRaw || []).map(v => (v === null || v === undefined) ? null : Number(v));
            const isPlaceholder = Array.isArray(opts.isPlaceholder) ? opts.isPlaceholder : labels.map(()=>false);

            let maxReal = 0;
            for (let i=0;i<labels.length;i++) {
                if (!isPlaceholder[i]) {
                    const total = (Number(passCounts[i]||0) + Number(failCounts[i]||0));
                    if (total > maxReal) maxReal = total;
                }
            }
            const placeholderHeight = maxReal > 0 ? Math.max(Math.round(maxReal * 0.95), 1) : 1;
            const totals = labels.map((_,i) => isPlaceholder[i] ? 0 : (Number(passCounts[i]||0) + Number(failCounts[i]||0)));
            const pointRadii = labels.map((_,i) => isPlaceholder[i] ? 0 : 6);
            const pointHover = labels.map((_,i) => isPlaceholder[i] ? 0 : 8);

            const datasets = [
                {
                  label: 'Success %',
                  data: successPercent,
                  type: 'line',
                  yAxisID: 'y1',
                  order: 1, // Draw line/dots ON TOP of bars
                  tension: (labels.length > 1 ? 0.35 : 0),
                  borderWidth: 3,
                  borderColor: 'rgba(54,162,235,1)',
                  backgroundColor: 'rgba(54,162,235,0.05)',
                  pointBackgroundColor: 'white',
                  pointBorderColor: 'rgba(54,162,235,1)',
                  pointBorderWidth: 2,
                  pointRadius: pointRadii,
                  pointHoverRadius: pointHover,
                  spanGaps: true,
                  showLine: true,
                  fill: false,
                  hidden: !(successPercent.some(v => v !== null))
                },
                { label: 'Passed', data: passCounts, backgroundColor: 'rgba(40,167,69,0.85)', borderColor: 'rgba(40,167,69,1)', borderWidth: 1, stack: 'stack1', type: 'bar', order: 2, borderSkipped: false, _isMain:true },
                { label: 'Failed', data: failCounts, backgroundColor: 'rgba(220,53,69,0.85)', borderColor: 'rgba(220,53,69,1)', borderWidth: 1, stack: 'stack1', type: 'bar', order: 2, borderSkipped: false }
            ];

            const config = {
                type: 'bar',
                data: { labels, datasets },
                options: {
                    responsive: true,
                    barPercentage: 0.25,
                    maintainAspectRatio: false,
                    layout: { padding: { top: 35, bottom: 0 } },
                    plugins: {
                        legend: { position: 'bottom', labels: { boxWidth: 16, padding: 10 } },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                title: function (ctx) {
                                    const idx = ctx && ctx[0] && ctx[0].dataIndex;
                                    if (idx !== undefined && isPlaceholder[idx]) return '';
                                    return fullLabels[idx] || '';
                                },
                                beforeBody: function (ctx) {
                                    const idx = ctx && ctx[0] && ctx[0].dataIndex;
                                    if (idx !== undefined && isPlaceholder[idx]) return ['No historical data for this run.'];
                                    const total = totals[idx] || 0;
                                    return ['∑  Total: ' + total, ''];
                                },
                                label: function (context) {
                                    const idx = context.dataIndex;
                                    if (isPlaceholder[idx]) return '';
                                    const dsLabel = context.dataset.label || '';
                                    const parsed = context.parsed;
                                    const value = (parsed && (parsed.y !== undefined ? parsed.y : parsed)) || 0;
                                    if (dsLabel === 'Success %') return '   ' + dsLabel + ': ' + value + ' %';
                                    return '   ' + dsLabel + ': ' + value;
                                }
                            }
                        }
                    },
                    interaction: { mode: 'index', intersect: false },
                    scales: {
                        x: { stacked: true, title: { display: true, text: 'Build' }, grid: { display: false } },
                        y: { beginAtZero: true, stacked: true, title: { display: true, text: 'Counts' }, grid: { display: false }, ticks: { precision: 0 } },
                        y1: {
                          beginAtZero: true,
                          position: 'right',
                          min: 0,
                          max: 100,
                          suggestedMin: 0,
                          suggestedMax: 100,
                          grid: { drawOnChartArea: false },
                          title: { display: true, text: 'Success (%)' },
                          ticks: { callback: v => v + '%' }
                        }
                    }
                },
                plugins: [
                    {
                        id: 'placeholderBarsPlugin',
                        beforeDatasetsDraw(chart) {
                            const ctx = chart.ctx;
                            const xScale = chart.scales.x;
                            const yScale = chart.scales.y;
                            if (!xScale || !yScale) return;
                            ctx.save();
                            let barWidth = 20;
                            try {
                                const tickCount = labels.length;
                                if (tickCount > 1) {
                                    const p0 = xScale.getPixelForTick(0);
                                    const p1 = xScale.getPixelForTick(1);
                                    barWidth = Math.abs(p1 - p0) * 0.2;
                                }
                            } catch (e) {}
                            const halfBar = barWidth / 2;

                            for (let i = 0; i < labels.length; i++) {
                                if (!isPlaceholder[i]) continue;
                                const px = xScale.getPixelForTick(i);
                                const yTop = yScale.getPixelForValue(placeholderHeight);
                                const yBottom = yScale.getPixelForValue(0);
                                // === FIX: Use a more transparent, "glassy" color ===
                                ctx.fillStyle = 'rgba(228, 231, 235, 0.7)';
                                ctx.fillRect(px - halfBar, yTop, barWidth, yBottom - yTop);
                            }
                            ctx.restore();
                        }
                    },
                    {
                        id: 'totalsLabelPlugin',
                        afterDatasetsDraw(chart) {
                            const ctx = chart.ctx;
                            const chartArea = chart.chartArea;
                            if (!chartArea) return;
                            ctx.save();
                            const mainIdx = chart.data.datasets.findIndex(ds => ds._isMain);
                            if (mainIdx === -1) { ctx.restore(); return; }
                            const meta = chart.getDatasetMeta(mainIdx);
                            ctx.font = '600 13px "Segoe UI", Arial';
                            ctx.fillStyle = '#111';
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'bottom';
                            for (let i = 0; i < (meta.data?.length || 0); i++) {
                                if (isPlaceholder[i]) continue;
                                const el = meta.data[i];
                                if (!el) continue;
                                const x = el.x;
                                const totalValue = totals[i] || 0;
                                const yTop = chart.scales.y.getPixelForValue(totalValue);
                                const drawY = Math.max(yTop, chartArea.top);
                                ctx.fillText(String(totalValue), x, drawY - 2);
                            }
                            ctx.restore();
                        }
                    },
                    {
                        id: 'successBadgePlugin',
                        afterDatasetsDraw(chart) {
                            const ctx = chart.ctx;
                            const chartArea = chart.chartArea;
                            if (!chartArea) return;

                            const lineDatasetIndex = chart.data.datasets.findIndex(ds => ds.label === 'Success %');
                            if (lineDatasetIndex === -1) return;

                            const meta = chart.getDatasetMeta(lineDatasetIndex);
                            const successData = chart.data.datasets[lineDatasetIndex].data;

                            ctx.save();
                            ctx.font = '600 12px "Segoe UI", Arial';
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';

                            const roundedRectPath = (ctx, x, y, width, height, radius) => {
                                const r = Math.min(radius, width / 2, height / 2);
                                ctx.moveTo(x + r, y);
                                ctx.arcTo(x + width, y, x + width, y + height, r);
                                ctx.arcTo(x + width, y + height, x, y + height, r);
                                ctx.arcTo(x, y + height, x, y, r);
                                ctx.arcTo(x, y, x + width, y, r);
                                ctx.closePath();
                            };

                            for (let i = 0; i < (meta.data?.length || 0); i++) {
                                if (isPlaceholder[i] || successData[i] === null) continue;

                                const el = meta.data[i];
                                if (!el) continue;

                                const x = el.x;
                                const text = String(successData[i]) + '%';

                                const badgePaddingX = 8, badgePaddingY = 5, badgeRadius = 6;
                                const badgeTextColor = '#005bc5', badgeBorderColor = '#007bff', badgeFill = '#ffffff';

                                const textWidth = ctx.measureText(text).width;
                                const fontSize = 12;
                                const badgeHeight = fontSize + badgePaddingY * 2;
                                const badgeWidth = textWidth + badgePaddingX * 2;

                                const y = el.y;
                                let ry = y - badgeHeight - 8;
                                const minBadgeY = chartArea.top + 8;
                                if (ry < minBadgeY) {
                                    ry = minBadgeY;
                                }

                                const rx = x - badgeWidth / 2;

                                ctx.beginPath();
                                roundedRectPath(ctx, rx, ry, badgeWidth, badgeHeight, badgeRadius);
                                ctx.fillStyle = badgeFill;
                                ctx.fill();
                                ctx.lineWidth = 1.5;
                                ctx.strokeStyle = badgeBorderColor;
                                ctx.stroke();
                                ctx.fillStyle = badgeTextColor;
                                ctx.fillText(text, x, ry + badgeHeight / 2);
                            }
                            ctx.restore();
                        }
                    }
                ]
            };

            let canvasEl = (typeof canvasId === 'string') ? document.getElementById(canvasId) : canvasId;
            if (!canvasEl) { console.error('renderComboChart: canvas element not found for', canvasId); return null; }
            if (canvasEl._chartInstance) {
                try { canvasEl._chartInstance.destroy(); } catch (e) {}
                canvasEl._chartInstance = null;
            }
            const chartInstance = new Chart(canvasEl, config);
            canvasEl._chartInstance = chartInstance;
            return chartInstance;
        }
    </script>
</body>
</html>