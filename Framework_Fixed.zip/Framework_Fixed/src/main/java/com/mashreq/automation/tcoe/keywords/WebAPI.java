//package com.mashreq.automation.tcoe.keywords;
//
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.utils.LogUtils;
//import io.restassured.RestAssured;
//import io.restassured.filter.log.RequestLoggingFilter;
//import io.restassured.filter.log.ResponseLoggingFilter;
//import io.restassured.http.ContentType;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestSpecification;
//import org.testng.Assert;
//
//import java.util.Map;
//import java.util.function.Supplier;
//
///**
// * A keyword-driven engine for API interactions using RestAssured.
// * Abstracts low-level HTTP calls into high-level keywords: GET, POST, PUT, DELETE.
// * Relies on ScenarioContext for thread-safe session management.
// */
//public final class WebAPI {
//
//    private final IActionLogger logger;
//    private final ScenarioContext ctx;
//
//    // Base URI is configured once at construction time.
//    private final String baseUri;
//
//    // Runtime-mutable headers (e.g. Authorization token added mid-scenario).
//    private Map<String, String> sessionHeaders = new java.util.HashMap<>();
//
//    // ---------------------------------------------------------------
//    // CONSTRUCTION
//    // ---------------------------------------------------------------
//
//    /**
//     * Full constructor — use this when a base URI is known up front.
//     *
//     * @param ctx     Active scenario context (holds response, config, etc.)
//     * @param logger  Action logger for reporting; falls back to NoOp if null.
//     * @param baseUri Base URI for all requests (e.g. "https://api.example.com").
//     */
//    public WebAPI(ScenarioContext ctx, IActionLogger logger, String baseUri) {
//        this.ctx = ctx;
//        this.logger = (logger != null) ? logger : new NoOpActionLogger();
//        this.baseUri = baseUri;
//    }
//
//    /**
//     * Minimal constructor — base URI must be provided per-call or set on RestAssured globally.
//     */
//    public WebAPI(ScenarioContext ctx, IActionLogger logger) {
//        this(ctx, logger, null);
//    }
//
//    // ---------------------------------------------------------------
//    // INTERNAL HELPERS
//    // ---------------------------------------------------------------
//
//    /**
//     * Builds a fresh RequestSpecification for every request.
//     * Applies base URI (if configured), default content type, session headers, and logging filters.
//     */
//    private RequestSpecification buildRequest() {
//        RequestSpecification spec = RestAssured.given()
//                .contentType(ContentType.JSON)
//                .filter(new RequestLoggingFilter())
//                .filter(new ResponseLoggingFilter());
//
//        if (baseUri != null && !baseUri.isBlank()) {
//            spec = spec.baseUri(baseUri);
//        }
//
//        if (!sessionHeaders.isEmpty()) {
//            spec = spec.headers(sessionHeaders);
//        }
//
//        return spec;
//    }
//
//    /**
//     * Stores the last response in ScenarioContext for downstream validation steps.
//     */
//    private void storeResponse(Response response) {
//        ctx.setResponse(response);
//        LogUtils.info("Response stored — Status: " + response.getStatusCode());
//    }
//
//    // ---------------------------------------------------------------
//    // SESSION CONFIGURATION KEYWORDS
//    // ---------------------------------------------------------------
//
//    /**
//     * Merges additional headers into the current session.
//     * Existing headers are preserved; conflicting keys are overwritten.
//     * Calling this with {"Authorization": "Bearer xyz"} will NOT wipe Content-Type.
//     *
//     * @param headers Key-value map of HTTP headers.
//     */
//    public void addHeaders(Map<String, String> headers) {
//        logger.logAction("Adding headers: " + headers.keySet(), () -> {
//            sessionHeaders.putAll(headers);
//            LogUtils.info("Session headers updated: " + sessionHeaders.keySet());
//        });
//    }
//
//    /**
//     * Replaces ALL session headers with the provided map.
//     * Use this when you need a clean-slate header configuration.
//     *
//     * @param headers Key-value map of HTTP headers.
//     */
//    public void setHeaders(Map<String, String> headers) {
//        logger.logAction("Replacing all session headers", () -> {
//            sessionHeaders = new java.util.HashMap<>(headers);
//            LogUtils.info("Session headers replaced: " + sessionHeaders.keySet());
//        });
//    }
//
//    /**
//     * Clears all session headers (e.g. between independent test scenarios).
//     */
//    public void clearHeaders() {
//        logger.logAction("Clearing all session headers", () -> {
//            sessionHeaders.clear();
//            LogUtils.info("Session headers cleared.");
//        });
//    }
//
//    // ---------------------------------------------------------------
//    // HTTP METHOD KEYWORDS
//    // ---------------------------------------------------------------
//
//    /**
//     * Performs a GET request and stores the response in context.
//     *
//     * @param endpoint Full URL or path relative to baseUri.
//     */
//    public void get(String endpoint) {
//        logger.logAction("GET " + endpoint, () -> {
//            try {
//                Response response = buildRequest().get(endpoint);
//                storeResponse(response);
//            } catch (Exception e) {
//                LogUtils.error("GET request failed: " + endpoint, e);
//                Assert.fail("API GET failed for [" + endpoint + "]: " + e.getMessage());
//            }
//        });
//    }
//
//    /**
//     * Performs a POST request with a request body.
//     *
//     * @param endpoint Full URL or path relative to baseUri.
//     * @param body     Payload — accepts String, Map, or any serializable POJO.
//     */
//    public void post(String endpoint, Object body) {
//        logger.logAction("POST " + endpoint, () -> {
//            try {
//                Response response = buildRequest().body(body).post(endpoint);
//                storeResponse(response);
//            } catch (Exception e) {
//                LogUtils.error("POST request failed: " + endpoint, e);
//                Assert.fail("API POST failed for [" + endpoint + "]: " + e.getMessage());
//            }
//        });
//    }
//
//    /**
//     * Performs a PUT request to update an existing resource.
//     *
//     * @param endpoint Full URL or path relative to baseUri.
//     * @param body     Updated payload.
//     */
//    public void put(String endpoint, Object body) {
//        logger.logAction("PUT " + endpoint, () -> {
//            try {
//                Response response = buildRequest().body(body).put(endpoint);
//                storeResponse(response);
//            } catch (Exception e) {
//                LogUtils.error("PUT request failed: " + endpoint, e);
//                Assert.fail("API PUT failed for [" + endpoint + "]: " + e.getMessage());
//            }
//        });
//    }
//
//    /**
//     * Performs a DELETE request.
//     *
//     * @param endpoint Full URL or path relative to baseUri.
//     */
//    public void delete(String endpoint) {
//        logger.logAction("DELETE " + endpoint, () -> {
//            try {
//                Response response = buildRequest().delete(endpoint);
//                storeResponse(response);
//            } catch (Exception e) {
//                LogUtils.error("DELETE request failed: " + endpoint, e);
//                Assert.fail("API DELETE failed for [" + endpoint + "]: " + e.getMessage());
//            }
//        });
//    }
//
//    // ---------------------------------------------------------------
//    // VALIDATION KEYWORDS
//    // ---------------------------------------------------------------
//
//    /**
//     * Asserts the HTTP status code of the last stored response.
//     *
//     * @param expectedCode Expected HTTP status (e.g. 200, 201, 404).
//     */
//    public void verifyStatusCode(int expectedCode) {
//        logger.logAction("Verify status code is " + expectedCode, () -> {
//            Response response = ctx.getResponse();
//            Assert.assertNotNull(response, "No response found in context. Ensure an HTTP call was made first.");
//
//            int actualCode = response.getStatusCode();
//            LogUtils.info("Status — expected: " + expectedCode + ", actual: " + actualCode);
//            Assert.assertEquals(actualCode, expectedCode,
//                    "HTTP Status Code mismatch! Expected [" + expectedCode + "] but got [" + actualCode + "].");
//        });
//    }
//
//    /**
//     * Asserts a specific field value in the JSON response using GPath / JsonPath.
//     *
//     * @param jsonPath      Dot-notation path to the field (e.g. "user.id", "items[0].name").
//     * @param expectedValue Expected string value at that path.
//     */
//    public void verifyJsonField(String jsonPath, String expectedValue) {
//        logger.logAction("Verify JSON [" + jsonPath + "] == '" + expectedValue + "'", () -> {
//            Response response = ctx.getResponse();
//            Assert.assertNotNull(response, "No response found in context.");
//
//            String actualValue = response.jsonPath().getString(jsonPath);
//            LogUtils.info("JSON [" + jsonPath + "] — expected: '" + expectedValue + "', actual: '" + actualValue + "'");
//            Assert.assertEquals(actualValue, expectedValue,
//                    "JSON field mismatch at [" + jsonPath + "]. Expected '" + expectedValue + "' but got '" + actualValue + "'.");
//        });
//    }
//
//    /**
//     * Asserts that a JSON field is not null and not empty.
//     *
//     * @param jsonPath Dot-notation path to the field.
//     */
//    public void verifyJsonFieldNotEmpty(String jsonPath) {
//        logger.logAction("Verify JSON [" + jsonPath + "] is not empty", () -> {
//            Response response = ctx.getResponse();
//            Assert.assertNotNull(response, "No response found in context.");
//
//            String actualValue = response.jsonPath().getString(jsonPath);
//            Assert.assertNotNull(actualValue, "JSON field [" + jsonPath + "] was null.");
//            Assert.assertFalse(actualValue.isBlank(), "JSON field [" + jsonPath + "] was empty.");
//        });
//    }
//
//    // ---------------------------------------------------------------
//    // PRIVATE: NO-OP LOGGER
//    // ---------------------------------------------------------------
//
//    private static class NoOpActionLogger implements IActionLogger {
//        @Override
//        public <T> T logAction(String description, Supplier<T> action) {
//            return action.get();
//        }
//    }
//}