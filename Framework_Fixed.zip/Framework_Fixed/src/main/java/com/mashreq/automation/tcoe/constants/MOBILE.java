package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_TermDeposit.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class MOBILE {

    private MOBILE() {}

    // ===== Loginflow =====
    public static final String LOGINFLOW_PAGE1TITLE = "MOBILE/Loginflow/Page1title";
    public static final String LOGINFLOW_PAGE1SUBTITLE = "MOBILE/Loginflow/Page1subtitle";
    public static final String LOGINFLOW_PAGE2TITLE = "MOBILE/Loginflow/Page2title";
    public static final String LOGINFLOW_PAGE2SUBTITLE = "MOBILE/Loginflow/Page2subtitle";
    public static final String LOGINFLOW_PAGE3TITLE = "MOBILE/Loginflow/Page3title";
    public static final String LOGINFLOW_PAGE3SUBTITLE = "MOBILE/Loginflow/Page3subtitle";
    public static final String LOGINFLOW_PAGE4TITLE = "MOBILE/Loginflow/Page4title";
    public static final String LOGINFLOW_PAGE4SUBTITLE = "MOBILE/Loginflow/Page4subtitle";
    public static final String LOGINFLOW_USERID = "MOBILE/Loginflow/Userid";
    public static final String LOGINFLOW_LOGINWITHPASSWORD = "MOBILE/Loginflow/Loginwithpassword";
    public static final String LOGINFLOW_LOGIN = "MOBILE/Loginflow/Login";
    public static final String LOGINFLOW_PASSWORD = "MOBILE/Loginflow/Password";
    public static final String LOGINFLOW_FORWARDARROW = "MOBILE/Loginflow/ForwardArrow";
    public static final String LOGINFLOW_LOGIN1 = "MOBILE/Loginflow/Login1";
    public static final String LOGINFLOW_LOGINPIN = "MOBILE/Loginflow/Loginpin";
    public static final String LOGINFLOW_SETUPYOURLOGINPIN = "MOBILE/Loginflow/Setupyourloginpin";
    public static final String LOGINFLOW_CONFIRMLOGINPIN = "MOBILE/Loginflow/Confirmloginpin";
    public static final String LOGINFLOW_CONTINUE = "MOBILE/Loginflow/Continue";
    public static final String LOGINFLOW_PINCONTINUE = "MOBILE/Loginflow/PINContinue";
    public static final String LOGINFLOW_BIOMETRICSLATER = "MOBILE/Loginflow/Biometricslater";
    public static final String LOGINFLOW_LOGIN2 = "MOBILE/Loginflow/Login2";
    public static final String LOGINFLOW_LOGINWITHPIN = "MOBILE/Loginflow/LoginwithPIN";
    public static final String LOGINFLOW_ENTERSIXDIGITPIN = "MOBILE/Loginflow/EntersixdigitPIN";
    public static final String LOGINFLOW_TERMSANDCONDITION = "MOBILE/Loginflow/Termsandcondition";
    public static final String LOGINFLOW_AGREEANDCONTINUE = "MOBILE/Loginflow/Agreeandcontinue";
    public static final String LOGINFLOW_BACK = "MOBILE/Loginflow/Back";
    public static final String LOGINFLOW_BACKARROW = "MOBILE/Loginflow/Backarrow";
    public static final String LOGINFLOW_HELP = "MOBILE/Loginflow/Help";
    public static final String LOGINFLOW_LANGUAGE = "MOBILE/Loginflow/Language";
    public static final String LOGINFLOW_NEWCORPTEXT = "MOBILE/Loginflow/Newcorptext";
    public static final String LOGINFLOW_SIGINTEXT = "MOBILE/Loginflow/sigintext";
    public static final String LOGINFLOW_HELPICON = "MOBILE/Loginflow/Helpicon";
    public static final String LOGINFLOW_HELPYOU = "MOBILE/Loginflow/Helpyou";
    public static final String LOGINFLOW_PHONE = "MOBILE/Loginflow/Phone";
    public static final String LOGINFLOW_EMAIL = "MOBILE/Loginflow/Email";
    public static final String LOGINFLOW_ASKEDQUESTIONS = "MOBILE/Loginflow/Askedquestions";
    public static final String LOGINFLOW_ARROW = "MOBILE/Loginflow/Arrow";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS1 = "MOBILE/Loginflow/Frequentlyaskedquestions1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE1 = "MOBILE/Loginflow/Frequentlyaskedquestionssubtitle1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS2 = "MOBILE/Loginflow/Frequentlyaskedquestions2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE2 = "MOBILE/Loginflow/Frequentlyaskedquestionssubtitle2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS3 = "MOBILE/Loginflow/Frequentlyaskedquestions3";
    public static final String LOGINFLOW_VIEWALLFAQS = "MOBILE/Loginflow/ViewallFAQs";
    public static final String LOGINFLOW_ERRORMESSAGE = "MOBILE/Loginflow/Errormessage";

    // ===== DepositHomepage =====
    public static final String DEPOSITHOMEPAGE_DEPOSITS = "MOBILE/DepositHomepage/Deposits";
    public static final String DEPOSITHOMEPAGE_TERMWAKALADEPOSITS = "MOBILE/DepositHomepage/TermWakalaDeposits";
    public static final String DEPOSITHOMEPAGE_AEDWIDGET = "MOBILE/DepositHomepage/AEDWidget";
    public static final String DEPOSITHOMEPAGE_DEPOSITSUMMARYHEADER = "MOBILE/DepositHomepage/DepositSummaryHeader";
    public static final String DEPOSITHOMEPAGE_AEDWIDGETACCOUNT = "MOBILE/DepositHomepage/AEDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITCAROUSEL = "MOBILE/DepositHomepage/DepositCarousel";
    public static final String DEPOSITHOMEPAGE_CURRENCY = "MOBILE/DepositHomepage/Currency";
    public static final String DEPOSITHOMEPAGE_DEPOSITWIDGETCARD = "MOBILE/DepositHomepage/DepositWidgetCard";
    public static final String DEPOSITHOMEPAGE_SEARCH = "MOBILE/DepositHomepage/Search";
    public static final String DEPOSITHOMEPAGE_USDWIDGETACCOUNT = "MOBILE/DepositHomepage/USDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_USDCURRENCY = "MOBILE/DepositHomepage/USDCurrency";
    public static final String DEPOSITHOMEPAGE_BHDWIDGETACCOUNT = "MOBILE/DepositHomepage/BHDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_SEARCHFIELD = "MOBILE/DepositHomepage/SearchField";
    public static final String DEPOSITHOMEPAGE_ACCOUNTCARD = "MOBILE/DepositHomepage/AccountCard";
    public static final String DEPOSITHOMEPAGE_SEARCHTEXT = "MOBILE/DepositHomepage/SearchText";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTSTYPE = "MOBILE/DepositHomepage/ConventionalAccountsType";
    public static final String DEPOSITHOMEPAGE_SEARCHICON = "MOBILE/DepositHomepage/SearchIcon";
    public static final String DEPOSITHOMEPAGE_MATCHINGDEPOSITCARD = "MOBILE/DepositHomepage/MatchingDepositCard";
    public static final String DEPOSITHOMEPAGE_CURRENCYSEARCH = "MOBILE/DepositHomepage/CurrencySearch";
    public static final String DEPOSITHOMEPAGE_NOTERMWAKALADEPOSITSAVAILABLE = "MOBILE/DepositHomepage/NoTermWakalaDepositsAvailable";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY = "MOBILE/DepositHomepage/AEDCurrency";
    public static final String DEPOSITHOMEPAGE_CLOSECURRENCYPANEL = "MOBILE/DepositHomepage/CloseCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_SEARCHMATURITYDATE = "MOBILE/DepositHomepage/SearchMaturityDate";
    public static final String DEPOSITHOMEPAGE_SEARCHSTATUS = "MOBILE/DepositHomepage/SearchStatus";
    public static final String DEPOSITHOMEPAGE_SEARCHDATE = "MOBILE/DepositHomepage/SearchDate";
    public static final String DEPOSITHOMEPAGE_SEARCHACCOUNTNUMBER = "MOBILE/DepositHomepage/SearchAccountNumber";
    public static final String DEPOSITHOMEPAGE_DEPOSITTYPE = "MOBILE/DepositHomepage/DepositType";
    public static final String DEPOSITHOMEPAGE_AEDDEPOSITCARD = "MOBILE/DepositHomepage/AEDDepositCard";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTTYPE = "MOBILE/DepositHomepage/ConventionalAccountType";
    public static final String DEPOSITHOMEPAGE_AEDVERIFY = "MOBILE/DepositHomepage/AEDVerify";
    public static final String DEPOSITHOMEPAGE_SUMMARYLIST = "MOBILE/DepositHomepage/SummaryList";
    public static final String DEPOSITHOMEPAGE_USDACCOUNT = "MOBILE/DepositHomepage/USDAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITSTITLE = "MOBILE/DepositHomepage/DepositsTitle";
    public static final String DEPOSITHOMEPAGE_SELECTEDCURRENCY = "MOBILE/DepositHomepage/SelectedCurrency";
    public static final String DEPOSITHOMEPAGE_ACTIVEACCOUNTCOUNT = "MOBILE/DepositHomepage/ActiveAccountCount";
    public static final String DEPOSITHOMEPAGE_TOTALAVAILABLEBALANCE = "MOBILE/DepositHomepage/TotalAvailableBalance";
    public static final String DEPOSITHOMEPAGE_CURRENCYDROPDOWN = "MOBILE/DepositHomepage/CurrencyDropdown";
    public static final String DEPOSITHOMEPAGE_CURRENCYBOTTOMSHEET = "MOBILE/DepositHomepage/CurrencyBottomSheet";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY1 = "MOBILE/DepositHomepage/AEDCurrency1";
    public static final String DEPOSITHOMEPAGE_SELECTCURRENCYPANEL = "MOBILE/DepositHomepage/SelectCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCYOPTION = "MOBILE/DepositHomepage/AEDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_BHDCURRENCYOPTION = "MOBILE/DepositHomepage/BHDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDCURRENCYOPTION = "MOBILE/DepositHomepage/USDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDBALANCE = "MOBILE/DepositHomepage/USDBalance";
    public static final String DEPOSITHOMEPAGE_USDDEPOSITCARD = "MOBILE/DepositHomepage/USDDepositCard";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTCOUNT = "MOBILE/DepositHomepage/USDAccountCount";
    public static final String DEPOSITHOMEPAGE_SEARCHBAR = "MOBILE/DepositHomepage/SearchBar";
    public static final String DEPOSITHOMEPAGE_MATURITYYEAR = "MOBILE/DepositHomepage/MaturityYear";
    public static final String DEPOSITHOMEPAGE_DEPOSITBALANCE = "MOBILE/DepositHomepage/DepositBalance";
    public static final String DEPOSITHOMEPAGE_BALANCE = "MOBILE/DepositHomepage/Balance";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALTYPE = "MOBILE/DepositHomepage/ConventionalType";
    public static final String DEPOSITHOMEPAGE_PARTIALSEARCHTEXT = "MOBILE/DepositHomepage/PartialSearchText";
    public static final String DEPOSITHOMEPAGE_INVALIDSEARCHTEXT = "MOBILE/DepositHomepage/InvalidSearchText";
    public static final String DEPOSITHOMEPAGE_SEARCHPARTIALTEXT = "MOBILE/DepositHomepage/SearchPartialText";
    public static final String DEPOSITHOMEPAGE_PARTIALTEXT = "MOBILE/DepositHomepage/PartialText";
    public static final String DEPOSITHOMEPAGE_NODEPOSITFOUNDMESSAGE = "MOBILE/DepositHomepage/NoDepositFoundMessage";
    public static final String DEPOSITHOMEPAGE_NORECORDSFOUND = "MOBILE/DepositHomepage/NoRecordsFound";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTSEARCHTEXT = "MOBILE/DepositHomepage/USDAccountSearchText";

    // ===== DepositFilter =====
    public static final String DEPOSITFILTER_FILTERICON = "MOBILE/DepositFilter/FilterIcon";
    public static final String DEPOSITFILTER_FILTER = "MOBILE/DepositFilter/Filter";
    public static final String DEPOSITFILTER_FILTERSHEADER = "MOBILE/DepositFilter/FiltersHeader";
    public static final String DEPOSITFILTER_ACCOUNTTYPE = "MOBILE/DepositFilter/AccountType";
    public static final String DEPOSITFILTER_PARTYSECTIONTYPE = "MOBILE/DepositFilter/PartySectionType";
    public static final String DEPOSITFILTER_ACCOUNTTYPESECTION = "MOBILE/DepositFilter/AccountTypeSection";
    public static final String DEPOSITFILTER_PARTYSECTION = "MOBILE/DepositFilter/PartySection";
    public static final String DEPOSITFILTER_APPLYBUTTON = "MOBILE/DepositFilter/ApplyButton";
    public static final String DEPOSITFILTER_APPLY = "MOBILE/DepositFilter/Apply";
    public static final String DEPOSITFILTER_APPLYBUTTONS = "MOBILE/DepositFilter/ApplyButtons";
    public static final String DEPOSITFILTER_ISLAMIC = "MOBILE/DepositFilter/Islamic";
    public static final String DEPOSITFILTER_CONVENTIONAL = "MOBILE/DepositFilter/Conventional";
    public static final String DEPOSITFILTER_PARTYALL = "MOBILE/DepositFilter/PartyAll";
    public static final String DEPOSITFILTER_ISLAMICVERIFY = "MOBILE/DepositFilter/Islamicverify";
    public static final String DEPOSITFILTER_PARTYHEADER = "MOBILE/DepositFilter/PartyHeader";
    public static final String DEPOSITFILTER_PARTYID = "MOBILE/DepositFilter/PartyId";
    public static final String DEPOSITFILTER_PARTYIDISLAMIC = "MOBILE/DepositFilter/PartyIdIslamic";
    public static final String DEPOSITFILTER_ACCOUNTALL = "MOBILE/DepositFilter/AccountAll";
    public static final String DEPOSITFILTER_ACCOUNTTYPEALL = "MOBILE/DepositFilter/AccountTypeAll";
    public static final String DEPOSITFILTER_PARTYID1 = "MOBILE/DepositFilter/PartyId1";
    public static final String DEPOSITFILTER_NORECORD = "MOBILE/DepositFilter/NoRecord";
    public static final String DEPOSITFILTER_PARTYALLS = "MOBILE/DepositFilter/PartyAlls";

    // ===== AccountDetails =====
    public static final String ACCOUNTDETAILS_CUSTOMERID = "MOBILE/AccountDetails/CustomerID";
    public static final String ACCOUNTDETAILS_ACCOUNTCARD = "MOBILE/AccountDetails/AccountCard";
    public static final String ACCOUNTDETAILS_CUSTOMERNAME = "MOBILE/AccountDetails/CustomerName";
    public static final String ACCOUNTDETAILS_ACCOUNTNAME = "MOBILE/AccountDetails/AccountName";
    public static final String ACCOUNTDETAILS_ACCOUNTBRANCH = "MOBILE/AccountDetails/AccountBranch";

    // ===== TermWakalaDepositDetails =====
    public static final String TERMWAKALADEPOSITDETAILS_TENURE = "MOBILE/TermWakalaDepositDetails/Tenure";
    public static final String TERMWAKALADEPOSITDETAILS_VALUEDATE = "MOBILE/TermWakalaDepositDetails/ValueDate";
    public static final String TERMWAKALADEPOSITDETAILS_DEPOSITCERTIFICATENUMBER = "MOBILE/TermWakalaDepositDetails/DepositCertificateNumber";

    // ===== MaturityDetails =====
    public static final String MATURITYDETAILS_MATURITYDATE = "MOBILE/MaturityDetails/MaturityDate";
    public static final String MATURITYDETAILS_MATURITYINSTRUCTION = "MOBILE/MaturityDetails/MaturityInstruction";

}
