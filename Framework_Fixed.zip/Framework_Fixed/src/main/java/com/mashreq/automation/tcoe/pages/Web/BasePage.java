package com.mashreq.automation.tcoe.pages;

import com.mashreq.automation.tcoe.keywords.WebUI;
import com.microsoft.playwright.Page;

public abstract class BasePage {
    protected final WebUI webUi;

    protected BasePage(WebUI webUi){
        this.webUi = webUi;
    }

    protected Page page() {
        return webUi.page();
    }
}
