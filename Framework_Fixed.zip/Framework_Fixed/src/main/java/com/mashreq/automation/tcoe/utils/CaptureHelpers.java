package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.microsoft.playwright.Page;
import com.mashreq.automation.tcoe.driver.DriverManager;
import io.cucumber.java.Scenario;


import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.microsoft.playwright.Page;
import com.mashreq.automation.tcoe.driver.DriverManager;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class CaptureHelpers {

    private CaptureHelpers() {}

//    /**/**/
//     * Takes a screenshot and attaches it to the Allure report.
//     * This method is designed to be resilient and will not fail the test
//     * if a screenshot cannot be taken (e.g., if the browser is already closed).
//     *
//     * @param scenario       The current Cucumber scenario.
//     * @param screenshotName The name for the screenshot attachment.
//     * @return
//     */
//    public static String takeScreenshot(Scenario scenario, String screenshotName) {
//        try {
//            // Ensure we have a valid page object before trying to take a screenshot
//            Page page = DriverManager.getPage();
//            if (page == null || page.isClosed()) {
//                LogUtils.warn("Could not take screenshot. The page was null or already closed.");
//                return screenshotName;
//            }
//
//            final byte[] screenshot = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
//            scenario.attach(screenshot, "image/png", screenshotName);
//
//        } catch (Exception e) {
//            // Catch any Playwright exceptions during screenshotting
//            LogUtils.error("Exception occurred while taking screenshot: " + e.getMessage());
//        }
//        return screenshotName;
//    }
//
    ////    public static String takeScreenshot(Page page, String scenarioId, String screenshotName) {
    ////        try {
    ////            // If you have a real step id, pass it in; this placeholder mirrors your original code
    ////            String stepId = "1";
    ////
    ////            // Prepare folders
    ////            Path projectRoot   = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
    ////            Path reportsRoot   = projectRoot.resolve("reports");
    ////            Path screenshotsDir = reportsRoot.resolve("screenshots");
    ////            Files.createDirectories(screenshotsDir);
    ////
    ////            // Sanitize inputs
    ////            String safeScenarioId   = (scenarioId == null || scenarioId.isBlank()) ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
    ////            String safeScreenshotNm = (screenshotName == null || screenshotName.isBlank()) ? "screenshot" : screenshotName.replaceAll("[^a-zA-Z0-9._-]", "_");
    ////
    ////            // File name with timestamp
    ////            long timestamp = DateUtils.getCurrentTimeInMillis();
    ////            String fileName = String.format("%s_%s_%s_%d.png", safeScenarioId, stepId, safeScreenshotNm, timestamp);
    ////
    ////            // Destination file path
    ////            Path destinationPath = screenshotsDir.resolve(fileName);
    ////
    ////            // Take screenshot directly to destination path
    ////            page.screenshot(new Page.ScreenshotOptions().setPath(destinationPath));
    ////
    ////            // Return path relative to project root (e.g., ./reports/screenshots/...)
    ////            Path relativePath = projectRoot.relativize(destinationPath.toAbsolutePath());
    ////            return "./" + relativePath.toString().replace("\\", "/");
    ////        } catch (Exception e) {
    ////            LogUtils.error("Exception while taking screenshot: " + e.getMessage(), e);
    ////            return "";
    ////        }
    ////    }
//
    public static String takeScreenshot(Page page, String scenarioId) {
        try {
            Integer step = ScreenshotContextHolder.getStepNo();
            Integer action = ScreenshotContextHolder.getActionNo();

            if (step == null || action == null) {
                throw new IllegalStateException("Step or Action number not set in ScreenshotContextHolder.");
            }

            // Prepare folder structure
            Path projectRoot = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
            Path reportsRoot = projectRoot.resolve("reports").resolve("latest").resolve("custom-report");
            Path screenshotsDir = reportsRoot.resolve("screenshots").resolve(scenarioId);
            Files.createDirectories(screenshotsDir);

            // Sanitize scenarioId
            String safeScenarioId = (scenarioId == null || scenarioId.isBlank())
                    ? "scenario"
                    : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");

            // File name: <scenarioId>_<stepNo>_<actionNo>.png
            long currentTimeMillis = System.currentTimeMillis();
            String fileName = String.format("%s_%d_%d_%d.png", safeScenarioId, step, action, currentTimeMillis);
            Path destinationPath = screenshotsDir.resolve(fileName);

            // Capture screenshot
            page.screenshot(new Page.ScreenshotOptions().setPath(destinationPath));

            // Return relative path
            Path relativePath = projectRoot.relativize(destinationPath.toAbsolutePath());
            return "./" + relativePath.toString().replace("\\", "/");
        } catch (Exception e) {
            LogUtils.error("Exception while taking screenshot: " + e.getMessage(), e);
            return "";
        }
    }
//    public static String takeMobileScreenshot(
//            AppiumDriver driver,
//            String scenarioId) {
//
//        if (driver == null) {
//            LogUtils.warn("Skipping mobile screenshot — AppiumDriver is null.");
//            return "";
//        }
//
//        try {
//            Integer step = ScreenshotContextHolder.getStepNo();
//            Integer action = ScreenshotContextHolder.getActionNo();
//
//            int safeStep = (step != null) ? step : 0;
//            int safeAction = (action != null) ? action : 0;
//
//            byte[] screenshotBytes =
//                    ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
//
//            Path destinationPath =
//                    buildScreenshotPath(scenarioId, safeStep, safeAction);
//
//            Files.write(destinationPath, screenshotBytes);
//
//
//
//            Path relativePath = Paths.get(System.getProperty("user.dir"))
//                    .toAbsolutePath()
//                    .relativize(destinationPath.toAbsolutePath());
//
//            String result =
//                    "./" + relativePath.toString().replace("\\", "/");
//
//            LogUtils.info("Mobile screenshot saved: " + result);
//
//            return result;
//
//        } catch (Exception e) {
//            LogUtils.error(
//                    "Failed to capture mobile screenshot: "
//                            + e.getMessage(), e);
//
//            return "";
//        }
//    }

// ---------------------------------------------------------------
    // SHARED HELPERS
    // ---------------------------------------------------------------

    /**
     * Builds and creates the directory structure for a screenshot file.
     * Pattern: {projectRoot}/reports/latest/custom-report/screenshots/{scenarioId}/{scenarioId}_{step}_{action}_{ts}.png
     *
     * @param scenarioId Raw scenario ID (sanitised internally).
     * @param step       Current step number.
     * @param action     Current action number within the step.
     * @return Fully resolved {@link Path} to the target screenshot file.
     */
    private static Path buildScreenshotPath(String scenarioId, int step, int action)
            throws Exception {
        String safeId = (scenarioId == null || scenarioId.isBlank())
                ? "scenario"
                : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");

        Path projectRoot    = Paths.get(System.getProperty("user.dir")).toAbsolutePath();
        Path screenshotsDir = projectRoot
                .resolve("reports")
                .resolve("latest")
                .resolve("custom-report")
                .resolve("screenshots")
                .resolve(safeId);

        Files.createDirectories(screenshotsDir);

        String fileName = String.format("%s_%d_%d_%d.png",
                safeId, step, action, System.currentTimeMillis());

        return screenshotsDir.resolve(fileName);
    }

    public static String takeMobileScreenshot(AppiumDriver driver, String scenarioId) {
        ScenarioContext ctx = ScenarioContext.get();
        if (ctx != null && ctx.isMobileDiagnosticsSuppressed()) return "";
        if (driver == null || driver.getSessionId() == null) {
            LogUtils.warn("Skipping mobile screenshot — AppiumDriver is null.");
            return "";
        }

        try {
            Integer step   = ScreenshotContextHolder.getStepNo();
            Integer action = ScreenshotContextHolder.getActionNo();

            // Gracefully fall back to 0/0 if context hasn't been set yet
            // (e.g. screenshot triggered from a hook before any step runs).
            int safeStep   = (step   != null) ? step   : 0;
            int safeAction = (action != null) ? action : 0;

            // Appium drivers implement TakesScreenshot — cast and capture.
            byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);

            Path destinationPath = buildScreenshotPath(scenarioId, safeStep, safeAction);
            Files.write(destinationPath, screenshotBytes);

            Path relativePath = Paths.get(System.getProperty("user.dir"))
                    .toAbsolutePath()
                    .relativize(destinationPath.toAbsolutePath());
            String result = "./" + relativePath.toString().replace("\\", "/");
            LogUtils.info("Mobile screenshot saved: " + result);
            return result;

        } catch (Exception e) {
            MobileFailureSupport.diagnosticFailed(ctx, "screenshot", e);
            return "";
        }
    }

}