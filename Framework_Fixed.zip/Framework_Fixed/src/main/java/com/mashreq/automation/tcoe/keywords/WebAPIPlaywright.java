//package com.mashreq.automation.tcoe.keywords;
//
//
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.utils.LogUtils;
//import com.microsoft.playwright.APIRequestContext;
//import com.microsoft.playwright.APIResponse;
//import com.microsoft.playwright.options.RequestOptions;
//import org.testng.Assert;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.function.Supplier;
//
///**
//     * A keyword-driven engine for API interactions using Playwright APIRequestContext.
//     * This ensures consistency if you are already using Playwright for Web.
//     */
//    public final class WebAPIPlaywright {
//
//        private final IActionLogger logger;
//        private final ScenarioContext ctx;
//        private APIRequestContext requestContext;
//        private final Map<String, String> defaultHeaders = new HashMap<>();
//
//        public WebAPIPlaywright(ScenarioContext ctx, IActionLogger logger) {
//            this.ctx = ctx;
//            this.logger = (logger != null) ? logger : new NoOpActionLogger();
////            initRequestContext();
//        }
//
////        private void initRequestContext() {
////            // Explicitly cast or use the full path to avoid library clashing
////            com.microsoft.playwright.Playwright pw = ctx.getPlaywright();
////
////            this.requestContext = pw.request().newContext(
////                    new com.microsoft.playwright.APIRequest.NewContextOptions()
////                            .setBaseURL(com.mashreq.automation.tcoe.constants.FrameworkConstants.BASE_URL)
////                            .setIgnoreHTTPSErrors(true)
////            );
////        }
//
//        // ===========================================================
//        // HTTP METHODS
//        // ===========================================================
//
//    public void get(String endpoint) {
//        logger.logAction("API GET Request: " + endpoint, () -> {
//            try {
//                // 1. Prepare Headers
//                Map<String, String> myHeaders = new HashMap<>();
//                myHeaders.put("Content-Type", "application/json");
//
//                // 2. Execute Request (Using the fluent API)
//                // Ensure you are using Playwright 1.18.0+ for .setHeaders(Map)
////                APIResponse response = requestContext.get(endpoint,
////                        RequestOptions.create().setHeaders(myHeaders));
////                        com.microsoft.playwright.options.RequestOptions.create().setHeaders(myHeaders));
//                RequestOptions options = RequestOptions.create();
//                // Iterate through your map manually
//                myHeaders.forEach(options::setHeader);
//                APIResponse response = requestContext.get(endpoint, options);
//                // 3. Store in Context
//                ctx.setApiResponse(response);
//                LogUtils.info("GET Response Code: " + response.status());
//
//            } catch (Exception e) {
//                LogUtils.error("API GET failed", e);
//                Assert.fail("GET Request failed: " + e.getMessage());
//            }
//        });
//    }
//
//        public void post(String endpoint, Object body) {
//            logger.logAction("API POST Request: " + endpoint, () -> {
//                try {
////                    APIResponse response = requestContext.post(endpoint,
////                            RequestOptions.create().setData(body).setHeaders(defaultHeaders));
//                    // Fix for RequestOptions:
//                    APIResponse response = requestContext.post(endpoint,
//                            RequestOptions.create().setData(body).setHeader("Content-Type", "application/json"));
//                    ctx.setApiResponse(response);
//                    LogUtils.info("POST Response Code: " + response.status());
//                } catch (Exception e) {
//                    LogUtils.error("API POST failed", e);
//                    Assert.fail("POST Request failed: " + e.getMessage());
//                }
//            });
//        }
//
//        public void setHeaders(Map<String, String> headers) {
//            logger.logAction("Setting API Headers", () -> {
//                this.defaultHeaders.putAll(headers);
//                LogUtils.info("Headers updated: " + headers.keySet());
//            });
//        }
//
//        // ===========================================================
//        // VALIDATIONS
//        // ===========================================================
//
//        public void verifyStatusCode(int expectedCode) {
//            logger.logAction("Verify Status Code: " + expectedCode, () -> {
//                APIResponse response = ctx.getApiResponse();
//                if (response == null) Assert.fail("No API Response found in context!");
//
//                LogUtils.info("Actual Status: " + response.status());
//                Assert.assertEquals(response.status(), expectedCode, "API Status mismatch!");
//            });
//        }
//
//        /**
//         * Verifies a value in the JSON response.
//         * Note: Playwright requires manual parsing or a library like Jackson/Gson
//         * since it doesn't have GPath like RestAssured.
//         */
//        public void verifyResponseField(String jsonPath, String expectedValue) {
//            logger.logAction("Verify Response Field [" + jsonPath + "]", () -> {
//                try {
//                    String responseBody = ctx.getApiResponse().text();
//                    // You would typically use com.jayway.jsonpath.JsonPath here
//                    String actualValue = com.jayway.jsonpath.JsonPath.read(responseBody, jsonPath).toString();
//                    Assert.assertEquals(actualValue, expectedValue);
//                } catch (Exception e) {
//                    Assert.fail("Failed to parse or verify JSON field: " + e.getMessage());
//                }
//            });
//        }
//
//    // --- PRIVATE INNER CLASS FOR NO-OP LOGGING ---
//
//    /**
//     * A private static inner class that provides a default, "do nothing" implementation
//     * of the IActionLogger. It simply executes the action without any reporting.
//     */
//    private static class NoOpActionLogger implements IActionLogger {
//        @Override
//        public <T> T logAction(String description, Supplier<T> action) {
//            // Simply execute the action and return its result.
//            return action.get();
//        }
//    }
//    }
//
