package com.mashreq.automation.tcoe.driver;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.openqa.selenium.remote.http.*;
import java.net.URL;
import java.nio.file.*;
import java.time.Duration;
import java.util.Map;

/** Result reporting through the account API, independent of the Appium session connection. */
final class BrowserStackResultReporter {
    private BrowserStackResultReporter() {}

    static boolean update(ClientConfig config, String session, boolean passed, String reason) throws Exception {
        if (session == null || !session.matches("[A-Za-z0-9-]+"))
            throw new IllegalArgumentException("Invalid BrowserStack session identifier");
        String json = new ObjectMapper().writeValueAsString(Map.of("status", passed ? "passed" : "failed", "reason", reason));
        try (HttpClient client = HttpClient.Factory.createDefault().createClient(config)) {
            HttpRequest request = new HttpRequest(HttpMethod.PUT, "/app-automate/sessions/" + session + ".json");
            request.setHeader("Content-Type", "application/json");
            request.setContent(Contents.utf8String(json));
            HttpResponse response = client.execute(request);
            if (response.getStatus() < 200 || response.getStatus() >= 300)
                throw new IllegalStateException("BrowserStack result API returned HTTP " + response.getStatus());
            return true;
        }
    }

    static ClientConfig config() throws Exception {
        ClientConfig config = MobileDriverManager.withCredentials(ClientConfig.defaultConfig()
                .baseUrl(new URL("https://api-cloud.browserstack.com"))
                .connectionTimeout(Duration.ofSeconds(10)).readTimeout(Duration.ofSeconds(15)),
                com.mashreq.automation.tcoe.constants.FrameworkConstants.BROWSERSTACK_USERNAME,
                com.mashreq.automation.tcoe.constants.FrameworkConstants.BROWSERSTACK_ACCESS_KEY);
        java.net.Proxy proxy = MobileDriverManager.getBrowserStackProxy();
        return proxy == null ? config : config.proxy(proxy);
    }

    static void journal(String session, boolean passed, String reason, boolean confirmed, String channel) throws Exception {
        Path directory = Paths.get("target", "browserstack-status");
        Files.createDirectories(directory);
        Path temporary = Files.createTempFile(directory, "result-", ".tmp");
        try {
            new ObjectMapper().writeValue(temporary.toFile(), Map.of("sessionId", session,
                    "status", passed ? "passed" : "failed", "reason", reason,
                    "confirmed", confirmed, "channel", channel, "recordedAt", java.time.Instant.now().toString()));
            Files.move(temporary, directory.resolve(session + ".json"), StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temporary); }
    }
}
