package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.function.Supplier;

/** Scenario-owned failure state. Diagnostic failures never replace the initiating failure. */
public final class MobileFailureSupport {
    public enum Kind { SETUP_FAILURE, LOCATOR_TIMEOUT, LOCATOR_ERROR, TRANSPORT_TIMEOUT,
        TRANSPORT_FAILURE, INVALID_SESSION, ACTION_FAILURE }

    private MobileFailureSupport() { }

    public static Kind classify(Throwable error) {
        Set<Throwable> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        boolean timeout = false;
        boolean locator = false;
        boolean setup = false;
        boolean transport = false;
        boolean transportTimeout = false;
        for (Throwable cause = error; cause != null && seen.add(cause); cause = cause.getCause()) {
            String type = SafeDiagnostics.typeName(cause);
            if (type.endsWith("NoSuchSessionException")) return Kind.INVALID_SESSION;
            if (type.endsWith("SessionNotCreatedException")) setup = true;
            if (type.equals("java.util.concurrent.TimeoutException") || type.endsWith("SocketTimeoutException")
                    || type.endsWith("HttpTimeoutException")) transportTimeout = true;
            if (type.endsWith("UnreachableBrowserException") || (type.startsWith("java.io.") && type.endsWith("IOException"))
                    || type.endsWith("UncheckedIOException")) transport = true;
            if (type.endsWith("TimeoutException")) timeout = true;
            if (type.endsWith("NoSuchElementException") || type.endsWith("InvalidSelectorException")) locator = true;
        }
        if (transportTimeout) return Kind.TRANSPORT_TIMEOUT;
        if (transport) return Kind.TRANSPORT_FAILURE;
        if (setup) return Kind.SETUP_FAILURE;
        if (timeout) return Kind.LOCATOR_TIMEOUT;
        return locator ? Kind.LOCATOR_ERROR : Kind.ACTION_FAILURE;
    }

    public static void record(ScenarioContext ctx, String operation, Throwable error) {
        if (ctx == null || !ctx.isMobileScenario()) return;
        Kind kind = classify(error);
        if (kind == Kind.TRANSPORT_FAILURE || kind == Kind.TRANSPORT_TIMEOUT
                || kind == Kind.INVALID_SESSION || kind == Kind.SETUP_FAILURE) {
            ctx.setMobileSessionUsable(false);
            ctx.setMobileDiagnosticsSuppressed(true);
        }
        if (ctx.getMobileFailure() == null) {
            ctx.setMobileFailure(SafeDiagnostics.sanitized(error));
            ctx.setMobileFailureCategory(kind.name());
            LogUtils.error("Mobile failure [category=" + kind + ", scenario=" + ctx.getScenarioId()
                    + ", thread=" + Thread.currentThread().getName() + ", operation=" + operation + "]", error);
        }
    }

    public static void optionalLookupFailed(ScenarioContext ctx, Throwable error) {
        Kind kind = classify(error);
        if (kind == Kind.LOCATOR_TIMEOUT || kind == Kind.LOCATOR_ERROR) return;
        record(ctx, "optional lookup", error);
        throw new RuntimeException("Optional lookup failed [category=" + kind + "]", error);
    }

    public static void recordSetup(ScenarioContext ctx, Throwable error) {
        record(ctx, "session creation", new org.openqa.selenium.SessionNotCreatedException(
                "Mobile session setup failed", error));
        if (ctx != null) {
            ctx.setMobileSessionUsable(false);
            ctx.setMobileDiagnosticsSuppressed(true);
        }
    }

    public static String captureFailure(ScenarioContext ctx) {
        if (ctx == null) return "";
        return captureFailure(ctx, () -> CaptureHelpers.takeMobileScreenshot(ctx.getMobileDriver(), ctx.getScenarioId()));
    }

    public static String captureFailure(ScenarioContext ctx, Supplier<String> capture) {
        if (ctx == null || !ctx.isMobileScenario() || ctx.isMobileFailureScreenshotAttempted()
                || ctx.isMobileDiagnosticsSuppressed() || !ctx.isMobileSessionUsable()) return "";
        ctx.setMobileFailureScreenshotAttempted(true);
        try {
            String path = capture.get();
            return path == null ? "" : path;
        } catch (Exception error) {
            diagnosticFailed(ctx, "failure screenshot", error);
            return "";
        }
    }

    public static void diagnosticFailed(ScenarioContext ctx, String operation, Throwable error) {
        // A failed screenshot can be transient: suppress further diagnostics, but permit UI commands.
        if (ctx != null && ctx.isMobileDiagnosticsSuppressed()) return;
        if (ctx != null) ctx.setMobileDiagnosticsSuppressed(true);
        LogUtils.warn("Mobile diagnostic failed [operation=" + operation + ", category=" + classify(error)
                + "]: " + SafeDiagnostics.stackTrace(error));
    }
}
