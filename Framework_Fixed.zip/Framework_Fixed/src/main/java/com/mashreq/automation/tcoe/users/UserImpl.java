package com.mashreq.automation.tcoe.users;

public class UserImpl extends User {
}
