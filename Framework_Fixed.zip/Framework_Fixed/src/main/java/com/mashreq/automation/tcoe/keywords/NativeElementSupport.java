package com.mashreq.automation.tcoe.keywords;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/** Native phone/tablet operations; no web context or coordinate assumptions. */
public final class NativeElementSupport {
    private NativeElementSupport() {}

    public static By locator(String locator) {
        if (locator == null || locator.isBlank()) throw new IllegalArgumentException("Locator must not be blank");
        int separator = locator.indexOf('|');
        // Raw XPath can contain union operators.
        if (separator < 0 || locator.startsWith("/") || locator.startsWith("(")) return AppiumBy.xpath(locator);
        String strategy = locator.substring(0, separator).trim().toLowerCase(java.util.Locale.ROOT);
        String value = locator.substring(separator + 1);
        if (value.isBlank()) throw new IllegalArgumentException("Locator value must not be blank");
        switch (strategy) {
            case "xpath": return AppiumBy.xpath(value);
            case "id": return AppiumBy.id(value);
            case "accessibility": case "accessibilityid": return AppiumBy.accessibilityId(value);
            case "class": return AppiumBy.className(value);
            case "iospredicate": case "-ios predicate string": return AppiumBy.iOSNsPredicateString(value);
            case "iosclasschain": case "-ios class chain": return AppiumBy.iOSClassChain(value);
            case "androiduiautomator": return AppiumBy.androidUIAutomator(value);
            default: throw new IllegalArgumentException("Unknown locator strategy: " + strategy);
        }
    }

    public static String text(WebElement element, boolean ios) {
        if (ios) {
            String type = element.getAttribute("type");
            if (type != null && (type.contains("TextField") || type.contains("TextView"))) {
                String value = element.getAttribute("value");
                return value == null ? "" : value;
            }
        }
        String text = element.getText();
        if (text != null && !text.isEmpty()) return text;
        String attribute = element.getAttribute(ios ? "label" : "text");
        return attribute == null ? "" : attribute;
    }

    public static void replace(WebElement element, String text, boolean ios) {
        if (text == null) throw new IllegalArgumentException("Input text must not be null");
        String phase = "inspect input";
        try {
            if (ios) {
                String type = element.getAttribute("type");
                if (type == null || !(type.contains("TextField") || type.contains("TextView")))
                    throw new IllegalArgumentException("iOS typing requires a text field/text view; selected type=" + type);
            }
            phase = "focus";
            element.click();
            phase = "clear";
            element.clear();
            phase = "type";
            if (!text.isEmpty()) element.sendKeys(text);
        } catch (Exception failure) {
            // Never replay typing after an ambiguous remote failure: it can duplicate input.
            throw new IllegalStateException("Native input failed during " + phase, failure);
        }
    }
}
