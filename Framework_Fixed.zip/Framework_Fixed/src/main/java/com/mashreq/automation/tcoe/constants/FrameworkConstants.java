package com.mashreq.automation.tcoe.constants;

/**
 * FrameworkConstants holds all the constant values used across the automation framework.
 * This helps in avoiding hard-coded "magic strings" and provides a single point of
 * maintenance for these values.
 */

import com.mashreq.automation.tcoe.utils.PropertiesHelpers;
import com.mashreq.automation.tcoe.utils.SystemHelpers;
import lombok.Getter;

import java.io.File;

/**
 * FrameworkConstants holds all the constant, unchanging values used across the framework.
 * This provides a single point of maintenance for these values.
 * Dynamic configuration values should be handled by the ConfigFactory.
 */
@Getter // Lombok annotation to automatically generate public static getters for all private static fields.
public final class FrameworkConstants {

    /**
     * Private constructor to prevent instantiation of this utility class.
     */
    private FrameworkConstants() {}

    static {
        PropertiesHelpers.loadAllFiles();
    }

    // Let -DENV / -DREGION override file values
    public static final String ENV = System.getProperty("ENV", PropertiesHelpers.getValue("ENV"));
    public static final String REGION = System.getProperty("REGION", PropertiesHelpers.getValue("REGION"));

    /** Get base URL based on merged System.getPropertys: urls-<ENV>.System.getPropertyerties supplies url.<REGION> */
    public static String getBaseUrl(String application) {
        String key = "url." + REGION + "."+ application;                  // e.g. url.US
        String url = PropertiesHelpers.getValue(key);  // comes from urls-<ENV>.System.getPropertyerties
        if (url == null || url.isBlank()) {
            // optional: fallback to legacy single URL if present
            url = PropertiesHelpers.getValue("URL");
        }
        if (url == null || url.isBlank()) {
            throw new IllegalStateException("No URL resolved for key '" + key +
                    "' (ENV=" + ENV + ", REGION=" + REGION + "). Check urls-" + ENV + ".System.getPropertyerties.");
        }
        return url.trim();
    }

    /** Returns the trimmed value of an optional key, or "" when it is absent (never null). */
    private static String optionalValue(String key) {
        return PropertiesHelpers.getOptionalValue(key, "");
    }

    /**
     * Fails fast, with one clear message, when BrowserStack settings are missing.
     * Called before a BrowserStack session is requested so that web/local runs are not affected.
     */
    public static void validateBrowserStackConfig() {
        java.util.List<String> missing = new java.util.ArrayList<>();
        if (BROWSERSTACK_USERNAME.isEmpty()) missing.add("BROWSERSTACK_USERNAME");
        if (BROWSERSTACK_ACCESS_KEY.isEmpty()) missing.add("BROWSERSTACK_ACCESS_KEY");
        if (BROWSERSTACK_APP_URL.isEmpty()) missing.add("BROWSERSTACK_APP_URL");
        if (BS_DEVICE_NAME.isEmpty()) missing.add("BS_DEVICE_NAME");
        if (BS_OS_VERSION.isEmpty()) missing.add("BS_OS_VERSION");
        if (!missing.isEmpty()) {
            throw new IllegalStateException("BrowserStack run requested but these settings are missing or empty: "
                    + String.join(", ", missing) + ". Set them in config.properties or pass -D<KEY>=<value>.");
        }
    }

    // ---------------- Timeout Constants (in milliseconds) ----------------
    public static final int WAIT_SHORT_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("WAIT_SHORT_SECONDS")) * 1000;
    public static final int WAIT_MEDIUM_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("WAIT_MEDIUM_SECONDS")) * 1000;
    public static final int WAIT_LONG_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("WAIT_LONG_SECONDS")) * 1000;

    public static final int DEFAULT_TIMEOUT_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("DEFAULT_TIMEOUT_SECONDS")) * 1000;
    public static final int DEFAULT_DOWNLOAD_TIMEOUT_MS = Integer.parseInt(PropertiesHelpers.getRequiredValue("DEFAULT_DOWNLOAD_TIMEOUT_SECONDS")) * 1000;


    // ---------------- Environment & Project Info ----------------
    private static final String PROJECT_PATH = System.getProperty("user.dir");
    private static final String CONFIG_PROPERTIES_PATH = PROJECT_PATH + "/src/test/resources/config/config.System.getPropertyerties";
    private static final String ALLURE_CONFIG_PATH = PROJECT_PATH + "/src/test/resources/config/allure/";
    private static final String EXTENT_REPORT_FOLDER_PATH = PROJECT_PATH + "/reports/latest/";
    public static final String OBJECT_REPO_PATH = PROJECT_PATH + "/src/main/resources/objectrepo/Mobile";
    public static final String TEST_DATA_PATH = PROJECT_PATH + "/testdata/";
    public static final String PROJECT_NAME = PropertiesHelpers.getRequiredValue("PROJECT_NAME");
    public static final String OS_NAME = System.getProperty("os.name");

    // ---------------- Browser Configuration ----------------
    public static final String BROWSER = PropertiesHelpers.getRequiredValue("BROWSER");
    public static final boolean HEADLESS = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("HEADLESS"));
    public static final boolean INCOGNITO = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("INCOGNITO"));

    public static String getBrowserInfo() {
        return (BROWSER == null || BROWSER.trim().isEmpty()) ? "CHROME" : BROWSER.toUpperCase();
    }
    // ===========================================================
    // MOBILE CONFIGURATIONS (Appium) — all driven from config.System.getPropertyerties
    // Override any value at runtime with a -D system System.getPropertyerty, e.g.:
    //   -DMOBILE_EXECUTION_MODE=browserstack  -DMOBILE_PLATFORM=ios
    // ===========================================================

    // Execution target: local | browserstack
    public static final String MOBILE_EXECUTION_MODE = PropertiesHelpers.getRequiredValue("MOBILE_EXECUTION_MODE");

    // Platform: android | ios
    public static final String MOBILE_PLATFORM = PropertiesHelpers.getRequiredValue("MOBILE_PLATFORM");

    // ---- Local device ----
    public static final String APPIUM_SERVER_URL = PropertiesHelpers.getValue("APPIUM_SERVER_URL");
    public static final String DEVICE_NAME = PropertiesHelpers.getValue("DEVICE_NAME");
    public static final String DEVICE_UDID = PropertiesHelpers.getValue("DEVICE_UDID");
    public static final String PLATFORM_VERSION = PropertiesHelpers.getRequiredValue("PLATFORM_VERSION");

    // ---- Android ----
    public static final String APP_PACKAGE = PropertiesHelpers.getRequiredValue("APP_PACKAGE");
    public static final String APP_ACTIVITY = PropertiesHelpers.getRequiredValue("APP_ACTIVITY");
    public static final String ANDROID_APP_PATH   = PROJECT_PATH + "/" + System.getProperty("ANDROID_APP_PATH", "");

    // ---- iOS ----
    public static final String IOS_APP_PATH       = PROJECT_PATH + "/" + System.getProperty("IOS_APP_PATH", "");

    // ---- BrowserStack ----
    public static final String BROWSERSTACK_USERNAME = optionalValue("BROWSERSTACK_USERNAME");
    public static final String BROWSERSTACK_ACCESS_KEY = optionalValue("BROWSERSTACK_ACCESS_KEY");
    public static final String BROWSERSTACK_APP_URL = optionalValue("BROWSERSTACK_APP_URL");
    public static final String BS_DEVICE_NAME = optionalValue("BS_DEVICE_NAME");
    public static final String BS_OS_VERSION = optionalValue("BS_OS_VERSION");
    public static final String BS_PROJECT = optionalValue("BS_PROJECT");
    public static final String BS_BUILD = optionalValue("BS_BUILD");
    public static final String BS_TEST_NAME = optionalValue("BS_TEST_NAME");
    public static final String BS_PROXY_HOST = optionalValue("BS_PROXY_HOST");
    public static final String BS_PROXY_PORT = optionalValue("BS_PROXY_PORT");

    // Fix for BASE_URL: Add this to FrameworkConstants.java
    public static final String BASE_URL = "https://api.example.com";
    // ---------------- Report Configuration ----------------
    public static final int REPORT_BACKUP_COUNT = Integer.parseInt(PropertiesHelpers.getRequiredValue("REPORT_BACKUP_COUNT"));
    public static final String REPORT_BASE_FOLDER_NAME = "reports/latest";
    public static final String REPORT_BACKUP_BASE_FOLDER_NAME = "reports/history";
    public static final String LOGS_BASE_FOLDER_NAME = "logs/latest";
    public static final String LOGS_BACKUP_BASE_FOLDER_NAME = "logs/backup";
    public static final int LOGS_BACKUP_COUNT = Integer.parseInt(PropertiesHelpers.getRequiredValue("LOGS_BACKUP_COUNT"));

    // ---------------- UI/Visual Settings ----------------
    public static final boolean HIGHLIGHT = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("HIGHLIGHT"));
    public static final String LOCALE = PropertiesHelpers.getRequiredValue("LOCALE");
    public static final String DATE_FORMAT = PropertiesHelpers.getRequiredValue("DATE_FORMAT");

    // ---------------- Test Options ----------------
    public static final boolean VIDEO_RECORD = Boolean.parseBoolean(PropertiesHelpers.getRequiredValue("VIDEO_RECORD"));

    // --- PROJECT & FOLDER PATHS ---
    // Using System.getProperty("user.dir") makes paths reliable and machine-independent.




    // --- YES / NO CONSTANTS ---
    // Used for consistent string comparisons, e.g., if (config.deleteOldReports().equalsIgnoreCase(YES))
    public static final String YES = "yes";
    public static final String NO = "no";

    // --- REPORTING ICONS (A great practice for beautiful reports) ---
    public static final String ICON_BUG = "<i class='fa fa-bug'></i>";
    public static final String ICON_OS_WINDOWS = "<i class='fa fa-windows'></i>";
    public static final String ICON_OS_MAC = "<i class='fa fa-apple'></i>";
    public static final String ICON_BROWSER_CHROME = "<i class='fa fa-chrome'></i>";
    public static final String ICON_BROWSER_FIREFOX = "<i class='fa fa-firefox'></i>";
    public static final String ICON_BROWSER_EDGE = "<i class='fa fa-edge'></i>";

    public static String getExtentReportFolderPath() {
        return EXTENT_REPORT_FOLDER_PATH;
    }
}
