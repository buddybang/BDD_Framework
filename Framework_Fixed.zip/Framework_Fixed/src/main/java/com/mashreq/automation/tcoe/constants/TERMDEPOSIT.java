package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_TermDeposit.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class TERMDEPOSIT {

    private TERMDEPOSIT() {}

    // ===== Loginflow =====
    public static final String LOGINFLOW_PAGE1TITLE = "TERMDEPOSIT/Loginflow/Page1title";
    public static final String LOGINFLOW_PAGE1SUBTITLE = "TERMDEPOSIT/Loginflow/Page1subtitle";
    public static final String LOGINFLOW_PAGE2TITLE = "TERMDEPOSIT/Loginflow/Page2title";
    public static final String LOGINFLOW_PAGE2SUBTITLE = "TERMDEPOSIT/Loginflow/Page2subtitle";
    public static final String LOGINFLOW_PAGE3TITLE = "TERMDEPOSIT/Loginflow/Page3title";
    public static final String LOGINFLOW_PAGE3SUBTITLE = "TERMDEPOSIT/Loginflow/Page3subtitle";
    public static final String LOGINFLOW_PAGE4TITLE = "TERMDEPOSIT/Loginflow/Page4title";
    public static final String LOGINFLOW_PAGE4SUBTITLE = "TERMDEPOSIT/Loginflow/Page4subtitle";
    public static final String LOGINFLOW_USERID = "TERMDEPOSIT/Loginflow/Userid";
    public static final String LOGINFLOW_LOGINWITHPASSWORD = "TERMDEPOSIT/Loginflow/Loginwithpassword";
    public static final String LOGINFLOW_LOGIN = "TERMDEPOSIT/Loginflow/Login";
    public static final String LOGINFLOW_PASSWORD = "TERMDEPOSIT/Loginflow/Password";
    public static final String LOGINFLOW_FORWARDARROW = "TERMDEPOSIT/Loginflow/ForwardArrow";
    public static final String LOGINFLOW_LOGIN1 = "TERMDEPOSIT/Loginflow/Login1";
    public static final String LOGINFLOW_LOGINPIN = "TERMDEPOSIT/Loginflow/Loginpin";
    public static final String LOGINFLOW_SETUPYOURLOGINPIN = "TERMDEPOSIT/Loginflow/Setupyourloginpin";
    public static final String LOGINFLOW_CONFIRMLOGINPIN = "TERMDEPOSIT/Loginflow/Confirmloginpin";
    public static final String LOGINFLOW_CONTINUE = "TERMDEPOSIT/Loginflow/Continue";
    public static final String LOGINFLOW_PINCONTINUE = "TERMDEPOSIT/Loginflow/PINContinue";
    public static final String LOGINFLOW_BIOMETRICSLATER = "TERMDEPOSIT/Loginflow/Biometricslater";
    public static final String LOGINFLOW_LOGIN2 = "TERMDEPOSIT/Loginflow/Login2";
    public static final String LOGINFLOW_LOGINWITHPIN = "TERMDEPOSIT/Loginflow/LoginwithPIN";
    public static final String LOGINFLOW_ENTERSIXDIGITPIN = "TERMDEPOSIT/Loginflow/EntersixdigitPIN";
    public static final String LOGINFLOW_TERMSANDCONDITION = "TERMDEPOSIT/Loginflow/Termsandcondition";
    public static final String LOGINFLOW_AGREEANDCONTINUE = "TERMDEPOSIT/Loginflow/Agreeandcontinue";
    public static final String LOGINFLOW_BACK = "TERMDEPOSIT/Loginflow/Back";
    public static final String LOGINFLOW_BACKARROW = "TERMDEPOSIT/Loginflow/Backarrow";
    public static final String LOGINFLOW_HELP = "TERMDEPOSIT/Loginflow/Help";
    public static final String LOGINFLOW_LANGUAGE = "TERMDEPOSIT/Loginflow/Language";
    public static final String LOGINFLOW_NEWCORPTEXT = "TERMDEPOSIT/Loginflow/Newcorptext";
    public static final String LOGINFLOW_SIGINTEXT = "TERMDEPOSIT/Loginflow/sigintext";
    public static final String LOGINFLOW_HELPICON = "TERMDEPOSIT/Loginflow/Helpicon";
    public static final String LOGINFLOW_HELPYOU = "TERMDEPOSIT/Loginflow/Helpyou";
    public static final String LOGINFLOW_PHONE = "TERMDEPOSIT/Loginflow/Phone";
    public static final String LOGINFLOW_EMAIL = "TERMDEPOSIT/Loginflow/Email";
    public static final String LOGINFLOW_ASKEDQUESTIONS = "TERMDEPOSIT/Loginflow/Askedquestions";
    public static final String LOGINFLOW_ARROW = "TERMDEPOSIT/Loginflow/Arrow";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS1 = "TERMDEPOSIT/Loginflow/Frequentlyaskedquestions1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE1 = "TERMDEPOSIT/Loginflow/Frequentlyaskedquestionssubtitle1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS2 = "TERMDEPOSIT/Loginflow/Frequentlyaskedquestions2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE2 = "TERMDEPOSIT/Loginflow/Frequentlyaskedquestionssubtitle2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS3 = "TERMDEPOSIT/Loginflow/Frequentlyaskedquestions3";
    public static final String LOGINFLOW_VIEWALLFAQS = "TERMDEPOSIT/Loginflow/ViewallFAQs";
    public static final String LOGINFLOW_ERRORMESSAGE = "TERMDEPOSIT/Loginflow/Errormessage";

    // ===== DepositHomepage =====
    public static final String DEPOSITHOMEPAGE_DEPOSITS = "TERMDEPOSIT/DepositHomepage/Deposits";
    public static final String DEPOSITHOMEPAGE_TERMWAKALADEPOSITS = "TERMDEPOSIT/DepositHomepage/TermWakalaDeposits";
    public static final String DEPOSITHOMEPAGE_AEDWIDGET = "TERMDEPOSIT/DepositHomepage/AEDWidget";
    public static final String DEPOSITHOMEPAGE_DEPOSITSUMMARYHEADER = "TERMDEPOSIT/DepositHomepage/DepositSummaryHeader";
    public static final String DEPOSITHOMEPAGE_AEDWIDGETACCOUNT = "TERMDEPOSIT/DepositHomepage/AEDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITCAROUSEL = "TERMDEPOSIT/DepositHomepage/DepositCarousel";
    public static final String DEPOSITHOMEPAGE_CURRENCY = "TERMDEPOSIT/DepositHomepage/Currency";
    public static final String DEPOSITHOMEPAGE_DEPOSITWIDGETCARD = "TERMDEPOSIT/DepositHomepage/DepositWidgetCard";
    public static final String DEPOSITHOMEPAGE_SEARCH = "TERMDEPOSIT/DepositHomepage/Search";
    public static final String DEPOSITHOMEPAGE_USDWIDGETACCOUNT = "TERMDEPOSIT/DepositHomepage/USDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_USDCURRENCY = "TERMDEPOSIT/DepositHomepage/USDCurrency";
    public static final String DEPOSITHOMEPAGE_BHDWIDGETACCOUNT = "TERMDEPOSIT/DepositHomepage/BHDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_SEARCHFIELD = "TERMDEPOSIT/DepositHomepage/SearchField";
    public static final String DEPOSITHOMEPAGE_ACCOUNTCARD = "TERMDEPOSIT/DepositHomepage/AccountCard";
    public static final String DEPOSITHOMEPAGE_SEARCHTEXT = "TERMDEPOSIT/DepositHomepage/SearchText";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTNUMBER = "TERMDEPOSIT/DepositHomepage/USDAccountNumber";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTSTYPE = "TERMDEPOSIT/DepositHomepage/ConventionalAccountsType";
    public static final String DEPOSITHOMEPAGE_SEARCHICON = "TERMDEPOSIT/DepositHomepage/SearchIcon";
    public static final String DEPOSITHOMEPAGE_MATCHINGDEPOSITCARD = "TERMDEPOSIT/DepositHomepage/MatchingDepositCard";
    public static final String DEPOSITHOMEPAGE_CURRENCYSEARCH = "TERMDEPOSIT/DepositHomepage/CurrencySearch";
    public static final String DEPOSITHOMEPAGE_NOTERMWAKALADEPOSITSAVAILABLE = "TERMDEPOSIT/DepositHomepage/NoTermWakalaDepositsAvailable";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY = "TERMDEPOSIT/DepositHomepage/AEDCurrency";
    public static final String DEPOSITHOMEPAGE_CLOSECURRENCYPANEL = "TERMDEPOSIT/DepositHomepage/CloseCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_SEARCHMATURITYDATE = "TERMDEPOSIT/DepositHomepage/SearchMaturityDate";
    public static final String DEPOSITHOMEPAGE_SEARCHSTATUS = "TERMDEPOSIT/DepositHomepage/SearchStatus";
    public static final String DEPOSITHOMEPAGE_SEARCHDATE = "TERMDEPOSIT/DepositHomepage/SearchDate";
    public static final String DEPOSITHOMEPAGE_SEARCHACCOUNTNUMBER = "TERMDEPOSIT/DepositHomepage/SearchAccountNumber";
    public static final String DEPOSITHOMEPAGE_DEPOSITTYPE = "TERMDEPOSIT/DepositHomepage/DepositType";
    public static final String DEPOSITHOMEPAGE_AEDDEPOSITCARD = "TERMDEPOSIT/DepositHomepage/AEDDepositCard";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTTYPE = "TERMDEPOSIT/DepositHomepage/ConventionalAccountType";
    public static final String DEPOSITHOMEPAGE_AEDVERIFY = "TERMDEPOSIT/DepositHomepage/AEDVerify";
    public static final String DEPOSITHOMEPAGE_SUMMARYLIST = "TERMDEPOSIT/DepositHomepage/SummaryList";
    public static final String DEPOSITHOMEPAGE_USDACCOUNT = "TERMDEPOSIT/DepositHomepage/USDAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITSTITLE = "TERMDEPOSIT/DepositHomepage/DepositsTitle";
    public static final String DEPOSITHOMEPAGE_SELECTEDCURRENCY = "TERMDEPOSIT/DepositHomepage/SelectedCurrency";
    public static final String DEPOSITHOMEPAGE_ACTIVEACCOUNTCOUNT = "TERMDEPOSIT/DepositHomepage/ActiveAccountCount";
    public static final String DEPOSITHOMEPAGE_TOTALAVAILABLEBALANCE = "TERMDEPOSIT/DepositHomepage/TotalAvailableBalance";
    public static final String DEPOSITHOMEPAGE_CURRENCYDROPDOWN = "TERMDEPOSIT/DepositHomepage/CurrencyDropdown";
    public static final String DEPOSITHOMEPAGE_CURRENCYBOTTOMSHEET = "TERMDEPOSIT/DepositHomepage/CurrencyBottomSheet";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY1 = "TERMDEPOSIT/DepositHomepage/AEDCurrency1";
    public static final String DEPOSITHOMEPAGE_SELECTCURRENCYPANEL = "TERMDEPOSIT/DepositHomepage/SelectCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCYOPTION = "TERMDEPOSIT/DepositHomepage/AEDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_BHDCURRENCYOPTION = "TERMDEPOSIT/DepositHomepage/BHDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDCURRENCYOPTION = "TERMDEPOSIT/DepositHomepage/USDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDBALANCE = "TERMDEPOSIT/DepositHomepage/USDBalance";
    public static final String DEPOSITHOMEPAGE_USDDEPOSITCARD = "TERMDEPOSIT/DepositHomepage/USDDepositCard";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTCOUNT = "TERMDEPOSIT/DepositHomepage/USDAccountCount";
    public static final String DEPOSITHOMEPAGE_SEARCHBAR = "TERMDEPOSIT/DepositHomepage/SearchBar";
    public static final String DEPOSITHOMEPAGE_MATURITYYEAR = "TERMDEPOSIT/DepositHomepage/MaturityYear";
    public static final String DEPOSITHOMEPAGE_DEPOSITBALANCE = "TERMDEPOSIT/DepositHomepage/DepositBalance";
    public static final String DEPOSITHOMEPAGE_BALANCE = "TERMDEPOSIT/DepositHomepage/Balance";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALTYPE = "TERMDEPOSIT/DepositHomepage/ConventionalType";
    public static final String DEPOSITHOMEPAGE_PARTIALSEARCHTEXT = "TERMDEPOSIT/DepositHomepage/PartialSearchText";
    public static final String DEPOSITHOMEPAGE_INVALIDSEARCHTEXT = "TERMDEPOSIT/DepositHomepage/InvalidSearchText";
    public static final String DEPOSITHOMEPAGE_SEARCHPARTIALTEXT = "TERMDEPOSIT/DepositHomepage/SearchPartialText";
    public static final String DEPOSITHOMEPAGE_PARTIALTEXT = "TERMDEPOSIT/DepositHomepage/PartialText";
    public static final String DEPOSITHOMEPAGE_NODEPOSITFOUNDMESSAGE = "TERMDEPOSIT/DepositHomepage/NoDepositFoundMessage";
    public static final String DEPOSITHOMEPAGE_NORECORDSFOUND = "TERMDEPOSIT/DepositHomepage/NoRecordsFound";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTSEARCHTEXT = "TERMDEPOSIT/DepositHomepage/USDAccountSearchText";

    // ===== DepositFilter =====
    public static final String DEPOSITFILTER_FILTERICON = "TERMDEPOSIT/DepositFilter/FilterIcon";
    public static final String DEPOSITFILTER_FILTER = "TERMDEPOSIT/DepositFilter/Filter";
    public static final String DEPOSITFILTER_FILTERSHEADER = "TERMDEPOSIT/DepositFilter/FiltersHeader";
    public static final String DEPOSITFILTER_ACCOUNTTYPE = "TERMDEPOSIT/DepositFilter/AccountType";
    public static final String DEPOSITFILTER_PARTYSECTIONTYPE = "TERMDEPOSIT/DepositFilter/PartySectionType";
    public static final String DEPOSITFILTER_ACCOUNTTYPESECTION = "TERMDEPOSIT/DepositFilter/AccountTypeSection";
    public static final String DEPOSITFILTER_PARTYSECTION = "TERMDEPOSIT/DepositFilter/PartySection";
    public static final String DEPOSITFILTER_APPLYBUTTON = "TERMDEPOSIT/DepositFilter/ApplyButton";
    public static final String DEPOSITFILTER_APPLY = "TERMDEPOSIT/DepositFilter/Apply";
    public static final String DEPOSITFILTER_APPLYBUTTONS = "TERMDEPOSIT/DepositFilter/ApplyButtons";
    public static final String DEPOSITFILTER_ISLAMIC = "TERMDEPOSIT/DepositFilter/Islamic";
    public static final String DEPOSITFILTER_CONVENTIONAL = "TERMDEPOSIT/DepositFilter/Conventional";
    public static final String DEPOSITFILTER_PARTYALL = "TERMDEPOSIT/DepositFilter/PartyAll";
    public static final String DEPOSITFILTER_ISLAMICVERIFY = "TERMDEPOSIT/DepositFilter/Islamicverify";
    public static final String DEPOSITFILTER_PARTYHEADER = "TERMDEPOSIT/DepositFilter/PartyHeader";
    public static final String DEPOSITFILTER_PARTYID = "TERMDEPOSIT/DepositFilter/PartyId";
    public static final String DEPOSITFILTER_PARTYIDISLAMIC = "TERMDEPOSIT/DepositFilter/PartyIdIslamic";
    public static final String DEPOSITFILTER_ACCOUNTALL = "TERMDEPOSIT/DepositFilter/AccountAll";
    public static final String DEPOSITFILTER_ACCOUNTTYPEALL = "TERMDEPOSIT/DepositFilter/AccountTypeAll";
    public static final String DEPOSITFILTER_PARTYID1 = "TERMDEPOSIT/DepositFilter/PartyId1";
    public static final String DEPOSITFILTER_NORECORD = "TERMDEPOSIT/DepositFilter/NoRecord";
    public static final String DEPOSITFILTER_PARTYALLS = "TERMDEPOSIT/DepositFilter/PartyAlls";

    // ===== AccountDetails =====
    public static final String ACCOUNTDETAILS_CUSTOMERID = "TERMDEPOSIT/AccountDetails/CustomerID";
    public static final String ACCOUNTDETAILS_ACCOUNTCARD = "TERMDEPOSIT/AccountDetails/AccountCard";
    public static final String ACCOUNTDETAILS_CUSTOMERNAME = "TERMDEPOSIT/AccountDetails/CustomerName";
    public static final String ACCOUNTDETAILS_ACCOUNTNAME = "TERMDEPOSIT/AccountDetails/AccountName";
    public static final String ACCOUNTDETAILS_ACCOUNTBRANCH = "TERMDEPOSIT/AccountDetails/AccountBranch";

    // ===== TermWakalaDepositDetails =====
    public static final String TERMWAKALADEPOSITDETAILS_TENURE = "TERMDEPOSIT/TermWakalaDepositDetails/Tenure";
    public static final String TERMWAKALADEPOSITDETAILS_VALUEDATE = "TERMDEPOSIT/TermWakalaDepositDetails/ValueDate";
    public static final String TERMWAKALADEPOSITDETAILS_DEPOSITCERTIFICATENUMBER = "TERMDEPOSIT/TermWakalaDepositDetails/DepositCertificateNumber";

    // ===== MaturityDetails =====
    public static final String MATURITYDETAILS_MATURITYDATE = "TERMDEPOSIT/MaturityDetails/MaturityDate";
    public static final String MATURITYDETAILS_MATURITYINSTRUCTION = "TERMDEPOSIT/MaturityDetails/MaturityInstruction";

}
