package com.mashreq.automation.tcoe.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.IdentityHashMap;
import java.util.Properties;
import java.util.regex.Pattern;

/** Sanitizes messages and complete cause chains before they reach logs or reporters. */
public final class SafeDiagnostics {
    private static final Pattern URL_AUTH = Pattern.compile("(?i)(https?://)[^/\\s@]+@");
    private static final Pattern AUTH_HEADER = Pattern.compile("(?i)(authorization[\\\"'\\s:=]+)(?:Basic|Bearer)\\s+[^\\s,}]+");
    private static final Pattern SECRET_FIELD = Pattern.compile(
            "(?i)((?:[\\w-]+:)?(?:access[_-]?key|password|passwd|userName|authToken|api[_-]?key)"
                    + "[\\\"'\\s]*[:=][\\\"'\\s]*)([^\\s,}\\]\\\"']+)");

    private SafeDiagnostics() { }

    public static String redact(String text) {
        if (text == null) return "";
        String result = URL_AUTH.matcher(text).replaceAll("$1<redacted>@");
        result = AUTH_HEADER.matcher(result).replaceAll("$1<redacted>");
        result = SECRET_FIELD.matcher(result).replaceAll("$1<redacted>");
        Properties configured = PropertiesHelpers.getProperties();
        for (String key : new String[]{"BROWSERSTACK_ACCESS_KEY", "BROWSERSTACK_USERNAME"}) {
            String[] values = {System.getProperty(key), System.getenv(key),
                    configured == null ? null : configured.getProperty(key)};
            for (String value : values) {
                if (value != null && !value.isBlank()) result = result.replace(value, "<redacted>");
            }
        }
        return result;
    }

    public static String stackTrace(Throwable error) {
        if (error == null) return "";
        StringWriter out = new StringWriter();
        error.printStackTrace(new PrintWriter(out));
        return redact(out.toString());
    }

    /** Keeps every original frame, cause and exception type name without raw secret-bearing messages. */
    public static Throwable sanitized(Throwable error) {
        return copy(error, new IdentityHashMap<>());
    }

    private static Throwable copy(Throwable source, IdentityHashMap<Throwable, Throwable> seen) {
        if (source == null) return null;
        if (seen.containsKey(source)) return seen.get(source);
        SanitizedThrowable safe = new SanitizedThrowable(typeName(source), redact(source.getMessage()));
        seen.put(source, safe);
        safe.setStackTrace(source.getStackTrace());
        Throwable cause = copy(source.getCause(), seen);
        if (cause != null && cause != safe) safe.initCause(cause);
        for (Throwable suppressed : source.getSuppressed()) {
            Throwable safeSuppressed = copy(suppressed, seen);
            if (safeSuppressed != safe) safe.addSuppressed(safeSuppressed);
        }
        return safe;
    }

    public static String typeName(Throwable error) {
        return error instanceof SanitizedThrowable safe ? safe.originalType : error.getClass().getName();
    }

    private static final class SanitizedThrowable extends RuntimeException {
        private final String originalType;

        private SanitizedThrowable(String originalType, String message) {
            super(message);
            this.originalType = originalType;
        }

        @Override
        public String toString() {
            return originalType + (getMessage().isEmpty() ? "" : ": " + getMessage());
        }
    }
}
