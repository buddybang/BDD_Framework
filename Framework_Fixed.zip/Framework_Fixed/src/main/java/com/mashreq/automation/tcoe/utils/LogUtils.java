package com.mashreq.automation.tcoe.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import java.io.PrintWriter;
import java.io.StringWriter;

public final class LogUtils {

    private static Logger logger = LogManager.getLogger();;
    private static final ThreadLocal<String> currentScenario = new ThreadLocal<>();

    private LogUtils() {
        // Prevent instantiation
    }

    /**
     * Initialize per-scenario logging â€” sets file name in ThreadContext.
     */
    public static synchronized void startScenario(String scenarioName, String logFileName) {
        String safeScenario = sanitize(scenarioName);

        currentScenario.set(safeScenario);
        // FIX: Change "logFilename" to "logFileName" to match the XML
        ThreadContext.put("logFileName", logFileName);
        startLog(System.getProperty("user.dir") + "/logs/", logFileName);

        info("************** Starting Scenario: " + scenarioName + " **************");
    }

    /**
     * End scenario log context.
     */
    public static synchronized void endScenario() {
        info("************** Ending Scenario: " + currentScenario.get() + " **************");
        currentScenario.remove();
        ThreadContext.remove("logFileName");
        ThreadContext.remove("logFilename");
    }

    /**
     * Initializes the log file in the specified directory.
     *
     * @param dirPath     Directory path where logs are stored
     * @param logFileName Name of the log file
     */
    private static void startLog(String dirPath, String logFileName) {
        boolean folderCreated = SystemHelpers.createFolder(dirPath);

        if (folderCreated) {
            ThreadContext.put("logFilename", logFileName);
        } else {
            System.err.println("Failed to create or access the log directory.");
        }
    }

    private static String sanitize(String input) {
        return input.replaceAll("[^a-zA-Z0-9]", "_").replaceAll("_+", "_");
    }

    /**
     * Returns the logger instance.
     *
     * @return Logger instance
     */
    public static Logger getCurrentLog() {
        return logger;
    }

    /**
     * Builds a log context string including scenario name, class, method, and line number.
     *
     * @return Formatted string with contextual information
     */
    public static String getCallInfo() {
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        String scenarioName = currentScenario.get();
        int scenarioNameLength = scenarioName != null ? scenarioName.length() : 10;

        // Start searching from index 3 (skips getStackTrace, getCallInfo, and the log method like info/error)
        int indexToUse = 3;

        while (indexToUse < stack.length) {
            String methodName = stack[indexToUse].getMethodName();

            // Define what to skip: lambdas OR the logAction wrapper method.
            if (methodName.contains("lambda$") || methodName.equals("logAction")) {
                indexToUse++; // Skip this frame and check the next one up.
            } else {
                break; // Found a real method, so stop searching.
            }
        }

        // A safety check in case we run out of stack frames
        if (indexToUse >= stack.length) {
            indexToUse = 3;
        }

        StackTraceElement element = stack[indexToUse];
        String fullClassName = element.getClassName();
        String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
        String methodName = element.getMethodName();
        int lineNumber = element.getLineNumber();

        return String.format("[ %-" + scenarioNameLength + "s ] [ %-15.15s:%-22.22s:%04d ] ",
                scenarioName, simpleClassName, methodName, lineNumber);
    }


    // ================== INFO ==================
    public static void info(String message) {
        getCurrentLog().info(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void info(Object message) {
        getCurrentLog().info(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void info(String message, Throwable throwable) {
        getCurrentLog().info(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    public static void info(String format, Object... args) {
        getCurrentLog().info(getCallInfo() + SafeDiagnostics.redact(String.format(format, args)));
    }

    // ------------------- Warn Level Logging -------------------

    public static void warn(String message) {
        getCurrentLog().warn(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void warn(Object message) {
        getCurrentLog().warn(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void warn(String format, Object... args) {
        getCurrentLog().warn(getCallInfo() + SafeDiagnostics.redact(String.format(format, args)));
    }

    // ------------------- Error Level Logging -------------------

    public static void error(String message) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void error(String message, Throwable throwable) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    public static void error(Object message) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void error(Object message, Throwable throwable) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    public static void error(String format, Object... args) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.format(format, args)));
    }

    public static void error(String format, Throwable throwable, Object... args) {
        getCurrentLog().error(getCallInfo() + SafeDiagnostics.redact(String.format(format, args)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    // ------------------- Fatal Level Logging -------------------

    public static void fatal(String message) {
        getCurrentLog().fatal(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void fatal(Object message) {
        getCurrentLog().fatal(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void fatal(Object message, Throwable throwable) {
        getCurrentLog().fatal(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    // ------------------- Debug Level Logging -------------------

    public static void debug(String message) {
        getCurrentLog().debug(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void debug(Object message) {
        getCurrentLog().debug(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void debug(Object message, Throwable throwable) {
        getCurrentLog().debug(getCallInfo() + SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    // ------------------- Trace Level Logging -------------------

    public static void trace(Object message) {
        getCurrentLog().trace(SafeDiagnostics.redact(String.valueOf(message)));
    }

    public static void trace(Object message, Throwable throwable) {
        getCurrentLog().trace(SafeDiagnostics.redact(String.valueOf(message)) + "\n" + SafeDiagnostics.stackTrace(throwable));
    }

    // ================== Utility ==================
    private static String getFullStackTrace(Throwable t) {
        if (t == null) return "";
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return SafeDiagnostics.redact(sw.toString());
    }
}