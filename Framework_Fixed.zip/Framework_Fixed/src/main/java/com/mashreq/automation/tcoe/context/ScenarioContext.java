package com.mashreq.automation.tcoe.context;

import com.mashreq.automation.tcoe.users.UserPair;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;
import lombok.Getter;
import lombok.Setter;
//import io.restassured.response.Response;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.mashreq.automation.tcoe.users.UserPair;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import io.appium.java_client.AppiumDriver;

import lombok.Getter;
import lombok.Setter;

import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Per-scenario context (PicoContainer injects a fresh instance for each scenario).
 * Holds the Playwright Page, scenario metadata, and any ad-hoc scenario data.
 */
public class ScenarioContext {

    // ---- Playwright ----
    // Instance field (was static): each scenario gets its own ScenarioContext, so each thread keeps its own page.
    private Page page;

    // ---- Scenario metadata ----
    @Getter @Setter private String testCaseId;
    @Getter @Setter private String scenarioId;
    @Getter @Setter private String currentModule;
    @Getter @Setter private String currentScreen;
    @Getter @Setter private Instant scenarioStartTime;
    @Getter @Setter private UserPair userPair;
    @Getter @Setter private AppiumDriver mobileDriver;
    @Getter @Setter private boolean mobileScenario;
    @Getter @Setter private Throwable mobileFailure;
    @Getter @Setter private String mobileFailureCategory;
    @Getter @Setter private boolean mobileFailureScreenshotAttempted;
    @Getter @Setter private boolean mobileDiagnosticsSuppressed;
    @Getter @Setter private boolean mobileSessionUsable = true;
    // ---- Scenario metadata ----

    @Setter @Getter private APIResponse apiResponse;
    @Setter @Getter private String authToken;

    // ---- Arbitrary per-scenario data ----
    private final Map<String, Object> scenarioData = new HashMap<>();

    public void setScenarioData(String key, Object value) { scenarioData.put(key, value); }
    public Object getScenarioData(String key) { return scenarioData.get(key); }

    private static final ThreadLocal<ScenarioContext> CURRENT = new ThreadLocal<>();

    public static void  set(ScenarioContext ctx) {CURRENT.set(ctx);}
    public static ScenarioContext get(){ return CURRENT.get();}
    public static void  clear() { CURRENT.remove();}

    private static final ThreadLocal<String> PENDING_CASE_ID = new ThreadLocal<>();

    public static void setPendingCaseId(String testcaseId) {
        PENDING_CASE_ID.set(testcaseId);
    }

    public static String consumePendingCaseId() {
        String id = PENDING_CASE_ID.get();
        PENDING_CASE_ID.remove();
        return id;
    }

    public Page getPage() {
        return page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public String getScenarioId() {
        return scenarioId;
    }

    public void setScenarioId(String scenarioId) {
        this.scenarioId = scenarioId;
    }

    public String getCurrentModule() {
        return currentModule;
    }

    public void setCurrentModule(String currentModule) {
        this.currentModule = currentModule;
    }

    public UserPair getUserPair() {
        return userPair;
    }

    public void setUserPair(UserPair userPair) {
        this.userPair = userPair;
    }

//    public void setResponse(Response response) {
//    }
//
//    public Response getResponse() {
//        return null;
//    }

    public HttpResponse<Object> getPlaywright() {
        return null;
    }


    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String token) {
        this.authToken = token;
    }
    //    public void setApiResponse(APIResponse response) {
//    }
//
//    public APIResponse getApiResponse() {
//        return null;
//    }
    public void setMobileDriver(AppiumDriver driver) { this.mobileDriver = driver; }
    public AppiumDriver getMobileDriver() { return this.mobileDriver; }

    public void setApiResponse(APIResponse response) { this.apiResponse = response; }
    public APIResponse getApiResponse() { return this.apiResponse; }

}
