//package com.mashreq.automation.tcoe.pages.API;
//
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.keywords.IActionLogger;
//import com.mashreq.automation.tcoe.keywords.WebAPI;
//
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * Page Object for the /users resource.
// *
// * Encapsulates all API interactions related to the User domain:
// * fetch, create, update, delete, and validation.
// *
// * Extends BaseAPIPage (NOT BasePage — that is Selenium-specific).
// */
//public class UserAPIPage extends BaseAPIPage {
//
//    // ---------------------------------------------------------------
//    // CONSTRUCTION
//    // ---------------------------------------------------------------
//
//    /**
//     * @param ctx     Active scenario context.
//     * @param logger  Action logger for step reporting.
//     * @param webAPI  Shared WebAPI engine (pre-configured with base URI).
//     */
//    public UserAPIPage(ScenarioContext ctx, IActionLogger logger, WebAPI webAPI) {
//        super(ctx, logger, webAPI);
//    }
//
//    // ---------------------------------------------------------------
//    // SESSION SETUP
//    // ---------------------------------------------------------------
//
//    /**
//     * Adds standard authentication/session headers.
//     * Does NOT set Content-Type — that is already handled by WebAPI internally.
//     *
//     * @param authToken Bearer token for Authorization header.
//     */
//    public void setAuthHeader(String authToken) {
//        Map<String, String> headers = new HashMap<>();
//        headers.put("Authorization", "Bearer " + authToken);
//        webAPI.addHeaders(headers);  // addHeaders merges — does not wipe existing config
//    }
//
//    // ---------------------------------------------------------------
//    // ACTIONS
//    // ---------------------------------------------------------------
//
//    /**
//     * Fetches a user by endpoint (e.g. "/users/1").
//     *
//     * @param endpoint Relative path or full URL.
//     */
//    public void getUser(String endpoint) {
//        webAPI.get(endpoint);
//    }
//
//    /**
//     * Creates a new user via POST.
//     *
//     * @param endpoint Relative path or full URL (e.g. "/users").
//     * @param payload  User object as Map or POJO.
//     */
//    public void createUser(String endpoint, Object payload) {
//        webAPI.post(endpoint, payload);
//    }
//
//    /**
//     * Updates an existing user via PUT.
//     *
//     * @param endpoint Relative path including the user ID (e.g. "/users/1").
//     * @param payload  Updated user data.
//     */
//    public void updateUser(String endpoint, Object payload) {
//        webAPI.put(endpoint, payload);
//    }
//
//    /**
//     * Deletes a user by endpoint.
//     *
//     * @param endpoint Relative path including the user ID (e.g. "/users/1").
//     */
//    public void deleteUser(String endpoint) {
//        webAPI.delete(endpoint);
//    }
//
//    // ---------------------------------------------------------------
//    // VALIDATIONS
//    // ---------------------------------------------------------------
//
//    /**
//     * Validates the HTTP status code of the last response.
//     *
//     * @param expectedCode Expected HTTP status code (e.g. 200, 201, 204, 404).
//     */
//    public void validateStatusCode(int expectedCode) {
//        webAPI.verifyStatusCode(expectedCode);
//    }
//
//    /**
//     * Validates a specific JSON field value in the last response.
//     *
//     * @param jsonPath      GPath expression (e.g. "data.name", "data.id").
//     * @param expectedValue Expected string value.
//     */
//    public void validateField(String jsonPath, String expectedValue) {
//        webAPI.verifyJsonField(jsonPath, expectedValue);
//    }
//
//    /**
//     * Validates that a JSON field is present and non-empty.
//     *
//     * @param jsonPath GPath expression (e.g. "data.email").
//     */
//    public void validateFieldNotEmpty(String jsonPath) {
//        webAPI.verifyJsonFieldNotEmpty(jsonPath);
//    }
//}