package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.MobileFailureSupport;
import com.mashreq.automation.tcoe.utils.PropertiesHelpers;
import com.mashreq.automation.tcoe.utils.SafeDiagnostics;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openqa.selenium.remote.http.ClientConfig;

import java.lang.management.ManagementFactory;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

/** Direct Appium sessions, one per scenario thread, with explicit lifecycle outcomes. */
public final class MobileDriverManager {
    private static final ThreadLocal<AppiumDriver> DRIVER = new ThreadLocal<>();
    private static final ThreadLocal<String> EXECUTION_MODE = new ThreadLocal<>();
    private static final ThreadLocal<String> DEVICE_DETAILS = new ThreadLocal<>();

    private MobileDriverManager() { }

    public static void initDriver() {
        if (DRIVER.get() != null) {
            throw new IllegalStateException("A mobile session already exists on this thread; refusing session reuse.");
        }
        ScenarioContext ctx = ScenarioContext.get();
        if (ctx != null) ctx.setMobileScenario(true);
        String mode = getProperty("MOBILE_EXECUTION_MODE", FrameworkConstants.MOBILE_EXECUTION_MODE)
                .toLowerCase(Locale.ROOT);
        String platform = getProperty("MOBILE_PLATFORM", FrameworkConstants.MOBILE_PLATFORM)
                .toLowerCase(Locale.ROOT);
        EXECUTION_MODE.set(mode);
        long started = System.nanoTime();
        lifecycle("creation-start platform=" + platform, 0);
        try {
            if (!"android".equals(platform) && !"ios".equals(platform)) {
                throw new IllegalArgumentException("MOBILE_PLATFORM must be android or ios.");
            }
            AppiumDriver driver;
            if ("browserstack".equals(mode)) {
                requireDirectIntegration();
                FrameworkConstants.validateBrowserStackConfig();
                ClientConfig config = createBrowserStackClientConfig();
                TimedAppiumCommandExecutor executor = new TimedAppiumCommandExecutor(config);
                driver = "android".equals(platform)
                        ? new AndroidDriver(executor, getBrowserStackAndroidOptions())
                        : new IOSDriver(executor, getBrowserStackIosOptions());
            } else if ("local".equals(mode)) {
                String endpoint = FrameworkConstants.APPIUM_SERVER_URL;
                if (endpoint == null || endpoint.isBlank()) throw new IllegalArgumentException("APPIUM_SERVER_URL is required.");
                TimedAppiumCommandExecutor executor = new TimedAppiumCommandExecutor(httpConfig(new URL(endpoint)));
                driver = "android".equals(platform)
                        ? new AndroidDriver(executor, getLocalAndroidOptions())
                        : new IOSDriver(executor, getLocalIosOptions());
            } else {
                throw new IllegalArgumentException("MOBILE_EXECUTION_MODE must be local or browserstack.");
            }
            DRIVER.set(driver);
            if (ctx != null) ctx.setMobileDriver(driver);
            String device = "browserstack".equals(mode) ? FrameworkConstants.BS_DEVICE_NAME : FrameworkConstants.DEVICE_NAME;
            DEVICE_DETAILS.set(platform.toUpperCase(Locale.ROOT) + " [" + mode.toUpperCase(Locale.ROOT) + "] - " + device);
            lifecycle("creation-succeeded device=" + DEVICE_DETAILS.get(), elapsedMs(started));
        } catch (Exception error) {
            MobileFailureSupport.recordSetup(ctx, error);
            lifecycle("creation-failed category=" + MobileFailureSupport.classify(error)
                    + " remote-allocation-unknown=" + (DRIVER.get() == null), elapsedMs(started));
            LogUtils.error("Mobile session creation failed; no automatic creation retry is performed.", error);
            if (DRIVER.get() != null) quitDriver(null, null);
            else cleanupThreadLocal();
            throw new RuntimeException("Failed to initialize Mobile Driver [mode=" + mode + ", platform=" + platform + "]",
                    SafeDiagnostics.sanitized(error));
        }
    }

    public static AppiumDriver getDriver() { return DRIVER.get(); }
    public static boolean isDriverAvailable() { return DRIVER.get() != null; }
    public static String getDeviceDetails() { return DEVICE_DETAILS.get(); }

    static void requireDirectIntegration() {
        boolean agentAttached = ManagementFactory.getRuntimeMXBean().getInputArguments().stream()
                .anyMatch(arg -> arg.startsWith("-javaagent:") && arg.toLowerCase(Locale.ROOT).contains("browserstack"));
        if (agentAttached) throw new IllegalStateException(
                "Direct Appium mode requires removing the BrowserStack javaagent from this run configuration. "
                        + "The framework owns capabilities, sessions and status marking.");
    }

    static ClientConfig httpConfig(URL endpoint) {
        int connect = PropertiesHelpers.getPositiveInt("MOBILE_HTTP_CONNECT_TIMEOUT_SECONDS", 30);
        int read = PropertiesHelpers.getPositiveInt("MOBILE_HTTP_READ_TIMEOUT_SECONDS", 180);
        return ClientConfig.defaultConfig().baseUrl(endpoint)
                .connectionTimeout(Duration.ofSeconds(connect)).readTimeout(Duration.ofSeconds(read));
    }

    static ClientConfig createBrowserStackClientConfig() throws Exception {
        // Auth belongs to the HTTP client, never the endpoint URL or desired capabilities.
        ClientConfig config = withCredentials(httpConfig(new URL("https://hub-cloud.browserstack.com/wd/hub")),
                FrameworkConstants.BROWSERSTACK_USERNAME, FrameworkConstants.BROWSERSTACK_ACCESS_KEY);
        Proxy proxy = getBrowserStackProxy();
        if (proxy != null) config = config.proxy(proxy);
        lifecycle("http-config proxy=" + (proxy != null) + " connectSeconds=" + config.connectionTimeout().getSeconds()
                + " readSeconds=" + config.readTimeout().getSeconds(), 0);
        return config;
    }

    static ClientConfig withCredentials(ClientConfig config, String username, String key) {
        String authorization = "Basic " + Base64.getEncoder().encodeToString(
                (username + ":" + key).getBytes(StandardCharsets.UTF_8));
        // Send preemptively: a cloud endpoint need not issue a WWW-Authenticate challenge.
        // Do not also install a JDK Authenticator: it can suppress the explicit preemptive header.
        return config.withFilter(next -> request -> {
            request.setHeader("Authorization", authorization);
            return next.execute(request);
        });
    }

    static Proxy getBrowserStackProxy() {
        if (!Boolean.parseBoolean(getProperty("BS_USE_PROXY", "true"))) return null;
        String host = getProperty("BS_PROXY_HOST", FrameworkConstants.BS_PROXY_HOST);
        String value = getProperty("BS_PROXY_PORT", FrameworkConstants.BS_PROXY_PORT);
        if (host.isBlank() && value.isBlank()) return null;
        if (host.isBlank() || value.isBlank()) throw new IllegalArgumentException("Set both BS_PROXY_HOST and BS_PROXY_PORT.");
        int port;
        try { port = Integer.parseInt(value); }
        catch (NumberFormatException error) { throw new IllegalArgumentException("BS_PROXY_PORT must be an integer."); }
        if (port < 1 || port > 65535) throw new IllegalArgumentException("BS_PROXY_PORT must be between 1 and 65535.");
        return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
    }

    static Map<String, Object> browserStackOptions() {
        Map<String, Object> options = new LinkedHashMap<>();
        options.put("projectName", FrameworkConstants.BS_PROJECT);
        options.put("buildName", FrameworkConstants.BS_BUILD);
        ScenarioContext ctx = ScenarioContext.get();
        String name = ctx == null || ctx.getScenarioId() == null ? FrameworkConstants.BS_TEST_NAME
                : ctx.getCurrentModule() + " | " + ctx.getScenarioId();
        options.put("sessionName", name);
        int idle = PropertiesHelpers.getPositiveInt("BS_IDLE_TIMEOUT_SECONDS", 90);
        if (idle > 300) throw new IllegalArgumentException("BS_IDLE_TIMEOUT_SECONDS must be between 1 and 300.");
        options.put("idleTimeout", idle);
        options.put("debug", true);
        options.put("video", true);
        return options;
    }

    static UiAutomator2Options getBrowserStackAndroidOptions() {
        UiAutomator2Options options = new UiAutomator2Options()
                .setDeviceName(FrameworkConstants.BS_DEVICE_NAME)
                .setPlatformVersion(FrameworkConstants.BS_OS_VERSION)
                .setApp(FrameworkConstants.BROWSERSTACK_APP_URL).setNoReset(false);
        options.setCapability("bstack:options", browserStackOptions());
        options.setAutoGrantPermissions(true);
        return options;
    }

    static XCUITestOptions getBrowserStackIosOptions() {
        XCUITestOptions options = new XCUITestOptions().setDeviceName(FrameworkConstants.BS_DEVICE_NAME)
                .setPlatformVersion(FrameworkConstants.BS_OS_VERSION)
                .setApp(FrameworkConstants.BROWSERSTACK_APP_URL).setNoReset(false);
        options.setCapability("bstack:options", browserStackOptions());
        return options;
    }

    private static UiAutomator2Options getLocalAndroidOptions() {
        UiAutomator2Options options = new UiAutomator2Options().setDeviceName(FrameworkConstants.DEVICE_NAME)
                .setAppPackage(FrameworkConstants.APP_PACKAGE).setAppActivity(FrameworkConstants.APP_ACTIVITY)
                .setNoReset(false).setNewCommandTimeout(Duration.ofSeconds(60));
        if (FrameworkConstants.DEVICE_UDID != null && !FrameworkConstants.DEVICE_UDID.isBlank()) options.setUdid(FrameworkConstants.DEVICE_UDID);
        if (FrameworkConstants.PLATFORM_VERSION != null && !FrameworkConstants.PLATFORM_VERSION.isBlank()) options.setPlatformVersion(FrameworkConstants.PLATFORM_VERSION);
        return options;
    }

    private static XCUITestOptions getLocalIosOptions() {
        XCUITestOptions options = new XCUITestOptions().setDeviceName(FrameworkConstants.DEVICE_NAME)
                .setNoReset(false).setNewCommandTimeout(Duration.ofSeconds(60));
        if (FrameworkConstants.DEVICE_UDID != null && !FrameworkConstants.DEVICE_UDID.isBlank()) options.setUdid(FrameworkConstants.DEVICE_UDID);
        if (FrameworkConstants.IOS_APP_PATH != null && !FrameworkConstants.IOS_APP_PATH.isBlank()) options.setApp(FrameworkConstants.IOS_APP_PATH);
        if (FrameworkConstants.PLATFORM_VERSION != null && !FrameworkConstants.PLATFORM_VERSION.isBlank()) options.setPlatformVersion(FrameworkConstants.PLATFORM_VERSION);
        return options;
    }

    public static void quitDriver() { quitDriver(null, null); }

    public static void quitDriver(Boolean passed, String reason) {
        quitDriver(passed, reason, null);
    }

    static void quitDriver(Boolean passed, String reason, ClientConfig resultApiConfig) {
        AppiumDriver driver = DRIVER.get();
        ScenarioContext ctx = ScenarioContext.get();
        if (driver == null) {
            lifecycle("teardown-skipped-no-driver", 0);
            cleanupThreadLocal();
            return;
        }
        try {
            if (passed != null && "browserstack".equals(EXECUTION_MODE.get())) {
                boolean actualPassed = passed && (ctx == null || ctx.getMobileFailure() == null);
                String safeReason = SafeDiagnostics.redact(reason == null ? "" : reason);
                if (ctx != null && ctx.getMobileFailure() != null)
                    safeReason = ctx.getMobileFailureCategory() + ": " + SafeDiagnostics.redact(ctx.getMobileFailure().getMessage());
                if (safeReason.length() > 250) safeReason = safeReason.substring(0, 250);
                String session = driver.getSessionId() == null ? null : driver.getSessionId().toString();
                boolean confirmed = false;
                String channel = "pending";
                if (ctx == null || ctx.isMobileSessionUsable()) {
                    long markingStarted = System.nanoTime();
                    try {
                        String payload = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(Map.of(
                                "action", "setSessionStatus", "arguments", Map.of(
                                        "status", actualPassed ? "passed" : "failed", "reason", safeReason)));
                        lifecycle("status-marking-start", 0);
                        driver.executeScript("browserstack_executor: " + payload);
                        confirmed = true;
                        channel = "executor";
                        lifecycle("status-marking-succeeded", elapsedMs(markingStarted));
                    } catch (Exception error) {
                        lifecycle("status-marking-failed", elapsedMs(markingStarted));
                        LogUtils.warn("BrowserStack status marking failed: " + SafeDiagnostics.stackTrace(error));
                    }
                }
                if (!confirmed && session != null) {
                    try {
                        confirmed = BrowserStackResultReporter.update(resultApiConfig == null ? BrowserStackResultReporter.config() : resultApiConfig, session, actualPassed, safeReason);
                        channel = "rest-api";
                        lifecycle("status-rest-succeeded", 0);
                    } catch (Exception error) {
                        LogUtils.warn("BrowserStack result unconfirmed; status journal retains pending result: " + SafeDiagnostics.stackTrace(error));
                    }
                }
                if (session != null) {
                    try { BrowserStackResultReporter.journal(session, actualPassed, safeReason, confirmed, channel); }
                    catch (Exception error) { LogUtils.warn("Could not persist BrowserStack status journal: " + SafeDiagnostics.stackTrace(error)); }
                }
            }
        } finally {
            // Reporting failures must never bypass the one DELETE attempt.
            long quitStarted = System.nanoTime();
            try {
                lifecycle("quit-start", 0);
                driver.quit();
                lifecycle("quit-succeeded", elapsedMs(quitStarted));
            } catch (Exception error) {
                lifecycle("quit-failed", elapsedMs(quitStarted));
                LogUtils.warn("Mobile quit failed: " + SafeDiagnostics.stackTrace(error));
            } finally {
                cleanupThreadLocal();
            }
        }
    }

    private static void lifecycle(String event, long elapsedMs) {
        ScenarioContext ctx = ScenarioContext.get();
        AppiumDriver driver = DRIVER.get();
        LogUtils.info("Mobile lifecycle [scenario=" + (ctx == null ? "unknown" : ctx.getScenarioId())
                + ", thread=" + Thread.currentThread().getName() + ", mode=" + EXECUTION_MODE.get()
                + ", session=" + (driver == null ? "none" : driver.getSessionId())
                + ", driverPresent=" + (driver != null) + ", elapsedMs=" + elapsedMs + ", event=" + event + "]");
    }

    private static long elapsedMs(long started) { return (System.nanoTime() - started) / 1_000_000; }
    private static String getProperty(String key, String fallback) {
        return PropertiesHelpers.getOptionalValue(key, fallback == null ? "" : fallback);
    }
    private static void cleanupThreadLocal() {
        ScenarioContext ctx = ScenarioContext.get();
        if (ctx != null) ctx.setMobileDriver(null);
        DRIVER.remove();
        EXECUTION_MODE.remove();
        DEVICE_DETAILS.remove();
    }
}
