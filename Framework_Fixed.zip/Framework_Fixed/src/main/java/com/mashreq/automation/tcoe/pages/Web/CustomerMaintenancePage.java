package com.mashreq.automation.tcoe.pages.Web;

import com.mashreq.automation.tcoe.constants.CIF;
import com.mashreq.automation.tcoe.constants.COMMON;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.mashreq.automation.tcoe.pages.CommonPage;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.microsoft.playwright.Frame;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.util.List;

import static com.mashreq.automation.tcoe.driver.DriverManager.getPage;
import static com.mashreq.automation.tcoe.keywords.WebUI.*;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

/**
 * AccountMaintenancePage encapsulates actions on CASA Account Maintenance flows.
 *
 * <p>Conventions:</p>
 * <ul>
 *   <li>OR is resolved via {@link LocatorUtils} (thread-safe cache)</li>
 *   <li>Resolve into a local variable, then pass to WebUI (readability + debug)</li>
 *   <li>Preferred: pages return values; steps persist test data. A legacy writer method is kept for compatibility.</li>
 * </ul>
 *
 * <p>Example OR access:</p>
 * <pre>
 * String accFetch = LocatorUtils.getLocator("CASA", "GeneralDetails", "AccountFetch");
 * webUI.click(accFetch);
 * </pre>
 */
public class CustomerMaintenancePage {

    private static final String MODULE_CASA = "CIF";
    private final CommonPage commonPage;
    private final WebUI webUI;
    public CustomerMaintenancePage(WebUI webUI) {
        this.webUI = webUI;
        this.commonPage = new CommonPage(webUI);
    }

    // -------------------- Buttons / Basic Actions --------------------
    // updated on 18 Nov by sadi
    public void removeLinkedEntities() {
        String LinkedEntity = LocatorUtils.byPath(COMMON.COMMONSCREEN_LINKEDENTITY);
        commonPage.clickButton(LinkedEntity);

        // updated on 18 Nov by sadi
        String CheckDeleteRow1 = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHECKKDELETEROW1);
        commonPage.clickButton(CheckDeleteRow1);
        String CheckDeleteRow2 = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHECKKDELETEROW2);
        commonPage.clickButton(CheckDeleteRow2);
        String CheckDeleteRow0 = LocatorUtils.byPath(CIF.LINKEDENTITY_CHECKKDELETEROW0);
        commonPage.clickButton(CheckDeleteRow0);
        String removeIconLinkedEntity = LocatorUtils.byPath(COMMON.COMMONSCREEN_REMOVEICONLINKEDENTITY);
        commonPage.clickButton(removeIconLinkedEntity);
        webUI.waitForPageToLoad();
    }

    public void removeLinkedEntitiesForIndividual() {
        String LinkedEntity = LocatorUtils.byPath(COMMON.COMMONSCREEN_LINKEDENTITY);
        commonPage.clickButton(LinkedEntity);

        // updated on 18 Nov by sadi
        String CheckDeleteRow0 = LocatorUtils.byPath(CIF.LINKEDENTITY_CHECKKDELETEROW0);
        commonPage.clickButton(CheckDeleteRow0);
        String CheckDeleteRow1 = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHECKKDELETEROW1);
        commonPage.clickButton(CheckDeleteRow1);
        String removeIconLinkedEntity = LocatorUtils.byPath(COMMON.COMMONSCREEN_REMOVEICONLINKEDENTITY);
        commonPage.clickButton(removeIconLinkedEntity);
        webUI.waitForPageToLoad();
    }

    public void verifyChangeLogForLinkedEntity() {
        String expand = LocatorUtils.byPath(COMMON.COMMONSCREEN_EXPAND);
        commonPage.clickButton(expand);
        String changeLog = LocatorUtils.byPath(COMMON.COMMONSCREEN_CHANGELOG);
        commonPage.clickButton(changeLog);
        String viewChanges = LocatorUtils.byPath(COMMON.COMMONSCREEN_VIEWCHANGES);
        commonPage.clickButton(viewChanges);
        webUI.waitForPageToLoad();
        String LinkedEntityChangeLog = LocatorUtils.byPath(COMMON.COMMONSCREEN_LINKEDENTITYCHANGELOG);
        commonPage.clickFirstVisibleElement(LinkedEntityChangeLog);
        webUI.waitForPageToLoad();
    }


    public void clickButton(String modulename, String screenname, String fieldName) {
        String locator = LocatorUtils.byPath(modulename + "/" + screenname + "/" + fieldName);
        webUI.click(locator);
        webUI.waitForPageToLoad();
    }

    // -------------------- Field Entry / Verification --------------------
    public void enterField(String modulename, String screenName, String fieldName, String value) {
        String locator = LocatorUtils.byPath(modulename + "/" + screenName + "/" + fieldName);
        webUI.sendKeys(locator, value);
    }

    public void modifyField(String modulename, String screenName, String fieldName, String testdata) {
        String locator = LocatorUtils.byPath(modulename + "/" + screenName + "/" + fieldName);
        webUI.sendKeys(locator, testdata);
    }

    public void enterSameDetails(String customerNumber, String relationNumber) {
        String cust1LinkedEntity = LocatorUtils.byPath(CIF.LINKEDENTITY_CUSTOMER1);
        webUI.sendKeys(cust1LinkedEntity, customerNumber);
        String relation1LinkedEntity = LocatorUtils.byPath(CIF.LINKEDENTITY_RELATIONS1);
        webUI.sendKeys(relation1LinkedEntity, relationNumber);
    }


    public void retrieveKYCDetails(String KYCRefNo, String KYCCustomerFullName, String riskLevel) {
        String KYCRefNoField = LocatorUtils.byPath(CIF.KYCDETAILS_KYCREFNO);
        String fullNameOfCustomerField = LocatorUtils.byPath(CIF.KYCDETAILS_KYCCUSTOMERFULLNAME);
        String riskLevelField = LocatorUtils.byPath(CIF.KYCDETAILS_RISKLEVEL);
        commonPage.clickEnterQuery();
        webUI.sendKeys(KYCRefNoField, KYCRefNo);
        webUI.sendKeys(fullNameOfCustomerField, KYCCustomerFullName);
        webUI.sendKeys(riskLevelField, riskLevel);
        commonPage.clickExecuteQuery();
        webUI.waitForPageToLoad();
    }

    public void retrieveCustomerDetails(String fieldName, String customerNumber) {
        String customerNumberField = LocatorUtils.byPath(CIF.GENERALDETAILS_CUSTOMERNUMBER);
        commonPage.clickEnterQuery();
        webUI.sendKeys(customerNumberField, customerNumber);
        commonPage.clickExecuteQuery();
        webUI.waitForPageToLoad();
    }

    public String randomFourDigit(String batchNumber) {
        int randomNumber = generateRandomFourDigitNumber(2222, 8888);
        String fourDigit;
        fourDigit = String.valueOf(randomNumber);
        return fourDigit;

    }

    public String retrieveCustomerNumber(String customerNumber) {
        String customerNumberLocator = LocatorUtils.byPath(CIF.GENERALDETAILS_CUSTOMERNUMBER);
        return webUI.retrieveText(customerNumberLocator, customerNumber);
    }

    public void uploadFile(String ChooseFile, String filePath) {
        System.out.println("i am inside the upload file");
        webUI.uploadFile(ChooseFile, filePath);
    }

    // retrive KYC reference number
    public String retrieveKYCRef(String SignatureId) {
        String kycIdLocator = LocatorUtils.byPath(CIF.KYCDETAILS_KYCREFNO);
        return webUI.retrieveText(kycIdLocator, SignatureId);
    }

    public String retrieveSignatureId(String SignatureId) {
        String signatureIdLocator = LocatorUtils.byPath(CIF.SIGNATUREDETAILS_SIGNATUREID);
        return webUI.retrieveText(signatureIdLocator, SignatureId);
    }

    public void verifyCustomerIsFrozen() {
        String frozenCheckboxLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_FROZEN);
        checkFrozenCheckboxStatus(frozenCheckboxLocator);
    }

    public void checkFrozenCheckboxStatus(String frozenCheckboxLocator) {
        webUI.checkFrozenCheckboxStatus(frozenCheckboxLocator);
    }

    public void verifyCustomerDefreeze() {
        String frozenCheckboxLocator = LocatorUtils.byPath(COMMON.COMMONSCREEN_FROZEN);
        checkCustomerDefreezeStatus(frozenCheckboxLocator);
    }

    public void checkCustomerDefreezeStatus(String frozenCheckboxLocator) {
        webUI.checkCustomerDefreezeStatus(frozenCheckboxLocator);
    }

    public void retrieveSignatureDetails(String SignatureId, String customerNumer) {
        System.out.println(SignatureId + "SignatureId--" + customerNumer + "customerNumer---");
        String signatureIdField = LocatorUtils.byPath(CIF.SIGNATUREDETAILS_SIGNATUREID);
        String customerNoField = LocatorUtils.byPath(CIF.SIGNATUREDETAILS_CUSTOMERNUMBERINSIGNATURE);
        commonPage.clickEnterQuery();
        webUI.sendKeys(customerNoField, customerNumer);
        webUI.sendKeys(signatureIdField, SignatureId);
        commonPage.clickExecuteQuery();
        webUI.waitForPageToLoad();
    }

    public void retrieveSignatureDetailsForSignbatureScreen(String SignatureId, String customerNumer) {
        Page page = getPage();
        System.out.println(SignatureId + "SignatureId--" + customerNumer + "customerNumer---");
        String signatureIdField = simplifyLocator(LocatorUtils.byPath(CIF.SIGNATUREDETAILS_SIGNATUREID));
        String customerNoField = simplifyLocator((LocatorUtils.byPath(CIF.SIGNATUREDETAILS_CUSTOMERNUMBERINSIGNATURE)));
        String locator = LocatorUtils.byPath(COMMON.COMMONSCREEN_ADDITIONAL);
        String locatorEnterQuery = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_ENTERQUERY));
        FrameLocator cmFrame = page.frameLocator("iframe[title*='Customer Signature and Image Upload']").nth(0);
        cmFrame.locator(locatorEnterQuery).click();
        webUI.sendKeys(customerNoField, customerNumer);
        webUI.sendKeys(signatureIdField, SignatureId);
        String locatorExecuteQuery = simplifyLocator(LocatorUtils.byPath(COMMON.COMMONSCREEN_EXECUTEQUERY));
        FrameLocator cmFrame1 = page.frameLocator("iframe[title*='Customer Signature and Image Upload']").nth(0);
        cmFrame1.locator(locatorExecuteQuery).click();
    }

    public void selectPayintype(String locator, String testdata) {
        webUI.selectOption(locator, testdata);
    }

    public void verifyTableRow() {
        try {
            Page page = getPage();
            String tableRows = LocatorUtils.byPath(CIF.CUSTOMERSIGNATORYDETAILS_TABLEROW);
            Locator table = webUI.findElementInFrame(tableRows);
            int rowCount = table.locator("tbody tr").count();
            if (rowCount == 0) System.out.println("Signature table is empty");
            else {
                System.out.println("Failed, Still signature is present");
            }
        } catch (IllegalArgumentException ignore) { /* optional */ }
    }

    public void verifyTableCellValue(String SignatureIdTestData) {
        String nextbutton = LocatorUtils.byPath(CIF.SIGNATUREDETAILS_NEXTBUTTON);
        String signTable = LocatorUtils.byPath(CIF.SIGNATUREDETAILS_SIGNATURETABLE);
        webUI.verifyTableCell(signTable, nextbutton, SignatureIdTestData);
    }

    public void selectLov(String value,String locator) {
        String lovSearch =   LocatorUtils.byPath(CIF.RELATEDPARTIESDETAILS_LOVSEARCHICON);
        String lovFetchButton =   LocatorUtils.byPath(CIF.RELATEDPARTIESDETAILS_LOVFETCH);
        String lovFirstRow =   LocatorUtils.byPath(CIF.RELATEDPARTIESDETAILS_LOVFIRSTROW);
        String lovFPositionCodew =   LocatorUtils.byPath(CIF.RELATEDPARTIESDETAILS_LOVPOSITIONCODE);
        webUI.click(lovSearch);
        sleep(5000);
        webUI.sendKeys(lovFPositionCodew, value);
        webUI.waitForPageToLoad();
        webUI.click(lovFetchButton);
        webUI.waitForPageToLoad();
        webUI.click(lovFirstRow);
        getPage().keyboard().press("Tab");
    }



}