//package com.mashreq.automation.tcoe.pages.API;
//
//import com.mashreq.automation.tcoe.context.ScenarioContext;
//import com.mashreq.automation.tcoe.keywords.IActionLogger;
//import com.mashreq.automation.tcoe.keywords.WebAPI;
//
///**
// * Base class for all API Page Objects.
// *
// * Provides a shared WebAPI engine instance and holds references to
// * ScenarioContext and IActionLogger so subclasses can construct
// * additional keyword engines if needed.
// *
// * API pages should NEVER extend BasePage (which is Selenium/web-specific).
// */
//public abstract class BaseAPIPage {
//
//    protected final WebAPI webAPI;
//    protected final ScenarioContext ctx;
//    protected final IActionLogger logger;
//
//    /**
//     * @param ctx    Active scenario context.
//     * @param logger Action logger for step reporting.
//     * @param webAPI Shared WebAPI engine instance.
//     */
//    protected BaseAPIPage(ScenarioContext ctx, IActionLogger logger, WebAPI webAPI) {
//        this.ctx = ctx;
//        this.logger = logger;
//        this.webAPI = webAPI;
//    }
//}