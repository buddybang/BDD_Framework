package com.mashreq.automation.tcoe.pages.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.utils.LocatorUtils;

public class paymentTrackerPage {
    private MobileUI mobileUI;

    public paymentTrackerPage(ScenarioContext ctx, IActionLogger logger) {
        this.mobileUI = new MobileUI(ctx, logger);
    }


}
