package com.mashreq.automation.tcoe.utils;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Pattern;

public final class SystemHelpers {

    public SystemHelpers() {
        super();
    }

    private static final Pattern NONLATIN = Pattern.compile("[^\\w-]");
    private static final Pattern WHITESPACE = Pattern.compile("[\\s]");

    public static String makeSlug(String input) {
        if (input == null)
            throw new IllegalArgumentException();

        String noWhiteSpace = WHITESPACE.matcher(input).replaceAll("_");
        String normalized = Normalizer.normalize(noWhiteSpace, Normalizer.Form.NFD);
        String slug = NONLATIN.matcher(normalized).replaceAll("");
        return slug.toLowerCase(Locale.ENGLISH);
    }

    public static String readFile(String file) throws IOException {
        Charset cs = StandardCharsets.UTF_8;
        FileInputStream stream = new FileInputStream(file);
        try {
            Reader reader = new BufferedReader(new InputStreamReader(stream, cs));
            StringBuilder builder = new StringBuilder();
            char[] buffer = new char[8192];
            int read;
            while ((read = ((BufferedReader) reader).read(buffer, 0, buffer.length)) > 0) {
                builder.append(buffer, 0, read);
            }
            return builder.toString();
        } finally {
            stream.close();
        }
    }

    /**
     * @return Get the path to your source directory with a / at the end
     */
    public static String getCurrentDir() {
        String current = System.getProperty("user.dir") + File.separator;
        return current;
    }

//    /**
//     * Create folder empty
//     *
//     * @param path path to create folder
//     */
//    public static void createFolder(String path) {
//        // File is a class inside java.io package
//        File file = new File(path);
//
//        String result = null;
//
//        int lengthSum = path.length();
//        int lengthSub = path.substring(0, path.lastIndexOf('/')).length();
//
//        result = path.substring(lengthSub, lengthSum);
//
//        if (!file.exists()) {
//            file.mkdir();  // mkdir is used to create folder
//            System.out.println("Folder " + file.getName() + " created: " + path);
//        } else {
//            System.out.println("Folder already created");
//        }
//    }

    /**
     * Creates a folder at the specified path.
     *
     * @param path the directory path
     * @return true if created successfully or already exists, false otherwise
     */
    public static boolean createFolder(String path) {
        File folder = new File(path);
        try {
            if (!folder.exists()) {
                if (folder.mkdirs()) {
                    LogUtils.info("Folder created: '" + folder.getName() + "' at " + path);
                    return true;
                } else {
                    LogUtils.error("Failed to create folder: " + path);
                    return false;
                }
            } else {
                return true;
            }
        } catch (SecurityException | NullPointerException e) {
            System.out.println("Error creating folder: " + e.getMessage());
            return false;
        }
    }

    /**
     * @param str string to be split based on condition
     * @param valueSplit the character to split the string into an array of values
     * @return array of string values after splitting
     */
    public static ArrayList<String> splitString(String str, String valueSplit) {
        ArrayList<String> arrayListString = new ArrayList<>();
        Collections.addAll(arrayListString, str.split(valueSplit, 0));
        return arrayListString;
    }

    public static String removeAccent(String s) {
        // Chuẩn hóa chuỗi thành dạng Unicode tổ hợp (NFD)
        String normalized = Normalizer.normalize(s, Normalizer.Form.NFD);
        String accentRemoved = normalized.replaceAll("\\p{M}", "");
        return accentRemoved;
    }

}