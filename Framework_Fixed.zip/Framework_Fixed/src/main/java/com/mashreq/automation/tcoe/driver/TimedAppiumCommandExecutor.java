package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.MobileFailureSupport;
import com.mashreq.automation.tcoe.utils.PropertiesHelpers;
import io.appium.java_client.AppiumClientConfig;
import io.appium.java_client.MobileCommand;
import io.appium.java_client.remote.AppiumCommandExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.Command;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.remote.http.ClientConfig;

/** Times the command exchange without logging parameters, capabilities, endpoints or credentials. */
public final class TimedAppiumCommandExecutor extends AppiumCommandExecutor {
    public TimedAppiumCommandExecutor(ClientConfig clientConfig) {
        super(MobileCommand.commandRepository, AppiumClientConfig.fromClientConfig(clientConfig));
    }

    @Override
    public Response execute(Command command) throws WebDriverException {
        long started = System.nanoTime();
        String outcome = "response-received";
        try {
            Response response = super.execute(command);
            if (response.getStatus() != null && response.getStatus() != 0) outcome = "remote-error-response";
            return response;
        } catch (RuntimeException error) {
            outcome = MobileFailureSupport.classify(error).name();
            ScenarioContext ctx = ScenarioContext.get();
            if ("screenshot".equals(command.getName())) {
                MobileFailureSupport.diagnosticFailed(ctx, command.getName(), error);
            } else {
                MobileFailureSupport.record(ctx, command.getName(), error);
            }
            throw error;
        } finally {
            if (Boolean.parseBoolean(PropertiesHelpers.getOptionalValue("MOBILE_COMMAND_LOGGING", "true"))) {
                ScenarioContext ctx = ScenarioContext.get();
                LogUtils.info("Mobile command [scenario=" + (ctx == null ? "unknown" : ctx.getScenarioId())
                        + ", thread=" + Thread.currentThread().getName() + ", session=" + command.getSessionId()
                        + ", command=" + command.getName() + ", elapsedMs="
                        + (System.nanoTime() - started) / 1_000_000 + ", outcome=" + outcome + "]");
            }
        }
    }
}
