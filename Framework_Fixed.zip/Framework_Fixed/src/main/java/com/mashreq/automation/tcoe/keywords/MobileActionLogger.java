package com.mashreq.automation.tcoe.keywords;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.utils.MobileFailureSupport;
import com.mashreq.automation.tcoe.utils.SafeDiagnostics;
import com.mashreq.automation.tcoe.utils.LogUtils;
import java.util.function.Supplier;

/** Handles a failed action once, before its result is handed to any reporting adapter. */
final class MobileActionLogger implements IActionLogger {
    private final ScenarioContext ctx;
    private final IActionLogger delegate;

    MobileActionLogger(ScenarioContext ctx, IActionLogger delegate) {
        this.ctx = ctx;
        this.delegate = delegate;
    }

    @Override
    public <T> T logAction(String description, Supplier<T> action) {
        return delegate.logAction(SafeDiagnostics.redact(description), () -> {
            long started = System.nanoTime();
            String actionId = java.util.UUID.randomUUID().toString();
            String outcome = "failed";
            LogUtils.info("Mobile action start [actionId=" + actionId + ", scenario=" + ctx.getScenarioId()
                    + ", thread=" + Thread.currentThread().getName() + ", description=" + SafeDiagnostics.redact(description) + "]");
            try {
                T result = action.get();
                outcome = "passed";
                return result;
            } catch (RuntimeException | AssertionError error) {
                MobileFailureSupport.record(ctx, description, error);
                String path = MobileFailureSupport.captureFailure(ctx);
                if (!path.isBlank()) ScreenshotContextHolder.publishLastScreenshotPath(path);
                throw new AssertionError(SafeDiagnostics.redact(error.getMessage()), SafeDiagnostics.sanitized(error));
            } finally {
                LogUtils.info("Mobile action end [actionId=" + actionId + ", scenario=" + ctx.getScenarioId()
                        + ", outcome=" + outcome + ", elapsedMs=" + (System.nanoTime() - started) / 1_000_000 + "]");
            }
        });
    }
}
