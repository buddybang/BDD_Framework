# TCoE Automation Framework — working context

Repo: Azure DevOps `MashreqCorpTech/TCOE/_git/Native_Mobile_Apps` (local clone at this folder). Maven, Java 17, groupId `com.mashreq.automation`, artifact `TCoE`.

## Branch layout (important)
- `master` (= `origin/master`) holds ONLY `pom.xml`, `README.md` (template stub), `.gitignore`, `TCoE.iml`. No source.
- Real framework code lives on branch `payment_tracker` (latest, local), `origin/OAT` ("Framework code" commit) and `origin/IFT` (only in the pack file).
- `git` is not on PATH on this machine. To inspect other branches without git, loose objects were extracted with Python (scratchpad `extract.py`); `IFT` is packed and not extracted.
- `.git/config` contains a plaintext Azure DevOps bearer token in `http.extraHeader`. Never print or copy it; rotate it.

## What the framework is
Keyword-driven BDD framework: Cucumber 7 + TestNG + PicoContainer, with
- Web UI via Playwright Java (Flexcube/OBDX/OBPM/OBTF/OBTFPM style banking UIs)
- Mobile via Appium (Android/iOS, local or BrowserStack App Automate)
- API via Playwright APIRequest (RestAssured version is commented out)
- Custom reporting: Cucumber JSON -> FreeMarker dashboard + per-feature HTML, plus Allure, Extent, cucumber-reporting.

## Layout (branch payment_tracker)
- `flexcube-features/` Gherkin (01.CIF, API, Mobile)
- `src/main/.../keywords` WebUI, MobileUI (action libs); `pages/` page objects; `driver/` DriverManager (ThreadLocal Playwright), MobileDriverManager
- `constants/` generated locator-key constants (CIF, COMMON, MOBILE, TERM...), `Script/LocatorConstantGenerator.java` + `utils/ORGenerator` generate them from `objectrepo/*.json`
- `utils/DataHandler` test data JSON by module/scenarioId; `testdata/` (+ `excel_files/`); `users/` maker/checker pool (BlockingQueue)
- `src/test/.../hooks/ApplicationHooks` (Before/After/AfterStep/AfterAll), `stepdefinitions/`, `runners/` (TestRunner, RerunTestRunner, MainRunner), `listeners/`, `utils/FeatureAggregator` + `FeatureStepCollector` (history/master.json for dashboard)
- Config: `src/main/resources/config/config.properties` + `urls-<ENV>.properties`; `-DENV -DREGION -Dparallel -Dthreads -Dcucumber.tags` overrides
- Run: `mvn test` (suite `src/test/resources/suites/testng.xml`, needs aspectj javaagent); failed scenarios -> `target/rerun.txt`

## Known issues (see the analysis given in chat on 2026-09-30)
Committed secrets (BrowserStack key, user passwords, git token), `target/` committed, hard-coded `@Mobile and @SC_2741358` tag in TestRunner, static shared `ScenarioContext.page`, `MobileDriverManager.java` ~73% commented-out code, many Thread.sleep, swallowed exceptions, `setIgnoreHTTPSErrors(true)`, PropertiesHelpers.getValue swallows missing keys (returns null -> NPE at class init), duplicate/conflicting pom dependencies, API layer commented out.
