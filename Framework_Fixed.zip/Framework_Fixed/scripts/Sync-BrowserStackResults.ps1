param(
    [string]$ProxyUri,
    [string]$ResultsDirectory = (Join-Path (Split-Path $PSScriptRoot -Parent) 'target/browserstack-status')
)
$ErrorActionPreference = 'Stop'
if (-not $env:BROWSERSTACK_USERNAME -or -not $env:BROWSERSTACK_ACCESS_KEY) {
    throw 'Set BROWSERSTACK_USERNAME and BROWSERSTACK_ACCESS_KEY environment variables.'
}
$authorization = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(
    $env:BROWSERSTACK_USERNAME + ':' + $env:BROWSERSTACK_ACCESS_KEY))
$failedUpdates = 0
foreach ($resultFile in (Get-ChildItem -LiteralPath $ResultsDirectory -Filter '*.json' -File)) {
    try {
        $result = Get-Content -LiteralPath $resultFile.FullName -Raw | ConvertFrom-Json
        if ($result.confirmed -eq $true) { continue }
        if ($result.sessionId -notmatch '^[A-Za-z0-9-]+$' -or $result.status -notin @('passed','failed')) {
            throw 'Invalid result journal entry.'
        }
        $request = @{
            Uri = 'https://api-cloud.browserstack.com/app-automate/sessions/' + $result.sessionId + '.json'
            Method = 'Put'
            Headers = @{ Authorization = 'Basic ' + $authorization }
            ContentType = 'application/json'
            Body = (@{status=$result.status; reason=$result.reason} | ConvertTo-Json -Compress)
            TimeoutSec = 15
        }
        if ($ProxyUri) { $request.Proxy = $ProxyUri }
        $null = Invoke-RestMethod @request
        $result.confirmed = $true
        $result.channel = 'rest-api-reconciliation'
        $result.recordedAt = [DateTime]::UtcNow.ToString('o')
        $temporaryPath = $resultFile.FullName + '.sync.tmp'
        try {
            [IO.File]::WriteAllText($temporaryPath, ($result | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
            Move-Item -LiteralPath $temporaryPath -Destination $resultFile.FullName -Force
        } finally {
            if (Test-Path -LiteralPath $temporaryPath) { Remove-Item -LiteralPath $temporaryPath }
        }
        Write-Output ('Result synchronized: ' + $result.sessionId + ' = ' + $result.status)
    } catch {
        $failedUpdates++
        Write-Warning ('Result remains pending: ' + $resultFile.Name + '. Check account API connectivity and credentials.')
    }
}
if ($failedUpdates -gt 0) { exit 1 }
