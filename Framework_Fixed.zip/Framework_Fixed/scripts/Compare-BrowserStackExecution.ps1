param(
    [Parameter(Mandatory = $true)][string]$Tags,
    [ValidateRange(2, 20)][int]$ParallelThreads = 3,
    [ValidateRange(1, 20)][int]$Iterations = 1,
    [string]$MavenCommand = 'mvn',
    [switch]$Offsite
)

# Run from any directory; credentials must already be supplied through the environment.
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:BROWSERSTACK_USERNAME) -or
    [string]::IsNullOrWhiteSpace($env:BROWSERSTACK_ACCESS_KEY)) {
    throw 'Set BROWSERSTACK_USERNAME and BROWSERSTACK_ACCESS_KEY in the environment before running this comparison.'
}
$workspace = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$comparisonRoot = Join-Path $workspace ('target/browserstack-comparison/' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $comparisonRoot -Force | Out-Null
$summary = [System.Collections.Generic.List[object]]::new()
$anyFailure = $false
Push-Location -LiteralPath $workspace
try {
    foreach ($iteration in 1..$Iterations) {
        foreach ($mode in @('sequential', 'parallel')) {
            $runRoot = Join-Path $comparisonRoot ($iteration.ToString() + '-' + $mode)
            New-Item -ItemType Directory -Path $runRoot -Force | Out-Null
            $profiles = if ($mode -eq 'sequential') { 'mobile-sequential' } else { '' }
            if ($Offsite) { $profiles = if ($profiles) { $profiles + ',offsite' } else { 'offsite' } }
            $mavenArgs = @('test', "-Dcucumber.tags=$Tags", '-DMOBILE_EXECUTION_MODE=browserstack')
            if ($profiles) { $mavenArgs += "-P$profiles" }
            if ($mode -eq 'parallel') { $mavenArgs += @('-Dparallel=true', "-Dthreads=$ParallelThreads") }
            $started = Get-Date
            Write-Output "Starting $mode iteration $iteration; artifacts: $runRoot"
            $runExit = 1
            try {
                & $MavenCommand @mavenArgs > (Join-Path $runRoot 'console.log') 2>&1
                $runExit = $LASTEXITCODE
            } catch {
                Add-Content -LiteralPath (Join-Path $runRoot 'console.log') -Value ('Maven launch/execution failed: ' + $_.Exception.Message)
            }
            if ($runExit -ne 0) { $anyFailure = $true }
            $reportPath = Join-Path $workspace 'reports/latest/cucumber-reports/cucumber-report.json'
            $freshReport = (Test-Path -LiteralPath $reportPath) -and
                ((Get-Item -LiteralPath $reportPath).LastWriteTime -ge $started)
            $artifactPaths = if ($freshReport) { @('logs/latest', 'reports/latest', 'target/rerun.txt') } else { @() }
            foreach ($relativePath in $artifactPaths) {
                if (Test-Path -LiteralPath $relativePath) {
                    $name = $relativePath.Replace('/', '-')
                    Copy-Item -LiteralPath $relativePath -Destination (Join-Path $runRoot $name) -Recurse
                }
            }
            $summary.Add([pscustomobject]@{
                Iteration = $iteration
                Mode = $mode
                Threads = if ($mode -eq 'sequential') { 1 } else { $ParallelThreads }
                ExitCode = $runExit
                FreshReport = $freshReport
                ElapsedSeconds = [math]::Round(((Get-Date) - $started).TotalSeconds, 2)
                Artifacts = $runRoot
            })
        }
    }
    $summary | Export-Csv -LiteralPath (Join-Path $comparisonRoot 'summary.csv') -NoTypeInformation -Encoding UTF8
    $summary | Format-Table -AutoSize
} finally {
    Pop-Location
}
if ($anyFailure) { exit 1 }
