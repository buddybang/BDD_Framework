# Native Android and iOS keywords

Updated 6 October 2026. These keywords use native Appium elements on phones and tablets. Keep native screens in NATIVE_APP. Device layouts still require appropriate Android/iOS and phone/tablet locators.

## Typing

Both `sendKeys` and `sendKeyswithEnter` wait for a visible, enabled element, focus it, clear it, and enter the supplied text. iOS targets must be XCUIElementTypeTextField, XCUIElementTypeSecureTextField, or XCUIElementTypeTextView. Select the editable child rather than a surrounding container. Failures retain their original cause and identify inspect input, focus, clear, or type. Ambiguous remote failures are not replayed.

`sendKeyswithEnter` uses Android's Done editor action and sends a newline on iOS. The app's keyboard must support a return action; numeric keyboards and app-specific Done buttons can require a separate click keyword. Custom controls without native editable semantics require app-specific handling.

## Reading

`getText` reads iOS text field/text view `value`. For other elements it uses getText, with an empty-result fallback to iOS `label` or Android `text`. It never substitutes an accessibility identifier. Lookup and command failures now fail the keyword instead of silently returning an empty string. XCTest can expose placeholders as values; use a test assertion appropriate for that control.

Use `getAttribute(locator, "text")`, `getAttribute(locator, "value")`, or `getAttribute(locator, "label")` when the scenario requires that exact attribute. This Java API does not add a new Gherkin step definition.

## Locators

Existing xpath, id, accessibility, and class prefixes remain supported. Added:

- `iospredicate|type == 'XCUIElementTypeTextField' AND name == 'amount'`
- `iosclasschain|**/XCUIElementTypeButton[`name == 'submit'`]`
- `androiduiautomator|new UiSelector().resourceId("example:id/amount")`

The native Appium names `-ios predicate string|` and `-ios class chain|` are also accepted. Unknown strategy prefixes fail explicitly instead of being interpreted as XPath. Raw XPath, including union expressions, remains supported.

Official references: [iOS locators](https://appium.github.io/appium-xcuitest-driver/latest/reference/ios-predicate/), [iOS attributes](https://appium.github.io/appium-xcuitest-driver/latest/reference/element-attributes/).

## Validation

All 68 Java source files compile with Java 17; IntelliJ build reports success. All 18 offline regression tests pass. These include native input ordering, clear failure without subsequent typing, iOS editable target validation, empty input values, Android text/iOS label fallback, and Appium locator strategy serialization, alongside the existing HTTP/session regression tests.

Live BrowserStack execution has not been performed. Verify on Android phone, Android tablet, iPhone, and iPad with the actual app and platform locators: ordinary input, secure input, clear existing content, read input value, read static text, and submit using the appropriate keyboard/button. Confirm incorrect locators fail with the original cause. See [BrowserStack execution instructions](browserstack-execution.md) for credentials and sequential execution. Standard Maven validation remains limited by the previously documented uncached plugin dependencies.
