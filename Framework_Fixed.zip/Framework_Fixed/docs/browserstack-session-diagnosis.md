# BrowserStack mobile session diagnosis

Reviewed 6 October 2026. Source code was inspected alongside the supplied scenario log, both BrowserStack javaagent logs, Cucumber/Allure results, and historical mobile logs. No source changes or live cloud executions were made. IntelliJ debugger tools were checked using the ij-debugger skill; there was no active session. Findings below use recorded runtime evidence, not a new debugger reproduction. Historical source line numbers differ from current source in places.

## Implementation update ? 6 October 2026

The local framework changes from recommendations 1?6 have been implemented. Recommendation 7 now has a sequential Maven profile and an executable comparison script that archives each live run. All 66 Java source files compiled with Java 17, and 12 offline regression tests passed. See [execution instructions and validation details](browserstack-execution.md).

A live BrowserStack/proxy/concurrency comparison and rotation of the previously exposed account key still require the cloud account and execution environment. The historical analysis below remains the evidence motivating the changes; its source line numbers describe the original implementation.

## Native keyword update

Android/iOS typing, native text reads, and platform locator handling have been updated. All 18 offline regression tests pass; live BrowserStack phone/tablet validation is pending. See [native keyword behavior and validation](native-mobile-keywords.md).

## Finding

The supplied SC_2741351 run failed during session creation when the client HTTP request timed out. It did not reach an object lookup. Other recorded “may have died” errors show communication failures, but that message does not by itself establish that BrowserStack terminated the session. Framework error handling obscures the distinction between a failed request, failed lookup, and normal scenario teardown.

## Evidence from the supplied run

The log's internal date is **1 October 2026**, regardless of its later file modification time.

| Evidence | Observation | Interpretation |
|---|---|---|
| `logs/latest/Log_TermDeposit_SC_2741351_6605835b-3fae-4268-8df5-083f66bcaeef.log` | Scenario setup starts at 13:19:14; completion is logged at 13:20:45 with duration 90,600 ms. No mobile-driver-started entry occurs. | Failure occurs during setup. |
| `reports/latest/cucumber-reports/cucumber-report.json` | Before hook failed in **90.5817595 seconds**; **24 steps skipped**; After hook passed. | No business step or locator failure caused this particular run. |
| `reports/latest/allure-results/6605835b-3fae-4268-8df5-083f66bcaeef-result.json` | Cause chain: RuntimeException → SessionNotCreatedException → Selenium TimeoutException → `java.util.concurrent.TimeoutException`; includes `JdkHttpClient.execute` and `ProtocolHandshake.createSession`. | The client did not complete the new-session HTTP exchange within its timeout. Whether the server created a remote session before the client timed out is unknown. |
| `MobileDriverManager.java:2600–2608` | HTTP connection timeout 30 seconds; HTTP read timeout **90 seconds**, used for both session creation and subsequent commands. | The failed setup duration matches the client's configured 90-second read budget. This identifies the timeout mechanism, not why the response was late. |
| Supplied scenario log / `ApplicationHooks.java:1603–1646` | Failed setup leaves no mobile driver. Screenshot code falls through to `DriverManager.getPage()`, which throws because no web page exists. | A secondary framework screenshot error hides the primary setup failure in the scenario log. |
| Supplied scenario log / `ApplicationHooks.java:1194–1203` | “Mobile driver closed successfully” is logged after calling quitDriver, even if no mobile driver was created. | This message does not prove that a BrowserStack session existed or that a DELETE request succeeded. |

## Historical “may have died” evidence

In `logs/backup/logs__2026Sep30_111639Z/Log_TermDeposit_SC_2741358_9dbed417-306a-4361-932d-a3baa3ba2875.log`:

- At **16:44:24**, a screenshot request raises `UnreachableBrowserException` with “may have died” (line 60).
- Its nested causes include `IOException: closed`, `fixed content-length: 602046, bytes received: 11994`, and `connection closed locally` (lines 119, 130, 145 and 154).
- The screenshot HTTP body was incomplete. The logs do not identify whether the original interruption came from the proxy, client, network, or remote service.
- At **16:44:28**, an Android editor action succeeds; at **16:44:30**, another screenshot succeeds (lines 171–172). No intervening driver initialization is recorded, and current screenshot failure handling does not recreate a session.
- The scenario finishes **PASSED**, and normal teardown occurs at **16:45:40** (lines 248–255).

This run demonstrates that a “may have died” message can describe a failed HTTP request while the same scenario's session continues to work.

Historical Allure results also show this message while finding PIN input elements in SC_2700567 and SC_2741358. Those reports retain only AssertionError wrappers: the underlying transport exception cause was discarded by the keyword layer. Therefore the exact transport cause for those particular findElement failures cannot be recovered from those reports.

## What the javaagent logs establish

The latest run segment in `logs/browserstack-javaagent.log` contains:

- Line 4063: framework detection is null, so Test Observability cannot be enabled.
- Lines 4064–4065: telemetry product selection throws an NPE, followed by a process-data parse error.
- Line 4087: the funnel telemetry endpoint returns `Unauthorized`.
- Other appended run segments contain `SSLHandshakeException: Remote host terminated the handshake` in `FunnelInstrumentation`.

The debug log contains corresponding telemetry entries (latest segment at lines 3784–3806). These files contain multiple appended runs and time-only timestamps; correlate segments using scenario time and SDK run information rather than file modification time.

These errors show an incompletely configured SDK/telemetry path. They do **not** establish an authentication failure for the Appium hub, nor prove that the SDK closed the Appium session. The selected current segment has no Appium session ID, command stream, DELETE record, or cloud termination reason. `SDKTestSuccessful` is the funnel event name, not proof that the Cucumber scenario passed.

## Framework failure and teardown path

1. A mobile keyword performs a wait or remote command.
2. On an exception, several keywords request another screenshot. `findElement` also requests one on failure, and `@After` requests one for a failed scenario.
3. Many keyword catches call `Assert.fail(message + e.getMessage())`, losing the original cause; for example `MobileUI.java:1237–1245`.
4. `FeatureStepCollector.java:160` wraps the resulting throwable and propagates failure to Cucumber. It cannot recover a cause already discarded by the keyword.
5. Cucumber skips remaining steps and executes `ApplicationHooks.afterScenario`.
6. Its finally block calls `MobileDriverManager.quitDriver(...)` at `ApplicationHooks.java:1194`. The manager attempts BrowserStack status marking, then `currentDriver.quit()` at `MobileDriverManager.java:3002` and removes ThreadLocal state.

The inspected code does not call driver.quit directly from a locator catch. After a hard test failure, closing the session in the After hook is expected cleanup. Disabling teardown would leave sessions allocated and would not correct the first failure.

## Recommended changes

| Order | Change | Reason / acceptance |
|---|---|---|
| 1 | Preserve exception causes with `Assert.fail(message, e)` and log the original command failure before any screenshot attempt. Classify locator timeout separately from transport timeout, invalid session, and setup failure. | A forced lookup failure and a simulated transport failure must yield distinct results with full cause chains. Redact authentication fields in exception messages and capabilities. |
| 2 | Make screenshot selection explicitly channel-aware. For failed mobile initialization, skip capture instead of trying the web driver. | A failed mobile Before hook must retain its original error without `DriverManager.page is null`. |
| 3 | Centralize failure screenshot capture; attempt it once where useful, and skip further remote diagnostics when the first failure indicates an unusable session/transport. | Failure processing must not stack multiple full HTTP waits or mask the initiating exception. Screenshot failure must remain secondary. |
| 4 | Log a sanitized setup/teardown lifecycle: scenario ID, thread, mode/platform, creation elapsed time, returned session ID, whether a driver existed, status-marking result, quit attempt and quit result. | “No driver was created,” “quit succeeded,” and “quit failed” must be separate outcomes. Never log endpoint credentials or credential-bearing capability dumps. |
| 5 | Make HTTP connect/read timeouts configurable. Measure creation and command latency through the actual proxy; evaluate a larger read budget in a controlled run. | The fixed 90-second budget demonstrably expires during setup. Increasing it may help slow provisioning or responses, but cannot fix an interrupted connection and is not yet a proven solution. Avoid blind creation retries: the server may have allocated a session without returning its ID to the client. |
| 6 | Use one BrowserStack integration mode consistently: direct Appium with framework-owned capabilities/status, or a correctly configured SDK workflow. Investigate why SDK framework detection and credentials are null in telemetry. | Confirm whether the javaagent is actually attached to the failing run; the reviewed POM declares the SDK dependency but its argLine explicitly includes only AspectJ. Removing SDK instrumentation should be a controlled comparison, not assumed to fix Appium. |
| 7 | Compare sequential execution against configured parallel execution, and inspect BrowserStack allocation/queue timing for setup failures. | A timeout while waiting for a cloud device can look like a connectivity timeout from the client. The current logs do not prove a concurrency-limit problem. |

HTTP read timeout, explicit element wait, and BrowserStack idle timeout are different timers. BrowserStack documents a default idle interval of 90 seconds, with an `idleTimeout` override up to 300 seconds. The supplied stack is an HTTP new-session timeout; no `BROWSERSTACK_IDLE_TIMEOUT` marker was found in the reviewed local logs. Set an idle override only when the server's session logs support that diagnosis. See [BrowserStack idle timeout documentation](https://www.browserstack.com/docs/app-automate/appium/troubleshooting/browserstack-idle-timeout?fw-lang=java) and [App Automate timeout reference](https://www.browserstack.com/docs/app-automate/appium/references/timeouts).

## Remaining evidence needed to identify an actual premature session termination

For a failing existing-session run, correlate its BrowserStack session ID with the **server Appium/text logs**, final cloud reason, last successful command, first failing command, and DELETE-session timestamp. Historical affected sessions include `286d808c2b7255b0a366e43f3c6f1aa87d3d7408` and `3758cf218ee9e9ba5c9939ee17d1d2bf847833cf` (see historical Allure results). Cloud artifacts may no longer be retained.

The result determines the next action: DELETE after the first test failure supports expected teardown; idle timeout requires command-gap analysis; a crashed Appium/device service requires cloud/device evidence; incomplete HTTP responses require client/proxy/network comparison. The existing local evidence does not establish which of those caused the historical PIN lookup failures.

Actual credential exposure was also observed in historical exception capability dumps. Remove authentication values from those capabilities/logs and rotate the exposed BrowserStack key. Values are intentionally omitted from this report.
