# BrowserStack mobile execution after the fixes

The framework now uses **direct Appium**. It owns driver creation, commands, status marking and teardown. The BrowserStack SDK dependency has been removed. Remove any BrowserStack `-javaagent` option from IDE/Maven/JAVA_TOOL_OPTIONS configurations; an identifiable BrowserStack agent is rejected before a cloud session is requested. Keep the existing AspectJ reporting agent.

## Credentials and configuration

Use Java 17 and Maven. Supply `BROWSERSTACK_USERNAME` and `BROWSERSTACK_ACCESS_KEY` through the environment or your CI secret store. Their config-file entries are now empty. Avoid putting secrets into command-line arguments or committing them. BrowserStack authentication is sent as a preemptive HTTP Basic header; credentials are no longer embedded in the endpoint URL or desired capabilities.

The credential previously exposed in historical capability dumps still needs to be **rotated in the BrowserStack account dashboard**, then replaced in your secret store. Local source changes cannot revoke an account key. Historical evidence files were retained; they may contain the old key.

Optional settings resolve in this order: system property, environment variable, config file, default.

| Setting | Default | Purpose |
|---|---|---|
| `MOBILE_HTTP_CONNECT_TIMEOUT_SECONDS` | 30 | Connection establishment timeout; positive integer. |
| `MOBILE_HTTP_READ_TIMEOUT_SECONDS` | 180 | HTTP response timeout for creation and commands; positive integer. Increased from the former fixed 90 seconds. |
| `BS_IDLE_TIMEOUT_SECONDS` | 90 | Separate cloud idle limit, configurable from 1 to 300 seconds. |
| `MOBILE_COMMAND_LOGGING` | true | Logs command name/session/thread/outcome/elapsed milliseconds, without parameters or capabilities. |
| `BS_USE_PROXY` | true | Corporate proxy enabled by the normal Maven profile; `offsite` disables it. |

The 180-second read timeout gives slow provisioning/responses more time. It is not a guarantee against proxy/network interruptions. Do not add automatic new-session retries: a timed-out creation request may have allocated a device whose ID the client never received.

## Validation and execution

Run the offline regression suite first:

```powershell
mvn test -Pmobile-regression
```

It exercises real Appium/Selenium HTTP exchanges against a loopback fake server, not BrowserStack. Tests cover missing-element failure classification and cause retention, one failure screenshot, interrupted screenshot responses, usable-session status marking, mandatory quit despite transport failure, thread isolation, authentication, redaction and invalid timeout values. The regression profile uses console-only logging to avoid replacing scenario logs.

Start with one selected mobile scenario:

```powershell
mvn test -Pmobile-sequential '-Dcucumber.tags=@Mobile and @SC_2741351'
```

Outside the corporate network, use `-Pmobile-sequential,offsite` with the same tags. This changes the proxy route; it does not change app/device settings.

Compare sequential and parallel execution using the same approved scenarios, app, device and timeout settings:

```powershell
./scripts/Compare-BrowserStackExecution.ps1 -Tags '@Mobile and (@SC_2741351 or @SC_2700567 or @SC_2741358)' -ParallelThreads 3 -Iterations 2
```

Pass `-Offsite` only when appropriate for the network. `-MavenCommand` accepts an explicit Maven executable path. The script runs real cloud sessions, archives console output/logs/reports after each run under `target/browserstack-comparison/<timestamp>`, writes `summary.csv`, and exits nonzero if any run failed. Use at least two independent scenarios for a concurrency comparison; selecting only one scenario does not exercise concurrency. Ensure the selected scenarios use suitable independent test accounts if concurrent application logins are restricted.

## Reading the new evidence

`Mobile lifecycle` entries distinguish `creation-start`, `creation-succeeded`, `creation-failed`, `teardown-skipped-no-driver`, status-marking outcomes, and `quit-start`/`quit-succeeded`/`quit-failed`. Device metadata is stored per thread.

`Mobile command` entries give the actual HTTP exchange duration. `response-received` means the exchange completed; the UI operation may subsequently fail while Selenium decodes the response or an explicit wait times out. Failure categories are `LOCATOR_TIMEOUT`, `LOCATOR_ERROR`, `TRANSPORT_TIMEOUT`, `TRANSPORT_FAILURE`, `INVALID_SESSION`, `SETUP_FAILURE` and `ACTION_FAILURE`.

The first failure is preserved before diagnostic work. A scenario failure requests at most one failure screenshot. Transport/session failures suppress screenshots and status marking, while teardown still attempts one quit. A screenshot failure suppresses further diagnostic requests but permits business commands to continue: it does not by itself declare the session dead. Failed mobile initialization never falls through to a web screenshot.

For a live failure, use the logged session ID to inspect BrowserStack's session Appium/text logs and final termination reason. Compare the last successful command, first failed command and DELETE timestamp with the client lifecycle entries. Device allocation/queue latency, server idle termination and proxy interruption still require live evidence; local regression tests cannot establish them.

## Validation performed on 6 October 2026

All 51 main and 15 test Java source files compiled with Java 17 against cached dependencies. All 12 offline regression tests passed (0 failures/skips). IntelliJ build calls returned success, but its debugger launcher could not start the test process. The tests were therefore compiled and run directly with Java/TestNG. A portable [Microsoft OpenJDK 17](https://learn.microsoft.com/en-us/java/openjdk/download) was used from the temporary directory because the system Java was 11 and IntelliJ's bundled runtime was 25.

The standard offline Maven lifecycle and explicit compiler goals were blocked by uncached resources/compiler-plugin dependencies. Direct compilation/test execution was used for validation; the added Maven profiles still need a normal Maven run where those plugin dependencies can be resolved. The comparison script was also exercised with a fake Maven command: it continued after the sequential failure, recorded both outcomes, and returned a nonzero exit status. No live BrowserStack comparison or account key rotation was performed.
