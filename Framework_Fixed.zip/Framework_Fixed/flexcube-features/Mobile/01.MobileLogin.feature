Feature: Mobile Login Functionality

  @Mobile @SC_2741351
  Scenario: TermDeposit|SC_2741351|Verify search does not return records from other currency
    Given the mobile app is launched
    And user clicks the "Login" button under "Loginflow" screen
    And user clicks the "Loginwithpassword" button under "Loginflow" screen
    And user enters the following Mobile field details under "Loginflow" screen
      |Userid|
    And user clicks the "ForwardArrow" button under "Loginflow" screen
    And user enters the following Mobile field details under "Loginflow" screen
      |Password|
    And user clicks the "Login1" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |Loginpin|
    And user clicks the "Continue" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |Confirmloginpin|
    And user clicks the "Continue" button under "Loginflow" screen
    And user clicks the "Biometricslater" button under "Loginflow" screen
    And user clicks the "Login2" button under "Loginflow" screen
    And user clicks the "LoginwithPIN" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |EntersixdigitPIN|
    And user clicks the "PINContinue" button under "Loginflow" screen
    And user scrolls and clicks the "Termsandcondition" button under "Loginflow" screen
    And user clicks the "Agreeandcontinue" button under "Loginflow" screen
    And user swipes and clicks the "Deposits" button under "DepositHomepage" screen
    And user clicks the "AEDWidgetAccount" button under "DepositHomepage" screen
    Then the user verifies the following elements should be "visible" under "DepositHomepage" screen
      |DepositSummaryHeader|
    When user enters the following Mobile field details under "DepositHomepage" screen
      |USDAccountNumber|
    And user clicks the "SearchIcon" button under "DepositHomepage" screen
    Then user verifies the following mobile field details under "DepositHomepage" screen
      |NoRecordsFound|

#    Given user "Maker" is logged into "FCUBS" with appropriate privileges

  @Mobile @SC_2700567
  Scenario: TermDeposit|SC_2700567|Verify all the different fields and details present in the Account details screen
    Given the mobile app is launched
    And user clicks the "Login" button under "Loginflow" screen
    And user clicks the "Loginwithpassword" button under "Loginflow" screen
    And user enters the following Mobile field details under "Loginflow" screen
      |Userid|
    And user clicks the "ForwardArrow" button under "Loginflow" screen
    And user enters the following Mobile field details under "Loginflow" screen
      |Password|
    And user clicks the "Login1" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |Loginpin|
    And user clicks the "Continue" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |Confirmloginpin|
    And user clicks the "Continue" button under "Loginflow" screen
    And user clicks the "Biometricslater" button under "Loginflow" screen
    And user clicks the "Login2" button under "Loginflow" screen
    And user clicks the "LoginwithPIN" button under "Loginflow" screen
    And user enters the following input field details under "Loginflow" screen
      |EntersixdigitPIN|
    And user clicks the "PINContinue" button under "Loginflow" screen
    And user scrolls and clicks the "Termsandcondition" button under "Loginflow" screen
    And user clicks the "Agreeandcontinue" button under "Loginflow" screen
    Then the user verifies the following elements should be "visible" under "Accountdetail" screen
      |Accounts|
    And user clicks the "AccountdetailNavaiagtebar" button under "Accountdetail" screen
    And user clicks the "Accountno" button under "Accountdetail" screen
    Then user verifies the following mobile field details under "Accountdetail" screen
      |AccountDetails|
      |Accountnames|
      |Bankname|
      |Accountstatement|
    Then user verifies the following mobile field details under "Accountdetail" screen
      |OpeningBalance|
      |AvailableBalance|
      |CurrentBalance|
      |AmountOnHold|
      |OverdraftLimit|
      |UnclearFunds|
      |AdvanceAgainstUnclearFunds|
      |DailyATMWithdrawalLimit|
      |MinimumBalanceRequired|
    Then user verifies the following mobile field details under "Accountdetail" screen
      |CustomerID|
      |CustomerName|
      |AccountBranch|


  @Mobile @SC_2741358
  Scenario:TermDeposit|SC_2741358|Verify search does not return records from other currency
    Given the mobile app is launched
    And user logs into the application under "Loginflow" screen
    And user swipes and clicks the "Deposits" button under "DepositHomepage" screen
   Then the user retrieves the following mobile field text under "DepositHomepage" screen
    |Deposits|
    And user clicks the "AEDWidgetAccount" button under "DepositHomepage" screen
    Then the user verifies the following elements should be "enabled" under "DepositHomepage" screen
      |DepositSummaryHeader|
    When user enters the following Mobile field details under "DepositHomepage" screen
      |USDAccountNumber|
    And user clicks the "SearchIcon" button under "DepositHomepage" screen
    Then user verifies the following mobile field details under "DepositHomepage" screen
      |NoRecordsFound|

#    Given user "Maker" is logged into "OBDX" with appropriate privileges