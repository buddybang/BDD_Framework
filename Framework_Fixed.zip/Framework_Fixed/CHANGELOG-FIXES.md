# Fix log — "Make it trustworthy" (2026-09-30)

Base: source from branch `payment_tracker` copied into the Framework root. Focus: Mobile automation on BrowserStack.
Verified: `mvn -DskipTests test-compile` passes. No scenarios were executed (no BrowserStack run).

| # | File | What changed | Why |
|---|------|--------------|-----|
| 1 | `src/test/java/.../runners/TestRunner.java` | Removed hard-coded `tags = "@Mobile and @SC_2741358"`. Data provider is now always `parallel = true` (thread count is still decided by `ParallelExecutionListener`, 1 by default). | The annotation tag overrode the command line, so every run executed one scenario only. The old `parallel=false` made `-Dparallel=true` do nothing for this runner. |
| 2 | `pom.xml` | Added default properties `cucumber.tags` (empty), `parallel=false`, `threads=1`. | Surefire forwards these to Cucumber/TestNG. Without defaults an unset value could arrive as the literal text `${cucumber.tags}` and break the tag filter. Empty tags = run all. |
| 3 | `src/main/java/.../utils/PropertiesHelpers.java` | New `getRequiredValue(key)` that throws a clear message for a missing or empty key. `getValue(key)` now honours a `-D<KEY>` override first. | Missing keys used to return null and crash later with an opaque NullPointerException. The `-D` overrides documented in `config.properties` (e.g. `-DMOBILE_EXECUTION_MODE`) were not actually applied. |
| 4 | `src/main/java/.../constants/FrameworkConstants.java` | Mandatory settings use `getRequiredValue`. BrowserStack/BS_* settings use a null-safe `optionalValue`. New `validateBrowserStackConfig()` lists every missing BrowserStack setting in one message. | Fail fast with a readable error. BrowserStack settings are checked only when a BrowserStack session starts, so web or local runs are not blocked. |
| 5 | `src/main/java/.../driver/MobileDriverManager.java` | One line added: `FrameworkConstants.validateBrowserStackConfig();` before creating a BrowserStack driver. | Wires in the check from #4. |
| 6 | `src/main/java/.../users/UserCredentialsManager.java` | `checkoutUserPair()` now waits at most 300s (override `-DUSER_POOL_TIMEOUT_SECONDS=<n>`) and throws a clear error. `checkinUserPair()` no longer blocks and ignores duplicate returns. | A run could hang forever when no pair was free. A double check-in could over-fill the pool. |
| 7 | `src/test/java/.../hooks/ApplicationHooks.java` | `@Before` only checks out a user pair for scenarios that are not `@Mobile` or `@API`. Logging uses a null-safe pair id. | Only web steps use the pair. With one pair in the pool, every mobile scenario was queued behind it, which blocked parallel BrowserStack devices. |
| 8 | `src/main/java/.../context/ScenarioContext.java` | `page` changed from `static` to an instance field. | A static page was shared by all threads, so parallel web scenarios could drive each other's browser. `ScenarioContext` is created per scenario by PicoContainer. |
| 9 | `src/test/java/.../stepdefinitions/Web/CustomerMaintenanceSteps.java` | Import fixed to `pages.Web.CustomerMaintenancePage`. | Pre-existing compile error on this branch (class lives in the `pages.Web` package). Needed to compile and verify. |

## Follow-up changes (same day, after first BrowserStack run)

| # | File | What changed | Why |
|---|------|--------------|-----|
| 10 | `src/main/java/.../driver/MobileDriverManager.java` | `getBrowserStackProxy()` returns no proxy when `-DBS_USE_PROXY=false` (default `true`, so client-site behaviour is unchanged). | The configured corporate proxy host cannot be resolved outside the client network. With the switch off, the JDK connects directly, or via the OS proxy when `-Djava.net.useSystemProxies=true` is also passed. |
| 11 | `src/main/resources/config/config.properties` | `BROWSERSTACK_APP_URL` changed from `bs://e5aa30f…` to `bs://fd7d4745…` (newest upload, 2026-09-22). | The old app ID no longer exists in the BrowserStack account, so session creation hung until the 90s timeout. Replace it again whenever a new build is uploaded; BrowserStack deletes old uploads. |

| 12 | `pom.xml` | Default `cucumber.tags` is now `@Mobile` (was empty = everything). New property `bs.use.proxy` (default `true`) passed to the tests as `BS_USE_PROXY`. `java.net.useSystemProxies=true` is always passed. New Maven profile `offsite` sets `bs.use.proxy=false`. | This framework is mostly for mobile, so a plain `mvn test` runs only mobile scenarios instead of the broken web/API ones. Working outside the client network only needs `-Poffsite` (tick it in IntelliJ's Maven panel) instead of several `-D` flags. Override tags with `-Dcucumber.tags=""` (all) or `-Dcucumber.tags="@SC_xxx"`. |

| 13 | `flexcube-features/Mobile/01.MobileLogin.feature` | Scenario names `\|SC_2741351\|…` and `Mobile\|SC_2700567\|…` changed to module `TermDeposit\|…`. The step `the user verifies the following mobile elements should be visible under "X" screen` (2 places, no step definition) changed to the existing step `the user verifies the following elements should be "visible" under "X" screen`. | The module in the scenario name selects the locator and test-data files, and the old names matched none. The old step wording was undefined, so the scenarios stopped with UndefinedStepException. |

Result after #13 (`mvn test -Poffsite`, real BrowserStack devices): login and the Deposits page now work, so the scenarios run further, but all 3 failed on test content/stability: SC_2741351 has no `USDAccountNumber` in `testdata/02.TERMDEPOSIT` test data; SC_2700567 and SC_2741358 lost the BrowserStack session while typing the PIN (`Error communicating with the remote browser`). SC_2741358 passed in two earlier runs, so this looks intermittent.

Earlier result of `mvn test -Poffsite` (3 `@Mobile` scenarios, real BrowserStack sessions): 1 passed (`TermDeposit\|SC_2741358`), 2 failed with `OR path not found: /Loginflow/Login` and `Mobile/Loginflow/Login`. Cause: the scenario names in `01.MobileLogin.feature` have an empty or unknown module (`\|SC_2741351\|...`, `Mobile\|SC_2700567\|...`). The module in the name selects the object-repository file, and only `Term` / `TermDeposit` exist. Not changed yet; needs the right module name from the feature owner.

Earlier result: `SC_2741358` (`@Mobile`) passed on a BrowserStack Android device (1 run, 0 failures, about 320s) with the proxy off.
Known minor issue seen: the failure screenshot at session close logged "Error communicating with the remote browser" (scenario still passed).

## How to run now
```
mvn test -Dcucumber.tags="@Mobile and @SC_2741358"
mvn test -Dcucumber.tags="@Mobile" -Dparallel=true -Dthreads=3 -DMOBILE_EXECUTION_MODE=browserstack
mvn test                                   # no tags = all scenarios
```
Optional: `-DUSER_POOL_TIMEOUT_SECONDS=600`.
Outside the client network add `"-DBS_USE_PROXY=false" "-Djava.net.useSystemProxies=true"` (quote each `-D` in PowerShell).

## Behaviour changes to be aware of
- Runs with no `-Dcucumber.tags` now execute all scenarios (before: one mobile scenario).
- A missing mandatory config key stops the run at start-up with the key name.
- A web scenario waits at most 300s for a user pair, then fails with an explanation.

## Not changed (still open)
Secrets in `config.properties` and `testdata/Users/*.json`, git token in `.git/config`, `setIgnoreHTTPSErrors(true)`, `Thread.sleep` calls, swallowed exceptions, commented-out code in `MobileDriverManager`, pom duplicate dependencies, `Launcher` glue package.
