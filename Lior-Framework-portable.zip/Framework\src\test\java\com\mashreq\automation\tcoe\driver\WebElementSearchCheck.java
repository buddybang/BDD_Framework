package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.keywords.WebUI;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.PlaywrightException;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.function.Supplier;

/**
 * Recorded web tests on FLEXCUBE-like screens (real Chrome, no application): seen 2026-10-08 as
 * "Element not found with selector: [Password|//input[@id='BTN_OK']] within 60000ms".
 * <ul>
 * <li>a locator that matches a hidden copy AND the visible button (FLEXCUBE pages repeat BTN_OK) - was a swallowed
 *     "strict mode" error, reported as not found after the full timeout;</li>
 * <li>a button in a pop-up window the application opened - only the first window and its frames were searched;</li>
 * <li>a button in a frame inside the pop-up; the pop-up closing and the test carrying on in the main window.</li>
 * </ul>
 * mvn -o test -Dsuite.xml.file=src/test/resources/suites/browser-portability.xml -DHEADLESS=true
 */
public class WebElementSearchCheck {

    private static final class NoLog implements IActionLogger {
        @Override
        public <T> T logAction(String description, Supplier<T> action) {
            return action.get();
        }
    }

    @Test
    public void recordedClicksFindTheirElementInPopUpsFramesAndAmongCopies() {
        DriverManager.initDriver("chrome");
        try {
            Page main = DriverManager.getPage();
            ScenarioContext ctx = new ScenarioContext();
            ctx.setPage(main);
            WebUI web = new WebUI(ctx, new NoLog());
            main.setContent("<h1>Login</h1>"
                    + "<div style='display:none'><input type='button' id='BTN_OK' value='OK' onclick=\"document.title='hidden'\"></div>"
                    + "<input type='button' id='BTN_OK' value='OK' onclick=\"document.title='visible'\">"
                    + "<button id='open' onclick='openSub()'>Open</button>"
                    + "<script>function openSub() {"
                    + " var w = window.open('', 'sub', 'width=500,height=400');"
                    + " w.document.write(\"<h2>Sub screen</h2><iframe name='f'></iframe>\"); w.document.close();"
                    + " var d = w.document.querySelector('iframe').contentDocument;"
                    + " d.write(\"<input type='button' id='BTN_SAVE' value='Save'>\"); d.close();"
                    + " d.getElementById('BTN_SAVE').onclick = function () { document.title = 'saved'; w.close(); };"
                    + "}</script>");

            // 1. two matches, the first one hidden: the visible one is clicked, at once (not after 60 s)
            long t0 = System.currentTimeMillis();
            web.click("Password|//input[@id='BTN_OK']");
            Assert.assertEquals(main.title(), "visible");
            Assert.assertTrue(System.currentTimeMillis() - t0 < 10000, "found at once, not after the full timeout");

            // 2. a button in a frame of a pop-up window; the pop-up closes itself; 3. the test goes on in the main window
            web.click("Open|//button[@id='open']");
            web.click("Save|//input[@id='BTN_SAVE']");
            main.waitForCondition(() -> "saved".equals(main.title()), new Page.WaitForConditionOptions().setTimeout(10000));
            Assert.assertEquals(main.title(), "saved", "the click in the pop-up's frame reached the application");
            web.click("Password|//input[@id='BTN_OK']");
            Assert.assertEquals(main.title(), "visible", "after the pop-up closed the test carries on in the main window");
            Assert.assertSame(ctx.getPage(), main);

            // 4. really missing: a clear message, not a swallowed error
            PlaywrightException missing = null;
            try {
                web.findElementInFrame("Nothing|//input[@id='NOT_THERE']");
            } catch (PlaywrightException e) {
                missing = e;
            }
            Assert.assertNotNull(missing);
            Assert.assertTrue(missing.getMessage().contains("open window(s)"), missing.getMessage());
        } finally {
            DriverManager.closeDriver("element-search-check");
        }
    }
}
