package com.mashreq.automation.tcoe.stepdefinitions.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.pages.Mobile.CommonMobilePage;
import com.mashreq.automation.tcoe.utils.FeatureStepCollector;
import io.cucumber.java.en.And;

import java.util.function.Supplier;

/**
 * Device key steps, and the action logger shared by the mobile step classes (LiorMobileSteps uses it too, so it stays here).
 * The steps "User enter the {string}" and "the user enters credentials from test data {string} and {string}" were removed
 * (2026-10-06): they read the hard-coded module "Mobile/Loginflow" whose object repository was removed, so they always
 * failed, and no feature used them. Use "user enters the following Mobile field details under {string} screen".
 */
public class MobileLoginSteps {

    private final CommonMobilePage page;

    /** Action logger connected to FeatureStepCollector (actions appear in the custom report). */
    static class LocalActionLogger implements IActionLogger {

        private final FeatureStepCollector collector =
                new FeatureStepCollector();

        @Override
        public <T> T logAction(
                String description,
                Supplier<T> action) {

            return collector.logAction(
                    description,
                    action
            );
        }
    }

    public MobileLoginSteps(ScenarioContext ctx) {
        this.page = new CommonMobilePage(ctx, new LocalActionLogger());
    }

    /** Back: the Android Back key; on iOS the app's navigation back. */
    @And("user presses Android back button")
    public void userPressesAndroidBackButton() {
        page.pressBackButton();
    }

    @And("user presses Android home button")
    public void userPressesAndroidHomeButton() {
        page.pressHomeButton();
    }

    @And("user opens recent apps")
    public void userOpensRecentApps() {
        page.openRecentAppsScreen();
    }
}
