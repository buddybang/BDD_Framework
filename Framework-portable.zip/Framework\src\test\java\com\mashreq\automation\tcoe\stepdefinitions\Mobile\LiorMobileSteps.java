package com.mashreq.automation.tcoe.stepdefinitions.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.pages.Mobile.CommonMobilePage;
import com.mashreq.automation.tcoe.utils.DataHandler;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.utils.OneTimeCodes;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import java.time.Duration;
import java.util.Collections;

/**
 * Added by Lior (generated - Lior rewrites this file; put your own steps in another class).
 * Mobile steps that run only when the scenario's test data has the field. A test recorded in several versions (other data)
 * is one Scenario Outline; a field that only one version uses is only in that version's test data.
 */
public class LiorMobileSteps {

    private final ScenarioContext ctx;
    private final CommonMobilePage page;
    private final DataHandler dataHandler = new DataHandler();

    public LiorMobileSteps(ScenarioContext ctx) {
        this.ctx = ctx;
        this.page = new CommonMobilePage(ctx, new MobileLoginSteps.LocalActionLogger());
    }

    @And("user enters the following Mobile field details under {string} screen if they are in the test data")
    public void userEntersFieldsIfInTestData(String screen, DataTable table) {
        for (String field : table.asList()) {
            String value = valueOrNull(field);
            if (value == null) {
                LogUtils.info("Skipped '" + field + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
                continue;
            }
            page.enter(ctx.getCurrentModule(), screen, field, value);
        }
    }

    @And("user clicks the {string} button under {string} screen if it is in the test data")
    public void userClicksIfInTestData(String element, String screen) {
        if (valueOrNull(element) == null) {
            LogUtils.info("Skipped tap on '" + element + "' on " + screen + ": not in the test data of " + ctx.getScenarioId());
            return;
        }
        page.clickButton(element, ctx.getCurrentModule(), screen);
    }

    /**
     * Reads the one-time password (or any code) an element shows and keeps it for this scenario. The test data then types it with
     * ${fromScreen:Screen.Element}. Used when the code is shown on one screen and typed on another, or in a message that disappears.
     */
    @And("user remembers the text of the following mobile elements under {string} screen")
    public void userRemembersText(String screen, DataTable table) {
        for (String field : table.asList()) {
            OneTimeCodes.remember(screen, field);
        }
    }

    /**
     * "Slide to confirm" (Lior action Slide): holds the handle, then drags it slowly to the edge of the screen. The element is
     * the handle or the whole slider bar; on a bar the handle is taken to sit at its start (left end when sliding right).
     */
    @And("user slides the {string} element {word} under {string} screen")
    public void userSlidesElement(String element, String direction, String screen) {
        String d = direction == null ? "" : direction.trim().toLowerCase(java.util.Locale.ROOT);
        if (!d.equals("right") && !d.equals("left")) {
            throw new IllegalArgumentException("Slide direction must be 'right' or 'left', not '" + direction + "'");
        }
        MobileUI mobile = new MobileUI(ctx, new MobileLoginSteps.LocalActionLogger());
        WebElement handle = mobile.findElement(LocatorUtils.byPath(ctx.getCurrentModule() + "/" + screen + "/" + element));
        Rectangle r = handle.getRect();
        Dimension size = ctx.getMobileDriver().manage().window().getSize();
        int inset = Math.min(r.getWidth() / 2, Math.max(1, r.getHeight() / 2)); // a square handle: its centre; a long bar: its end
        int y = r.getY() + r.getHeight() / 2;
        int startX = d.equals("right") ? r.getX() + inset : r.getX() + r.getWidth() - inset;
        int endX = d.equals("right") ? (int) (size.getWidth() * 0.97) : (int) (size.getWidth() * 0.03);
        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
        Sequence slide = new Sequence(finger, 1);
        slide.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), startX, y));
        slide.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
        slide.addAction(new Pause(finger, Duration.ofMillis(250)));
        slide.addAction(finger.createPointerMove(Duration.ofMillis(900), PointerInput.Origin.viewport(), endX, y));
        slide.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
        ctx.getMobileDriver().perform(Collections.singletonList(slide));
        LogUtils.info("Slid '" + element + "' " + d + " on " + screen + " (" + startX + "," + y + " -> " + endX + "," + y + ")");
    }

    private String valueOrNull(String field) {
        try {
            String v = dataHandler.getTestDataOrThrow(ctx.getCurrentModule(), ctx.getScenarioId(), field);
            return v == null || v.trim().isEmpty() ? null : v;
        } catch (OneTimeCodes.CodeException otpProblem) {
            throw otpProblem; // the field IS in the test data: its one-time password could not be worked out
        } catch (IllegalArgumentException notThere) {
            return null; // only "field not in the test data"; a missing folder / file or broken JSON fails the step
        }
    }
}
