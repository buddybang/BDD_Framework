package com.mashreq.automation.tcoe.utils;

import com.mashreq.automation.tcoe.context.Platform;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.keywords.WebUI;
import org.openqa.selenium.WebElement;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.awt.GraphicsEnvironment;
import java.io.Console;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * One-time passwords (OTP) in the test data. A fixed test OTP is simply written as it is ("OneTimePassword": "123456").
 * An OTP that changes on every run is written as one of these values (see {@link TestDataTokens}):
 * <pre>
 * ${fromScreen:Transfers.OtpMessage}     the code the application shows on that element ("Your OTP is 482913" gives 482913)
 * ${fromScreen:Transfers.OtpMessage:3}   only the 3rd character of it, for OTP boxes that take one digit each
 * ${ask:Type the OTP sent to the phone}  a person types it in a small window while the test runs (local runs only)
 * ${totp:JBSWY3DPEHPK3PXP}               the 6-digit code an authenticator app shows for that secret key (also ${totp:KEY:8})
 * </pre>
 * The step "user remembers the text of the following elements under X screen" reads an element early (an OTP shown on one
 * screen and typed on the next, or a message that disappears); ${fromScreen:...} then uses what was remembered.
 */
public final class OneTimeCodes {

    /** The OTP could not be worked out. Never means "field not in the test data": steps must not skip on it. */
    public static final class CodeException extends RuntimeException {
        public CodeException(String message) {
            super(message);
        }

        public CodeException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static final String REMEMBERED = "lior.remembered.";
    private static final String ASKED = "lior.asked.";
    private static final int ASK_SECONDS = 300;
    private static final Pattern KEYWORD = Pattern.compile("(?i)(otp|one[- ]?time|pass ?code|password|verification|security code|code|pin|token)");
    private static final Pattern DIGITS = Pattern.compile("(?<![A-Za-z0-9])\\d{4,10}(?![A-Za-z0-9])");
    private static final Pattern MIXED = Pattern.compile("(?<![A-Za-z0-9])(?=[A-Za-z0-9]*\\d)(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{4,10}(?![A-Za-z0-9])");

    private OneTimeCodes() {
    }

    // ------------------------------------------------------------------ from the screen

    /** {@code Screen.Element} or {@code Screen.Element:N} (the Nth character). */
    static String fromScreen(String arg) {
        if (arg == null || arg.isBlank()) {
            throw new CodeException("${fromScreen:...} needs the screen and element, for example ${fromScreen:Transfers.OtpMessage}.");
        }
        String spec = arg.trim();
        int position = 0;
        Matcher pos = Pattern.compile("^(.*):(\\d+)$").matcher(spec);
        if (pos.matches()) {
            spec = pos.group(1).trim();
            position = Integer.parseInt(pos.group(2));
        }
        int dot = spec.lastIndexOf('.');
        if (dot <= 0 || dot == spec.length() - 1) {
            throw new CodeException("${fromScreen:" + arg + "} must be Screen.Element, for example ${fromScreen:Transfers.OtpMessage}.");
        }
        String screen = spec.substring(0, dot).trim();
        String field = spec.substring(dot + 1).trim();
        ScenarioContext ctx = context();
        Object kept = ctx.getScenarioData(REMEMBERED + key(screen, field));
        String code = kept != null ? String.valueOf(kept) : extractCode(readText(ctx, screen, field), screen + "." + field);
        if (position <= 0) {
            LogUtils.info("One-time password taken from '" + field + "' on " + screen + (kept != null ? " (remembered earlier)." : "."));
            return code;
        }
        if (position > code.length()) {
            throw new CodeException("The one-time password shown in '" + field + "' on " + screen + " has " + code.length()
                    + " characters, but the test data asks for character " + position + ".");
        }
        return String.valueOf(code.charAt(position - 1));
    }

    /** Reads the element now and keeps the code it shows for the rest of the scenario. Returns the code. */
    public static String remember(String screen, String field) {
        ScenarioContext ctx = context();
        String text = readText(ctx, screen, field);
        String code = extractCode(text, screen + "." + field);
        ctx.setScenarioData(REMEMBERED + key(screen, field), code);
        LogUtils.info("Remembered the code shown in '" + field + "' on " + screen + " (" + code.length() + " characters).");
        return code;
    }

    /**
     * The text an element shows now (web: its text, else the value of a read-only box; mobile: text, else content-desc / label /
     * value / name). Used for one-time passwords and for values a journey hands to its next part (see {@link Journey}).
     */
    public static String shownText(String screen, String field) {
        try {
            return readText(context(), screen, field);
        } catch (CodeException e) {
            throw new IllegalStateException(e.getMessage().replace("The one-time password could not be read: ", ""), e);
        }
    }

    private static String readText(ScenarioContext ctx, String screen, String field) {
        String module = ctx.getCurrentModule();
        if (module == null || module.isBlank()) {
            throw new CodeException("Cannot read '" + field + "' on " + screen + ": the scenario has no module (scenario name Module|SC_id|title).");
        }
        String locator = LocatorUtils.byPath(module + "/" + screen + "/" + field);
        try {
            if (ctx.getPlatform() == Platform.MOBILE) {
                WebElement el = new MobileUI(ctx, null).findElement(locator);
                String t = el.getText();
                for (String attr : new String[]{"content-desc", "label", "value", "name"}) {
                    if (t != null && !t.isBlank()) {
                        break;
                    }
                    try {
                        t = el.getAttribute(attr);
                    } catch (RuntimeException ignored) {
                        // not every platform knows every attribute
                    }
                }
                return t == null ? "" : t;
            }
            com.microsoft.playwright.Locator el = new WebUI(ctx, null).findElementInFrame(locator);
            String t = el.innerText();
            if (t == null || t.isBlank()) {
                try {
                    t = el.inputValue(); // a read-only box that shows the code
                } catch (RuntimeException notAnInput) {
                    t = el.getAttribute("value");
                }
            }
            return t == null ? "" : t;
        } catch (CodeException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new CodeException("The one-time password could not be read: '" + field + "' is not shown on the " + screen
                    + " screen. " + e.getMessage(), e);
        }
    }

    /**
     * The code inside a message: the whole text when it is only the code, else the first 4-10 digit number after a word
     * such as OTP / code / password, else the first 4-10 digit number, else the first 4-10 letters-and-digits word.
     */
    public static String extractCode(String text, String where) {
        String t = text == null ? "" : text.replace(' ', ' ').trim();
        if (t.matches("(?=.*\\d)[A-Za-z0-9]{3,12}")) {
            return t;
        }
        Matcher k = KEYWORD.matcher(t);
        while (k.find()) {
            Matcher d = DIGITS.matcher(t);
            if (d.find(k.end())) {
                return d.group();
            }
        }
        Matcher d = DIGITS.matcher(t);
        if (d.find()) {
            return d.group();
        }
        Matcher m = MIXED.matcher(t);
        if (m.find()) {
            return m.group();
        }
        throw new CodeException("No one-time password found in " + where + ". It shows: \"" + (t.length() > 120 ? t.substring(0, 120) + "..." : t) + "\"");
    }

    // ------------------------------------------------------------------ a person types it

    /** Asks once per scenario for each question; the answer is reused when the same value is read again. */
    static String ask(String question) {
        String q = question == null || question.isBlank() ? "Type the one-time password" : question.trim();
        ScenarioContext ctx = ScenarioContext.get();
        if (ctx != null && ctx.getScenarioData(ASKED + q) != null) {
            return String.valueOf(ctx.getScenarioData(ASKED + q));
        }
        String scenario = ctx == null || ctx.getScenarioId() == null ? "" : ctx.getScenarioId();
        String answer;
        synchronized (OneTimeCodes.class) { // parallel scenarios ask one after the other
            answer = GraphicsEnvironment.isHeadless() ? askOnConsole(q, scenario) : askInWindow(q, scenario);
        }
        if (answer == null || answer.isBlank()) {
            throw new CodeException("Nobody typed the one-time password (\"" + q + "\") within " + ASK_SECONDS / 60
                    + " minutes. Tests that need a person cannot run unattended (BrowserStack, pipelines): ask the application team for a fixed test OTP.");
        }
        answer = answer.trim();
        if (ctx != null) {
            ctx.setScenarioData(ASKED + q, answer);
        }
        return answer;
    }

    private static String askInWindow(String question, String scenario) {
        JOptionPane pane = new JOptionPane(question, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_CANCEL_OPTION);
        pane.setWantsInput(true);
        pane.setInitialSelectionValue("");
        JDialog dialog = pane.createDialog(null, "Test " + scenario + " needs you");
        dialog.setAlwaysOnTop(true);
        dialog.setModal(true);
        Timer giveUp = new Timer(ASK_SECONDS * 1000, e -> dialog.dispose());
        giveUp.setRepeats(false);
        giveUp.start();
        LogUtils.info("Waiting for a person to type: " + question);
        dialog.setVisible(true); // blocks until OK, Cancel or the time is up
        giveUp.stop();
        dialog.dispose();
        Object v = pane.getInputValue();
        boolean ok = Integer.valueOf(JOptionPane.OK_OPTION).equals(pane.getValue());
        return ok && v != null && v != JOptionPane.UNINITIALIZED_VALUE ? String.valueOf(v) : null;
    }

    private static String askOnConsole(String question, String scenario) {
        Console console = System.console();
        if (console != null) {
            return console.readLine("[%s] %s: ", scenario, question);
        }
        throw new CodeException("The test data asks a person to type the one-time password (\"" + question
                + "\"), but this run has no screen or console. Run it on a desktop, or ask the application team for a fixed test OTP.");
    }

    // ------------------------------------------------------------------ authenticator app (TOTP, RFC 6238)

    /** {@code SECRET} or {@code SECRET:digits}; the secret is the Base32 key shown when the authenticator app was set up. */
    static String totp(String arg) {
        if (arg == null || arg.isBlank()) {
            throw new CodeException("${totp:...} needs the secret key of the authenticator app, for example ${totp:JBSWY3DPEHPK3PXP}.");
        }
        String[] parts = arg.trim().split(":");
        int digits = 6;
        if (parts.length > 1) {
            try {
                digits = Integer.parseInt(parts[1].trim());
            } catch (NumberFormatException e) {
                throw new CodeException("${totp:KEY:digits}: '" + parts[1] + "' is not a number of digits.");
            }
        }
        byte[] key = base32(parts[0]);
        long now = System.currentTimeMillis() / 1000L;
        if (30 - now % 30 < 3) { // the code would run out while it is typed: wait for the next one
            sleep((30 - now % 30) * 1000L + 200);
            now = System.currentTimeMillis() / 1000L;
        }
        return totpAt(key, now / 30, digits);
    }

    static String totpAt(byte[] key, long counter, int digits) {
        try {
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(new SecretKeySpec(key, "HmacSHA1"));
            byte[] h = mac.doFinal(ByteBuffer.allocate(8).putLong(counter).array());
            int o = h[h.length - 1] & 0x0f;
            int bin = ((h[o] & 0x7f) << 24) | ((h[o + 1] & 0xff) << 16) | ((h[o + 2] & 0xff) << 8) | (h[o + 3] & 0xff);
            int mod = (int) Math.pow(10, Math.max(4, Math.min(digits, 9)));
            return String.format(Locale.ROOT, "%0" + Math.max(4, Math.min(digits, 9)) + "d", bin % mod);
        } catch (java.security.GeneralSecurityException e) {
            throw new CodeException("Could not work out the authenticator code: " + e.getMessage(), e);
        }
    }

    static byte[] base32(String secret) {
        String s = secret.replace(" ", "").replace("-", "").replace("=", "").toUpperCase(Locale.ROOT);
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int buffer = 0;
        int bits = 0;
        for (char c : s.toCharArray()) {
            int v = alphabet.indexOf(c);
            if (v < 0) {
                throw new CodeException("The authenticator secret key may only have the letters A-Z and digits 2-7 (found '" + c + "').");
            }
            buffer = (buffer << 5) | v;
            bits += 5;
            if (bits >= 8) {
                out.write((buffer >> (bits - 8)) & 0xff);
                bits -= 8;
            }
        }
        if (out.size() == 0) {
            throw new CodeException("The authenticator secret key is empty.");
        }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ helpers

    private static ScenarioContext context() {
        ScenarioContext ctx = ScenarioContext.get();
        if (ctx == null) {
            throw new CodeException("A one-time password can only be read from the screen while a scenario runs.");
        }
        return ctx;
    }

    private static String key(String screen, String field) {
        return (screen + "." + field).toLowerCase(Locale.ROOT);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
