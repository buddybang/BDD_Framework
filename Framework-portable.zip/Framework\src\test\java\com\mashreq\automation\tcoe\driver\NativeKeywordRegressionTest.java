package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.List;

/**
 * Offline regression tests of the native mobile keywords (typing, text, locators) against the fake Appium server.
 * Run: mvn test -Pmobile-regression. Adapted from Framework_Fixed's NativeKeywordRegressionTest.
 */
public class NativeKeywordRegressionTest {

    @AfterMethod(alwaysRun = true)
    public void cleanUp() {
        MobileDriverManager.quitDriver();
        ScenarioContext.clear();
        ScreenshotContextHolder.clear();
    }

    private static MobileUI keywords(FakeAppium server) throws Exception {
        ScenarioContext ctx = MobileSessionRegressionTest.mobileContext();
        AppiumDriver driver = MobileSessionRegressionTest.bindManager(server.driver());
        ctx.setMobileDriver(driver);
        return new MobileUI(ctx, null, Duration.ofSeconds(2));
    }

    /** The element commands, without attribute reads / visibility checks. */
    private static List<String> actions(FakeAppium server) {
        return server.elementCalls.stream().filter(c -> c.equals("click") || c.equals("clear") || c.equals("value")).toList();
    }

    @Test
    public void typingFocusesThenClearsThenTypesOnBothPlatforms() throws Exception {
        for (String platform : new String[]{"Android", "iOS"}) {
            try (FakeAppium server = new FakeAppium()) {
                server.platformName = platform;
                server.elementPresent = true;
                server.attributes.put("type", "XCUIElementTypeTextField");
                keywords(server).sendKeys("Amount|id|amount", "123");
                Assert.assertEquals(actions(server), List.of("click", "clear", "value"), platform);
            } finally {
                cleanUp();
            }
        }
    }

    @Test
    public void clearFailureKeepsCauseAndNeverTypes() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            server.elementPresent = true;
            server.failClear = true;
            MobileUI ui = keywords(server);
            AssertionError failure = Assert.expectThrows(AssertionError.class, () -> ui.sendKeys("Amount|id|amount", "123"));
            Assert.assertTrue(failure.getMessage().contains("clearing the field"), failure.getMessage());
            Assert.assertNotNull(failure.getCause());
            Assert.assertFalse(server.elementCalls.contains("value"), "nothing may be typed after a failed clear");
        }
    }

    @Test
    public void iosRejectsANonEditableTargetBeforeTouchingIt() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            server.platformName = "iOS";
            server.elementPresent = true;
            server.attributes.put("type", "XCUIElementTypeStaticText");
            MobileUI ui = keywords(server);
            AssertionError failure = Assert.expectThrows(AssertionError.class, () -> ui.sendKeys("Label|id|label", "123"));
            Assert.assertTrue(failure.getMessage().contains("not a text field"), failure.getMessage());
            Assert.assertTrue(actions(server).isEmpty(), "no tap / clear / typing on a label: " + server.elementCalls);
        }
    }

    @Test
    public void iosInputReadsItsValueAlsoWhenEmpty() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            server.platformName = "iOS";
            server.elementPresent = true;
            server.attributes.put("type", "XCUIElementTypeTextField");
            server.attributes.put("value", "123");
            server.attributes.put("label", "Amount");
            server.elementText = "Amount";
            MobileUI ui = keywords(server);
            Assert.assertEquals(ui.getText("Amount|id|amount"), "123");
            server.attributes.put("type", "XCUIElementTypeSecureTextField");
            server.attributes.put("value", "");
            server.attributes.put("label", "Password");
            Assert.assertEquals(ui.getText("Password|id|pw"), "", "an empty field is empty, not its label");
        }
    }

    @Test
    public void labelAndAndroidTextFallbacks() throws Exception {
        try (FakeAppium server = new FakeAppium()) {
            server.platformName = "iOS";
            server.elementPresent = true;
            server.attributes.put("type", "XCUIElementTypeStaticText");
            server.attributes.put("label", "Balance");
            server.attributes.put("name", "balance_id");
            Assert.assertEquals(keywords(server).getText("Balance|id|balance"), "Balance");
        } finally {
            cleanUp();
        }
        try (FakeAppium server = new FakeAppium()) {
            server.elementPresent = true;
            server.attributes.put("text", "Balance");
            Assert.assertEquals(keywords(server).getText("Balance|id|balance"), "Balance");
        }
    }

    @Test
    public void nativeLocatorStrategiesAndUnknownPrefixes() throws Exception {
        MobileUI ui = new MobileUI(new ScenarioContext(), null);
        Method resolve = MobileUI.class.getDeclaredMethod("resolveLocator", String.class);
        resolve.setAccessible(true);
        Assert.assertEquals(using(resolve.invoke(ui, "iospredicate|type == 'XCUIElementTypeTextField'")), "-ios predicate string");
        Assert.assertEquals(using(resolve.invoke(ui, "predicate|name == 'Pay'")), "-ios predicate string");
        Assert.assertEquals(using(resolve.invoke(ui, "iosclasschain|**/XCUIElementTypeButton")), "-ios class chain");
        Assert.assertEquals(using(resolve.invoke(ui, "Field|classchain|**/XCUIElementTypeCell")), "-ios class chain");
        Assert.assertEquals(using(resolve.invoke(ui, "androiduiautomator|new UiSelector().text(\"OK\")")), "-android uiautomator");
        Assert.assertEquals(using(resolve.invoke(ui, "Field|//A | //B")), "xpath");
        for (String bad : new String[]{"unknown thing|something", "Field|", "id|", "hello world"}) {
            try {
                resolve.invoke(ui, bad);
                Assert.fail("accepted: " + bad);
            } catch (InvocationTargetException e) {
                Assert.assertTrue(e.getCause() instanceof IllegalArgumentException, bad + " -> " + e.getCause());
            }
        }
    }

    private static String using(Object by) {
        return ((By.Remotable) by).getRemoteParameters().using();
    }
}
