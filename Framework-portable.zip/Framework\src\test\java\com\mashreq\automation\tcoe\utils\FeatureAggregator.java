package com.mashreq.automation.tcoe.utils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

public class FeatureAggregator {

    private static final String SCENARIO_DIR = System.getProperty("user.dir") + "/reports/latest/custom-report/json/scenarios/";
    private static final String REPORT_DIR = System.getProperty("user.dir") + "/reports/latest/custom-report/json/";
    private static final String HISTORY_ROOT_DIR = System.getProperty("user.dir") + "/reports/history/";
    /**
     * noOfHistoryBackups = total entries to keep in history arrays (including current run)
     * e.g. 5 means: current run + last 4 runs.
     */
    private static final int noOfHistoryBackups = 5;

    /**
     * Generate all reports by reading scenario JS files from disk.
     * @param buildNumber The unique build number for the current execution (from CI or a local timestamp).
     * @param suiteDurationMillis The total wall-clock duration of the suite, calculated in ApplicationHooks.
     */
    public static void generateReports(String buildNumber, long suiteDurationMillis) {
        try {
            File scenarioDir = new File(SCENARIO_DIR);
            if (!scenarioDir.exists() || scenarioDir.listFiles() == null) {
                LogUtils.info("No scenario JS files found in " + SCENARIO_DIR);
                return;
            }

            // 1. Build history caches for BOTH scenarios and features.
            Map<String, List<RunRecord>> scenarioHistoryCache = buildScenarioHistoryCache();
            Map<String, List<RunRecord>> featureHistoryCache = buildFeatureHistoryCache();

            ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

            // Key featureMap by featureUUID (safer than featureName)
            Map<String, FeatureSummary> featureMap = new LinkedHashMap<>();
            Map<String, TagSummary> tagMap = new LinkedHashMap<>();
            List<ScenarioResultMinimal> failedScenarios = new ArrayList<>();

            for (File file : Objects.requireNonNull(scenarioDir.listFiles((d, name) -> name.endsWith(".js")))) {
                // ==================== START OF THE FIX ====================
                // This try-catch block is the solution. It prevents the entire aggregation
                // from crashing if one file is corrupt or incompletely written, which can
                // happen during parallel execution with `mvn test`.
                try {
                    // ==========================================================

                    String jsContent = Files.readString(Paths.get(file.toURI()), java.nio.charset.StandardCharsets.UTF_8);
                    if (jsContent.startsWith("loadScenarioData(") && jsContent.endsWith(");")) {
                        String jsonContent = jsContent.substring("loadScenarioData(".length(), jsContent.length() - 2);

                        // Parse as JSON tree so we can inspect per-step statuses reliably
                        JsonNode root = mapper.readTree(jsonContent);
                        ScenarioResultMinimal scenario = mapper.treeToValue(root, ScenarioResultMinimal.class);

                        // --- compute step-level counts from steps[] (we'll use these both for step-level fields and dashboard mapping)
                        int passedCount = 0, failedCount = 0, skippedCount = 0;
                        int undefinedCount = 0, pendingCount = 0, ambiguousCount = 0;

                        JsonNode stepsNode = root.path("steps");
                        if (stepsNode.isArray()) {
                            for (JsonNode stepNode : stepsNode) {
                                String st = stepNode.path("status").asText("").trim().toUpperCase(Locale.ROOT);
                                switch (st) {
                                    case "PASSED": passedCount++; break;
                                    case "FAILED": failedCount++; break;
                                    case "SKIPPED": skippedCount++; break;
                                    case "UNDEFINED": undefinedCount++; break;
                                    case "PENDING": pendingCount++; break;
                                    case "AMBIGUOUS": ambiguousCount++; break;
                                    default:
                                        // treat unknown/empty as UNDEFINED
                                        undefinedCount++;
                                        break;
                                }
                            }
                        }

                        int totalStepsFromJson = passedCount + failedCount + skippedCount + undefinedCount + pendingCount + ambiguousCount;

                        // Keep scenario's numeric fields consistent with the actual step counts (so step view is accurate)
                        scenario.setTotalSteps(totalStepsFromJson);
                        scenario.setPassedSteps(passedCount);
                        scenario.setFailedSteps(failedCount);   // actual FAILED only
                        scenario.setSkippedSteps(skippedCount);

                        // === set raw counts (so the detail UI can show them separately) ===
                        scenario.setUndefinedSteps(undefinedCount);
                        scenario.setPendingSteps(pendingCount);
                        scenario.setAmbiguousSteps(ambiguousCount);

                        // --- determine rawScenarioStatus (worst step status) to preserve step-level fidelity
                        // Precedence: FAILED > AMBIGUOUS > UNDEFINED > PENDING > SKIPPED > PASSED
                        String rawScenarioStatus = "PASSED";
                        if (failedCount > 0) rawScenarioStatus = "FAILED";
                        else if (ambiguousCount > 0) rawScenarioStatus = "AMBIGUOUS";
                        else if (undefinedCount > 0) rawScenarioStatus = "UNDEFINED";
                        else if (pendingCount > 0) rawScenarioStatus = "PENDING";
                        else if (skippedCount > 0) rawScenarioStatus = "SKIPPED";
                        else if (passedCount > 0) rawScenarioStatus = "PASSED";

                        // Set rawStatus for step-detail fidelity
                        scenario.setRawStatus(rawScenarioStatus);

                        // --- compute dashboard semantics: treat UNDEFINED/PENDING/AMBIGUOUS as failures for dashboard/graphs
                        int dashboardFailedSteps = failedCount + undefinedCount + pendingCount + ambiguousCount;
                        // Cucumber's own result (written since 2026-10-06) also counts: a scenario that did not pass
                        // (e.g. @Before failed, so every step was SKIPPED) must never be shown as passed.
                        String cucumberStatus = root.path("cucumberStatus").asText("").trim().toUpperCase(Locale.ROOT);
                        boolean cucumberNotPassed = !cucumberStatus.isEmpty() && !"PASSED".equals(cucumberStatus);
                        boolean scenarioFailedForDashboard = dashboardFailedSteps > 0 || cucumberNotPassed;
                        String scenarioStatusForAggregation = scenarioFailedForDashboard ? "FAILED" : "PASSED";

                        // Keep scenario.status as aggregation-level status (so feature JSON & dashboard use aggregated semantics)
                        scenario.setStatus(scenarioStatusForAggregation);

                        // -------------------------
                        // WRITE BACK raw counts into the scenario.js JSON wrapper so scenario files also carry them.
                        // Using an ordered ObjectNode so fields appear in desired sequence
                        // (safe attempt - if it fails, aggregation continues and feature JSON will still have counts)
                        // -------------------------
                        try {
                            if (root.isObject()) {
                                com.fasterxml.jackson.databind.node.ObjectNode src = (com.fasterxml.jackson.databind.node.ObjectNode) root;
                                com.fasterxml.jackson.databind.node.ObjectNode ordered = mapper.createObjectNode();

                                // Put fields in the exact order we want in scenario.js
                                if (src.has("featureUUID")) ordered.set("featureUUID", src.get("featureUUID"));
                                if (src.has("featureName")) ordered.set("featureName", src.get("featureName"));
                                if (src.has("featureDescription")) ordered.set("featureDescription", src.get("featureDescription"));
                                if (src.has("featureKeyword")) ordered.set("featureKeyword", src.get("featureKeyword"));
                                if (src.has("featureUri")) ordered.set("featureUri", src.get("featureUri"));
                                if (src.has("featureTags")) ordered.set("featureTags", src.get("featureTags"));

                                if (src.has("scenarioUUID")) ordered.set("scenarioUUID", src.get("scenarioUUID"));
                                if (src.has("scenarioName")) ordered.set("scenarioName", src.get("scenarioName"));
                                if (src.has("description")) ordered.set("description", src.get("description"));
                                if (src.has("tags")) ordered.set("tags", src.get("tags"));

                                if (src.has("startTime")) ordered.set("startTime", src.get("startTime"));
                                if (src.has("endTime")) ordered.set("endTime", src.get("endTime"));
                                if (src.has("durationMillis")) ordered.set("durationMillis", src.get("durationMillis"));

                                // Step counts — put here so they appear before steps/video/status if you want
                                ordered.put("totalSteps", totalStepsFromJson);
                                ordered.put("passedSteps", passedCount);
                                ordered.put("failedSteps", failedCount);
                                ordered.put("skippedSteps", skippedCount);
                                ordered.put("undefinedSteps", undefinedCount);
                                ordered.put("pendingSteps", pendingCount);
                                ordered.put("ambiguousSteps", ambiguousCount);

                                // preserve moduleName and scenarioId if present in original src (or from our scenario object)
                                if (src.has("moduleName")) ordered.set("moduleName", src.get("moduleName"));
                                else if (scenario.getModuleName() != null) ordered.put("moduleName", scenario.getModuleName());
                                if (src.has("scenarioId")) ordered.set("scenarioId", src.get("scenarioId"));
                                else if (scenario.getScenarioId() != null) ordered.put("scenarioId", scenario.getScenarioId());

                                // keep videoPath (if present)
                                if (src.has("videoPath")) ordered.set("videoPath", src.get("videoPath"));
                                if (src.has("cucumberStatus")) ordered.set("cucumberStatus", src.get("cucumberStatus"));

                                // then copy 'steps' array (keep original)
                                if (src.has("steps")) ordered.set("steps", src.get("steps"));

                                // finally preserve/put status and any other remaining fields (history etc.)
                                if (src.has("status")) ordered.set("status", src.get("status"));
                                if (src.has("history")) ordered.set("history", src.get("history"));

                                // copy any leftover unknown fields from src that we didn't explicitly add
                                Iterator<String> it = src.fieldNames();
                                while (it.hasNext()) {
                                    String fn = it.next();
                                    if (!ordered.has(fn)) ordered.set(fn, src.get(fn));
                                }

                                String updatedJson = mapper.writeValueAsString(ordered);
                                String newJsContent = "loadScenarioData(" + updatedJson + ");";
                                Files.writeString(file.toPath(),
                                        newJsContent,
                                        java.nio.charset.StandardCharsets.UTF_8,
                                        java.nio.file.StandardOpenOption.CREATE,
                                        java.nio.file.StandardOpenOption.TRUNCATE_EXISTING);
                            }
                        } catch (Exception ex) {
                            LogUtils.error("Warning: could not write counts back to " + file.getName() + " - " + ex.getMessage());
                        }

                        // -------------------------
                        // Inject scenario history (current run first, then older runs)
                        // -------------------------
                        Long startMillis = null;
                        String runDateStr = null;
                        try {
                            if (scenario.getStartTime() != null && !scenario.getStartTime().isEmpty()) {
                                startMillis = Instant.parse(scenario.getStartTime()).toEpochMilli();
                                runDateStr = Instant.ofEpochMilli(startMillis).toString();
                            }
                        } catch (Exception ignored) { /* fall back to null */ }

                        if (startMillis == null) {
                            startMillis = Instant.now().toEpochMilli();
                            runDateStr = Instant.ofEpochMilli(startMillis).toString();
                        }

                        Long duration = scenario.getDurationMillis() > 0 ? scenario.getDurationMillis() : null;

                        // Use the aggregation-level status for history and master summaries (so dashboard shows as failed if undefined/pending/ambiguous)
                        RunRecord currentRun = new RunRecord(scenarioStatusForAggregation, buildNumber, startMillis, runDateStr, duration);

                        // Build canonical lookup key for scenario (stable across runs)
                        // Preference order:
                        // 1) moduleName::scenarioId
                        // 2) moduleName::scenarioName
                        // 3) scenarioName
                        String currentKey;
                        String curModule = scenario.getModuleName();
                        String curScenarioId = scenario.getScenarioId();
                        String curScenarioName = scenario.getScenarioName();

                        if (curModule != null && !curModule.isEmpty() && curScenarioId != null && !curScenarioId.isEmpty()) {
                            currentKey = curModule + "::" + curScenarioId;
                        } else if (curModule != null && !curModule.isEmpty() && curScenarioName != null && !curScenarioName.isEmpty()) {
                            currentKey = curModule + "::" + curScenarioName;
                        } else if (curScenarioName != null && !curScenarioName.isEmpty()) {
                            currentKey = curScenarioName;
                        } else {
                            currentKey = UUID.randomUUID().toString(); // last resort
                        }


                        List<RunRecord> pastRuns = scenarioHistoryCache.getOrDefault(currentKey, new ArrayList<>());

                        // Build new history: current run first, then existing cached runs. Cap at noOfHistoryBackups and ensure ordering newest->oldest
                        List<RunRecord> newScenarioHistory = new ArrayList<>();
                        newScenarioHistory.add(currentRun);
                        if (!pastRuns.isEmpty()) newScenarioHistory.addAll(pastRuns);

                        // sort by runDateMillis desc (nulls last)
                        newScenarioHistory.sort((a, b) -> {
                            Long aa = a.getRunDateMillis();
                            Long bb = b.getRunDateMillis();
                            if (aa == null && bb == null) return 0;
                            if (aa == null) return 1;
                            if (bb == null) return -1;
                            return bb.compareTo(aa);
                        });

                        if (newScenarioHistory.size() > noOfHistoryBackups) newScenarioHistory = newScenarioHistory.subList(0, noOfHistoryBackups);
                        scenario.setHistory(newScenarioHistory);

                        // Original aggregation logic for features, keyed by featureUUID
                        String featureUUID = scenario.getFeatureUUID();
                        String featureName = scenario.getFeatureName() != null ? scenario.getFeatureName() : (featureUUID != null ? featureUUID : "UNKNOWN_FEATURE");

                        FeatureSummary feature = featureMap.computeIfAbsent(featureUUID != null ? featureUUID : featureName, fn -> {
                            FeatureSummary fs = new FeatureSummary();
                            fs.setFeatureUUID(scenario.getFeatureUUID());
                            fs.setFeatureName(featureName);
                            fs.setFeatureUri(scenario.getFeatureUri());
                            fs.setFeatureTags(scenario.getFeatureTags());
                            fs.setModuleName(scenario.getModuleName());
                            return fs;
                        });

                        // --- MODIFICATION: Track feature's wall-clock time ---
                        // Instead of summing durations, we track the earliest start and latest end time
                        // of all scenarios within this feature. This is accurate for both sequential and parallel runs.
                        try {
                            if (scenario.getStartTime() != null && !scenario.getStartTime().isEmpty() && scenario.getEndTime() != null && !scenario.getEndTime().isEmpty()) {
                                Instant scenarioStart = Instant.parse(scenario.getStartTime());
                                Instant scenarioEnd = Instant.parse(scenario.getEndTime());
                                feature.addScenarioTime(scenarioStart, scenarioEnd);
                            }
                        } catch (Exception e) {
                            LogUtils.error("Warning: Could not parse scenario time to update feature duration for " + featureName);
                        }
                        // --- END MODIFICATION ---

                        feature.getScenarios().add(scenario);
                        feature.setTotalScenarios(feature.getTotalScenarios() + 1);

                        // Use scenarioStatusForAggregation to increment passed/failed scenario counters
                        if ("PASSED".equals(scenarioStatusForAggregation)) {
                            feature.setPassedScenarios(feature.getPassedScenarios() + 1);
                        } else {
                            feature.setFailedScenarios(feature.getFailedScenarios() + 1);
                        }

                        // durations & step totals (use counts computed above)
                        feature.setTotalSteps(feature.getTotalSteps() + totalStepsFromJson);

                        // For step-level numbers shown on dashboard/graphs, count undefined/pending/ambiguous as failed
                        feature.setPassedSteps(feature.getPassedSteps() + passedCount);
                        feature.setFailedSteps(feature.getFailedSteps() + dashboardFailedSteps);
                        feature.setSkippedSteps(feature.getSkippedSteps() + skippedCount);

                        // Set feature status using aggregated failed scenario count
                        feature.setStatus(feature.getFailedScenarios() > 0 ? "FAILED" : "PASSED");

                        // Add scenario to failedScenarios list if considered failed in dashboard
                        if (scenarioFailedForDashboard) {
                            failedScenarios.add(scenario);
                        }

                        // Tag aggregation: use aggregation-level scenario status for counts
                        if (scenario.getTags() != null) {
                            for (String tag : scenario.getTags()) {
                                TagSummary tagSummary = tagMap.computeIfAbsent(tag, TagSummary::new);
                                tagSummary.incrementTotal();
                                if ("PASSED".equals(scenarioStatusForAggregation)) tagSummary.incrementPassed();
                                else if ("FAILED".equals(scenarioStatusForAggregation)) tagSummary.incrementFailed();
                            }
                        }
                    } else {
                        LogUtils.error("Skipping malformed scenario file (missing wrapper): " + file.getName());
                    }

                    // ==================== START OF THE FIX ====================
                } catch (IOException e) {
                    // This will catch MalformedInputException and other I/O errors.
                    // It logs the issue and allows the aggregator to continue with the next file.
                    LogUtils.error("WARNING: Could not process scenario file, it may be corrupt or incomplete. Skipping. File: " + file.getName() + ". Error: " + e.getMessage());
                }
                // ===================== END OF THE FIX =====================
            }

            // --- MODIFICATION: Finalize feature durations AFTER processing all scenarios ---
            // Now that we have the start/end times for all scenarios, we can calculate
            // the true wall-clock duration for each feature.
            for (FeatureSummary feature : featureMap.values()) {
                feature.calculateWallClockDuration();
            }
            // --- END MODIFICATION ---

            // --- START: NEW FEATURE HISTORY INJECTION ---
            // After all scenarios are aggregated, loop through the completed features to inject their history.
            Long masterExecMillis = Instant.now().toEpochMilli();
            String masterRunDate = Instant.ofEpochMilli(masterExecMillis).toString();
            for (FeatureSummary feature : featureMap.values()) {
                RunRecord currentFeatureRun = new RunRecord(feature.getStatus(), buildNumber, masterExecMillis, masterRunDate, feature.getDurationMillis());

                // Use same canonical key as in buildFeatureHistoryCache
                String featureKey;
                if (feature.getModuleName() != null && !feature.getModuleName().isEmpty() && feature.getFeatureName() != null && !feature.getFeatureName().isEmpty()) {
                    featureKey = feature.getModuleName() + "::" + feature.getFeatureName();
                } else if (feature.getFeatureUUID() != null && !feature.getFeatureUUID().isEmpty()) {
                    featureKey = feature.getFeatureUUID();
                } else if (feature.getFeatureName() != null && !feature.getFeatureName().isEmpty()) {
                    featureKey = feature.getFeatureName();
                } else {
                    featureKey = UUID.randomUUID().toString();
                }

                List<RunRecord> pastFeatureRuns = featureHistoryCache.getOrDefault(featureKey, new ArrayList<>());


                List<RunRecord> newFeatureHistory = new ArrayList<>();
                newFeatureHistory.add(currentFeatureRun);
                newFeatureHistory.addAll(pastFeatureRuns);

                // sort desc by runDateMillis (nulls last)
                newFeatureHistory.sort((a, b) -> {
                    Long aa = a.getRunDateMillis();
                    Long bb = b.getRunDateMillis();
                    if (aa == null && bb == null) return 0;
                    if (aa == null) return 1;
                    if (bb == null) return -1;
                    return bb.compareTo(aa);
                });
                if (newFeatureHistory.size() > noOfHistoryBackups) {
                    feature.setHistory(newFeatureHistory.subList(0, noOfHistoryBackups));
                } else {
                    feature.setHistory(newFeatureHistory);
                }
            }
            // --- END: NEW FEATURE HISTORY INJECTION ---

            File reportDir = new File(REPORT_DIR);
            if (!reportDir.exists()) reportDir.mkdirs();

            // ===== 1. master.json =====
            List<Map<String, Object>> masterList = new ArrayList<>();
            for (FeatureSummary f : featureMap.values()) {
                Map<String, Object> fm = new LinkedHashMap<>();
                fm.put("featureUUID", f.getFeatureUUID());
                fm.put("featureName", f.getFeatureName());
                fm.put("moduleName", f.getModuleName()); // NEW
                fm.put("status", f.getStatus());
                fm.put("totalScenarios", f.getTotalScenarios());
                fm.put("passedScenarios", f.getPassedScenarios());
                fm.put("failedScenarios", f.getFailedScenarios());
                fm.put("durationMillis", f.getDurationMillis());
                fm.put("totalSteps", f.getTotalSteps());
                fm.put("passedSteps", f.getPassedSteps());
                fm.put("failedSteps", f.getFailedSteps());
                fm.put("skippedSteps", f.getSkippedSteps());
                fm.put("history", f.getHistory()); // keep feature history in master.json
                masterList.add(fm);
            }
            Map<String, Object> masterJson = new LinkedHashMap<>();
            masterJson.put("buildNumber", buildNumber);

            // --- MODIFICATION: Use the accurate suite duration passed from ApplicationHooks ---
            masterJson.put("executionTime", suiteDurationMillis); // the duration (ms), kept for the dashboard
            masterJson.put("runStartTime", Instant.now().minusMillis(suiteDurationMillis).toString()); // for history dates
            // --- END MODIFICATION ---
            masterJson.put("features", masterList);
            mapper.writeValue(new File(REPORT_DIR + "master.json"), masterJson);
            LogUtils.info("Master JSON generated:" + REPORT_DIR + "master.json" );

            // ===== 2. feature_<module>_<uuid>.json =====
            for (FeatureSummary f : featureMap.values()) {
                Map<String, Object> featureJson = new LinkedHashMap<>();
                featureJson.put("buildNumber", buildNumber);
                featureJson.put("featureUUID", f.getFeatureUUID());
                featureJson.put("featureName", f.getFeatureName());
                featureJson.put("moduleName", f.getModuleName());   // NEW
                featureJson.put("featureUri", f.getFeatureUri());
                featureJson.put("featureTags", f.getFeatureTags());
                Map<String, Object> summary = new LinkedHashMap<>();
                summary.put("totalScenarios", f.getTotalScenarios());
                summary.put("passedScenarios", f.getPassedScenarios());
                summary.put("failedScenarios", f.getFailedScenarios());
                summary.put("durationMillis", f.getDurationMillis());
                summary.put("totalSteps", f.getTotalSteps());
                summary.put("passedSteps", f.getPassedSteps());
                summary.put("failedSteps", f.getFailedSteps());
                summary.put("skippedSteps", f.getSkippedSteps());
                featureJson.put("summary", summary);

                List<Map<String, Object>> scenarioList = new ArrayList<>();
                for (ScenarioResultMinimal s : f.getScenarios()) {
                    Map<String, Object> sm = new LinkedHashMap<>();
                    sm.put("scenarioUUID", s.getScenarioUUID());
                    sm.put("scenarioId", s.getScenarioId());        // NEW
                    sm.put("scenarioName", s.getScenarioName());
                    sm.put("tags", s.getTags());
                    sm.put("durationMillis", s.getDurationMillis());
                    sm.put("totalSteps", s.getTotalSteps());
                    sm.put("passedSteps", s.getPassedSteps());
                    sm.put("failedSteps", s.getFailedSteps());
                    sm.put("skippedSteps", s.getSkippedSteps());

                    // NEW raw counters for step-detail UI
                    sm.put("undefinedSteps", s.getUndefinedSteps());
                    sm.put("pendingSteps", s.getPendingSteps());
                    sm.put("ambiguousSteps", s.getAmbiguousSteps());

                    // NEW: expose raw step-level status (preserve fidelity in detail view)
                    sm.put("rawStatus", s.getRawStatus());

                    sm.put("status", s.getStatus());
                    sm.put("history", s.getHistory());

                    // also propagate moduleName into per-scenario object for consumers
                    sm.put("moduleName", s.getModuleName());

                    scenarioList.add(sm);
                }
                featureJson.put("scenarios", scenarioList);

                // sanitize moduleName for filename (replace non-alphanum with _)
                String safeModule = (f.getModuleName() != null) ? f.getModuleName().replaceAll("[^A-Za-z0-9_-]", "_") : "module";
                String featureFileName = "feature_" + safeModule + "_" + (f.getFeatureUUID() != null ? f.getFeatureUUID() : UUID.randomUUID().toString()) + ".json";
                mapper.writeValue(new File(REPORT_DIR + featureFileName), featureJson);
            }

            // ===== 3. failures.json =====
            Map<String, Object> failuresJson = new LinkedHashMap<>();
            failuresJson.put("buildNumber", buildNumber);
            failuresJson.put("totalFailedScenarios", failedScenarios.size());
            failuresJson.put("failedScenarios", failedScenarios);
            mapper.writeValue(new File(REPORT_DIR + "failures.json"), failuresJson);

            // ===== 4. tags.json =====
            Map<String, Object> tagsJson = new LinkedHashMap<>();
            tagsJson.put("buildNumber", buildNumber);
            tagsJson.put("tags", tagMap.values());
            mapper.writeValue(new File(REPORT_DIR + "tags.json"), tagsJson);

            // ===== 5. featureHistories.js =====
            try {
                // Build nested structure: features -> scenarios -> history
                List<Map<String, Object>> featuresHistories = new ArrayList<>();

                for (FeatureSummary f : featureMap.values()) {
                    Map<String, Object> featureEntry = new LinkedHashMap<>();
                    featureEntry.put("featureUUID", f.getFeatureUUID());
                    featureEntry.put("moduleName", f.getModuleName()); // NEW

                    List<Map<String, Object>> scenarioEntries = new ArrayList<>();
                    if (f.getScenarios() != null) {
                        for (ScenarioResultMinimal s : f.getScenarios()) {
                            Map<String, Object> scenarioEntry = new LinkedHashMap<>();
                            scenarioEntry.put("scenarioUUID", s.getScenarioUUID());
                            scenarioEntry.put("scenarioId", s.getScenarioId()); // NEW
                            scenarioEntry.put("moduleName", s.getModuleName()); // NEW

                            // copy history (already ordered newest->oldest and capped at noOfHistoryBackups)
                            List<RunRecord> hist = s.getHistory() != null ? new ArrayList<>(s.getHistory()) : new ArrayList<>();
                            scenarioEntry.put("history", hist);

                            scenarioEntries.add(scenarioEntry);
                        }
                    }

                    featureEntry.put("scenarios", scenarioEntries);
                    featuresHistories.add(featureEntry);
                }

                Map<String, Object> root = new LinkedHashMap<>();
                root.put("features", featuresHistories);

                File jsFile = new File(REPORT_DIR + "featureHistories.js");
                String jsonString = mapper.writeValueAsString(root);
                String jsContent = "window.__allFeatureHistories = " + jsonString + ";";

                Files.writeString(jsFile.toPath(),
                        jsContent,
                        java.nio.charset.StandardCharsets.UTF_8,
                        java.nio.file.StandardOpenOption.CREATE,
                        java.nio.file.StandardOpenOption.TRUNCATE_EXISTING);

                LogUtils.info(">>> Generated featureHistories.js at " + jsFile.getPath());
            } catch (Exception e) {
                LogUtils.error("Could not write featureHistories.js", e);
            }

            LogUtils.info("All aggregated reports generated in " + REPORT_DIR);

        } catch (Exception e) {
            LogUtils.error("Could not generate the aggregated reports in " + REPORT_DIR, e);
        }
    }

    /**
     * Build a cache of scenario histories by reading older feature JSON files found under reports/history/<run>/
     * Each RunRecord will contain status, buildNumber and execution timestamp (if master.json has executionTime).
     *
     * History cache keys: prefer featureUUID::scenarioUUID (if both present).
     * Fallbacks: featureUUID::scenarioName (if scenarioUUID missing), scenarioName as last resort.
     */
    private static Map<String, List<RunRecord>> buildScenarioHistoryCache() {
        Map<String, List<RunRecord>> historyCache = new HashMap<>();
        File historyDir = new File(HISTORY_ROOT_DIR);
        if (!historyDir.exists() || !historyDir.isDirectory()) return historyCache;
        File[] runFolders = historyDir.listFiles(File::isDirectory);
        if (runFolders == null) return historyCache;
        Arrays.sort(runFolders, Comparator.comparingLong(ReportUtils::runTimeMillis).reversed()); // newest first, by run time

        // We treat noOfHistoryBackups as total entries to keep (including current).
        // So process up to (noOfHistoryBackups - 1) previous runs.
        int runsToProcess = Math.max(0, Math.min(runFolders.length, Math.max(0, noOfHistoryBackups - 1)));

        for (int i = 0; i < runsToProcess; i++) {
            File jsonDir = new File(runFolders[i], "custom-report/json/");
            if (!jsonDir.exists()) continue;

            MasterInfo mi = getMasterInfo(jsonDir);
            String buildNumber = mi.getBuildNumber();
            Long execMillis = mi.getExecutionMillis();

            File[] featureFiles = jsonDir.listFiles((d, name) -> name.startsWith("feature_") && name.endsWith(".json"));
            if (featureFiles == null) continue;

            ObjectMapper mapper = new ObjectMapper();
            for (File featureFile : featureFiles) {
                try {
                    JsonNode rootNode = mapper.readTree(featureFile);
                    String historicalFeatureUUID = rootNode.path("featureUUID").asText(null);
                    HistoricalFeatureFile featureData = mapper.treeToValue(rootNode, HistoricalFeatureFile.class);

                    if (featureData.getScenarios() != null) {
                        for (HistoricalScenario scenario : featureData.getScenarios()) {
                            String status = scenario.getStatus();
                            String runDate = execMillis != null ? Instant.ofEpochMilli(execMillis).toString() : buildNumber;
                            Long duration = scenario.getDurationMillis();

                            // Build canonical historical key for scenario (must match currentKey logic)
                            // Preference order:
                            // 1) moduleName::scenarioId
                            // 2) moduleName::scenarioName
                            // 3) scenarioName
                            String key;
                            String histModule = scenario.getModuleName();
                            String histScenarioId = scenario.getScenarioId();
                            String histScenarioName = scenario.getScenarioName();

                            if (histModule != null && !histModule.isEmpty() && histScenarioId != null && !histScenarioId.isEmpty()) {
                                key = histModule + "::" + histScenarioId;
                            } else if (histModule != null && !histModule.isEmpty() && histScenarioName != null && !histScenarioName.isEmpty()) {
                                key = histModule + "::" + histScenarioName;
                            } else if (histScenarioName != null && !histScenarioName.isEmpty()) {
                                key = histScenarioName;
                            } else {
                                key = UUID.randomUUID().toString();
                            }


                            RunRecord rr = new RunRecord(status, buildNumber, execMillis, runDate, duration);
                            historyCache.computeIfAbsent(key, k -> new ArrayList<>()).add(rr);
                        }
                    }
                } catch (IOException e) {
                    LogUtils.error("Could not read scenario history from: " + featureFile.getPath());
                }
            }
        }

        // sort each list newest -> oldest (by runDateMillis) and keep them in that order
        historyCache.values().forEach(list -> list.sort((a, b) -> {
            Long aa = a.getRunDateMillis(); Long bb = b.getRunDateMillis();
            if (aa == null && bb == null) return 0;
            if (aa == null) return 1;
            if (bb == null) return -1;
            return bb.compareTo(aa);
        }));

        return historyCache;
    }

    /**
     * Builds feature history cache keyed by featureUUID (fallback to featureName).
     * Each RunRecord for a feature has status and buildNumber (and runDateMillis when available).
     */
    private static Map<String, List<RunRecord>> buildFeatureHistoryCache() {
        Map<String, List<RunRecord>> historyCache = new HashMap<>();
        File historyDir = new File(HISTORY_ROOT_DIR);
        if (!historyDir.exists() || !historyDir.isDirectory()) return historyCache;
        File[] runFolders = historyDir.listFiles(File::isDirectory);
        if (runFolders == null) return historyCache;
        Arrays.sort(runFolders, Comparator.comparingLong(ReportUtils::runTimeMillis).reversed()); // newest first, by run time

        int runsToProcess = Math.max(0, Math.min(runFolders.length, Math.max(0, noOfHistoryBackups - 1)));
        ObjectMapper mapper = new ObjectMapper();

        for (int i = 0; i < runsToProcess; i++) {
            File jsonDir = new File(runFolders[i], "custom-report/json/");
            if (!jsonDir.exists()) continue;

            MasterInfo mi = getMasterInfo(jsonDir);
            String buildNumber = mi.getBuildNumber();
            Long execMillis = mi.getExecutionMillis();

            File masterFile = new File(jsonDir, "master.json");
            if (masterFile.exists()) {
                try {
                    HistoricalMasterFile mf = mapper.readValue(masterFile, HistoricalMasterFile.class);
                    if (mf.getFeatures() != null) {
                        for (HistoricalFeature feature : mf.getFeatures()) {
                            String status = feature.getStatus();
                            String runDate = execMillis != null ? Instant.ofEpochMilli(execMillis).toString() : buildNumber;
                            RunRecord rr = new RunRecord(status, buildNumber, execMillis, runDate, null);

                            // Stable feature key: prefer moduleName::featureName, fallback to featureUUID or featureName
                            String histModule = feature.getModuleName();
                            String histFeatureName = feature.getFeatureName();
                            String histFeatureUUID = feature.getFeatureUUID();
                            String key;

                            if (histModule != null && !histModule.isEmpty() && histFeatureName != null && !histFeatureName.isEmpty()) {
                                key = histModule + "::" + histFeatureName;
                            } else if (histFeatureUUID != null && !histFeatureUUID.isEmpty()) {
                                key = histFeatureUUID;
                            } else if (histFeatureName != null && !histFeatureName.isEmpty()) {
                                key = histFeatureName;
                            } else {
                                key = UUID.randomUUID().toString();
                            }

                            historyCache.computeIfAbsent(key, k -> new ArrayList<>()).add(rr);
                        }
                    }
                } catch (IOException e) {
                    LogUtils.error("Could not read feature history from: " + masterFile.getPath());
                }
            }
        }

        // sort each feature list newest -> oldest
        historyCache.values().forEach(list -> list.sort((a, b) -> {
            Long aa = a.getRunDateMillis(); Long bb = b.getRunDateMillis();
            if (aa == null && bb == null) return 0;
            if (aa == null) return 1;
            if (bb == null) return -1;
            return bb.compareTo(aa);
        }));

        return historyCache;
    }

    /**
     * Read master.json (if present) and return both buildNumber and executionTime as millis.
     */
    private static MasterInfo getMasterInfo(File jsonDir) {
        File masterFile = new File(jsonDir, "master.json");
        if (!masterFile.exists()) return new MasterInfo("N/A", null);
        try {
            ObjectMapper mapper = new ObjectMapper();
            HistoricalMasterFile mf = mapper.readValue(masterFile, HistoricalMasterFile.class);
            // runStartTime (since 2026-10-06); older master.json files have only executionTime, which is a duration,
            // so their run date comes from the history folder (name / last-modified time)
            Long execMillis = null;
            if (mf.getRunStartTime() != null) {
                try {
                    execMillis = Instant.parse(mf.getRunStartTime()).toEpochMilli();
                } catch (java.time.format.DateTimeParseException ex) {
                    execMillis = null;
                }
            }
            if (execMillis == null && jsonDir.getParentFile() != null && jsonDir.getParentFile().getParentFile() != null) {
                execMillis = ReportUtils.runTimeMillis(jsonDir.getParentFile().getParentFile());
            }
            return new MasterInfo(mf.getBuildNumber() != null ? mf.getBuildNumber() : "N/A", execMillis);
        } catch (IOException e) {
            return new MasterInfo("N/A", null);
        }
    }

    public static String getScenarioDir() {
        LogUtils.info("SCENARIO_DIR"+SCENARIO_DIR);
        return SCENARIO_DIR;
    }

    // ==================== Nested Classes ====================
    @Data
    public static class FeatureSummary {
        private String featureUUID, featureName, featureUri;
        private String moduleName;
        private List<String> featureTags;
        private int totalScenarios = 0, passedScenarios = 0, failedScenarios = 0;
        private long durationMillis = 0;
        private String status = "PASSED";
        private List<ScenarioResultMinimal> scenarios = new ArrayList<>();
        private int totalSteps = 0, passedSteps = 0, failedSteps = 0, skippedSteps = 0;
        private List<RunRecord> history = new ArrayList<>();

        // --- MODIFICATION: Add transient fields to calculate a feature's wall-clock time ---
        private transient Instant featureStartTime;
        private transient Instant featureEndTime;

        /**
         * Updates the feature's time boundaries based on a scenario's execution time.
         * This is called for every scenario within the feature.
         * @param start The start time of a scenario.
         * @param end The end time of a scenario.
         */
        public void addScenarioTime(Instant start, Instant end) {
            if (featureStartTime == null || start.isBefore(featureStartTime)) {
                featureStartTime = start;
            }
            if (featureEndTime == null || end.isAfter(featureEndTime)) {
                featureEndTime = end;
            }
        }

        /**
         * Calculates the final wall-clock duration after all scenarios for this feature have been processed.
         * This should be called once, after the main scenario processing loop is complete.
         */
        public void calculateWallClockDuration() {
            if (featureStartTime != null && featureEndTime != null) {
                this.durationMillis = Duration.between(featureStartTime, featureEndTime).toMillis();
            }
        }
        // --- END MODIFICATION ---

    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ScenarioResultMinimal {
        private String featureUUID, featureName, featureDescription, featureKeyword, featureUri;
        private List<String> featureTags;

        private String scenarioUUID, scenarioName, status;
        private String scenarioId;     //  (e.g. "SC_002_D1")
        private String moduleName;

        private List<String> tags;
        private String startTime; // ISO instant string from scenario JSON
        private String endTime; // ISO instant string from scenario JSON
        private long durationMillis;
        private int totalSteps, passedSteps, failedSteps, skippedSteps;

        // NEW raw counts to expose UNDEFINED/PENDING/AMBIGUOUS at scenario level
        private int undefinedSteps;
        private int pendingSteps;
        private int ambiguousSteps;

        // NEW: raw step-level status (preserve step fidelity)
        private String rawStatus;

        private List<RunRecord> history = new ArrayList<>();
    }

    @Data
    public static class TagSummary {
        private String tag;
        private int totalScenarios = 0, passedScenarios = 0, failedScenarios = 0;
        public TagSummary(String tag) { this.tag = tag; }
        public void incrementTotal() { totalScenarios++; }
        public void incrementPassed() { passedScenarios++; }
        public void incrementFailed() { failedScenarios++; }
    }

    @Data
    public static class MasterInfo {
        private String buildNumber;
        private Long executionMillis;
        public MasterInfo(String buildNumber, Long executionMillis) {
            this.buildNumber = buildNumber;
            this.executionMillis = executionMillis;
        }
    }

    @Data @NoArgsConstructor
    public static class RunRecord {
        private String status;
        private String buildNumber;

        // new fields for the UI & sorting
        private Long runDateMillis;    // epoch millis of the run (preferred for sorting)
        private String runDate;        // human-readable date string (ISO)
        private Long durationMillis;   // duration of the scenario/feature in ms (optional)

        // convenience constructor for older two-arg calls (if needed)
        public RunRecord(String status, String buildNumber) {
            this.status = status;
            this.buildNumber = buildNumber;
            this.runDateMillis = null;
            this.runDate = null;
            this.durationMillis = null;
        }

        // full constructor
        public RunRecord(String status, String buildNumber, Long runDateMillis, String runDate, Long durationMillis) {
            this.status = status;
            this.buildNumber = buildNumber;
            this.runDateMillis = runDateMillis;
            this.runDate = runDate;
            this.durationMillis = durationMillis;
        }
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HistoricalMasterFile {
        private String buildNumber;
        private String executionTime;         // the suite duration in ms (not a date)
        private String runStartTime;          // ISO instant of the run start (since 2026-10-06)
        private List<HistoricalFeature> features;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HistoricalFeature {
        private String featureUUID;
        private String featureName;
        private String status;
        private String moduleName;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HistoricalFeatureFile {
        private String featureUUID;
        private List<HistoricalScenario> scenarios;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HistoricalScenario {
        private String scenarioUUID;
        private String scenarioName;
        private String status;
        // New fields we now read from historical feature JSONs (if present)
        private Long durationMillis;
        private String startTime;
        private String scenarioId;
        private String moduleName;
    }
}
