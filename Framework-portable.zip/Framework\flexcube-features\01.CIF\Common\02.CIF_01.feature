@CIF @Regression @HK @UK
Feature: This feature is to test Customer Maintenance Functionality

  @SC_001 @Day1 @TestingWEBDEMO
  Scenario: CIF|SC_001|Verification of Corporate customer through front end based on Migrated data from T24, Validation of Migrated Director details and capturing KYC details, Linking KYC with CIF, dedupe and Authorization of CIF

#Maker - Validate migrated customer data and Linkage of CIF
    Given user navigates to the URL


#
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user retrieves the Branch date "BranchDate"
#    And user navigates to the "Customer Maintenance" screen using "STDCIF"
#    Then user verify "Customer Maintenance" is displayed successfully
#    When user retrieves the existing customer details "CustomerNumber"
#    Then user verify the following field details under "GeneralDetails" screen
#      | CustomerFullName  |
#      | CustomerShortName |
#      | CustomerCategory  |
#      | Name              |
#      | AddressLine       |
#      | AddressLine2      |
#      | AddressLine3      |
#      | Country           |
#      | AddressLine4      |
#      | AddressLine4      |
#      | TelephoneNo       |
#      | TelephoneISDCode  |
#      | MbNo              |
#      | MbISDCode         |
#      | EmailId           |
#      | Language          |
#    When user click "Additional" under "AdditionalDetails" screen
#    Then user verify the following field details under "AdditionalDetails" screen
#      | Location     |
#      | Media        |
#      | RMID         |
#      | RMName       |
#      | BusinessCode |
#      | PurposeCode  |
#    When user click "RelatedParties"
#    Then user verify the following field details under "RelatedPartiesDetails" screen
#      | CustomerName         |
#      | IdentificationType   |
#      | CountryOfIssue       |
#      | CountryRelatedPaties |
#      | Nationality          |
#      | Position             |
#      | IDNumber             |
#      | IDIssuePlace         |
#      | IDIssueDate          |
#      | IDExpiryDate         |
#      | Email                |
#    When user click "MIS" under "MIS" screen
#    Then user verify "MIS" is displayed successfully
#    And user verify the following field details under "MIS" screen
#      | CustomerMISCode |
#    When user click "CompositeTab" under "MIS" screen
#    Then user verify the following field details under "MIS" screen
#      | BUS_GRP   |
#      | CUST_SGMT |
#      | SRC_BRN   |
#      | GEOGRAPHY |
#    When user click "ExitCustomer" under "GeneralDetails" screen
#    And user click "UPArrow"
#    And user click "FATCA" under "FATCADetails" screen
#    Then user verify the following field details under "FATCADetails" screen
#      | Nationality          |
#      | CountryOfBirth       |
#      | ParentCoCountryIncor |
#    When user click "ExitFATCA" under "FATCADetails" screen
#    And user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
#
##Maker - Dedupe Check
#    Given user "Maker" is logged into "FCUBS" with appropriate privileges
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user retrieves the Branch date "BranchDate"
#    And user navigates to the "Customer Maintenance" screen using "STDCIF"
#    Then user verify "Customer Maintenance" is displayed successfully
#    When user retrieves the existing customer details "CustomerNumber"
#    And user click "Unlock"
#    Then user modifies the following field details under "GeneralDetails" screen
#      | CustomerFullName |
#      | AddressLine      |
#    When user click "Save"
#    And user click "RemarksOk"
#    Then user verify the pop up for "error" message "Duplicate customer exists"
#    When user click "Cancel"
#    Then user verify the pop up for confirmation message "Do you want to cancel the operation ?"
#    When user click "InfoOk"
#    And user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
#
##KYC CREATION
#    Given user "Maker" is logged into "FCUBS" with appropriate privileges
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user retrieves the Branch date "BranchDate"
#    And user navigates to the "KYC Maintenance" screen using "STDKYCMN"
#    Then user verify "KYC Maintenance" is displayed successfully
#    When user click "New"
#    And user retrieves the following field value under "KYCDetails" screen
#      | KYCRefNo       |
#    And user selectOption "KYCCustomerType" under "KYCDetails" screen
#    And user enters the following field details under "KYCDetails" screen
#      | RiskLevel           |
#      | KYCCustomerFullName |
#      | KYCCustomerNumber   |
#    And user click "AddRiskMatrixRow" under "KYCDetails" screen
#    And user enters the following field details under "KYCDetails" screen
#      | RiskMatrixSerialNo |
#      | RiskMatrixLow      |
#      | RiskMatrixMid      |
#      | RiskMatrixHigh     |
#    And user click "CorporateCustomerTab" under "KYCDetails" screen
#    And user enters the following field details under "KYCDetails" screen
#      | PurposeOfAccountOpening             |
#      | NatureOfBusiness                    |
#      | ProductTraded                       |
#      | MainSourceOfFunds                   |
#      | ParentCompanyCountryOfIncorporation |
#      | TypeOfCompany                       |
#      | KYCAmountsCurrency                  |
#      | DetailPurposeCommercial             |
#      | OwnershipDetails                    |
#      | NoOfPersonsEmployed                 |
#      | ModeForSalary                       |
#      | TradeLicenseNumber                  |
#      | TradeLicenseExpiryDate              |
#      | KYCComments                         |
#      | SalesAndServiceOfficers             |
#      | Approvers                           |
#    When user click "OkSaveCorporateProfile" under "KYCDetails" screen
#    And user click "Save" under "KYCDetails" screen
#    Then user verify the pop up for "success" message "Record Successfully Saved"
#    When user click "InfoOk"
#    Then user is able to validate authorization status as "Unauthorized"
#    When user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
#
## CHECKER AUTHORIZATION
#    Given user "Checker" is logged into "FCUBS" with appropriate privileges
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user navigates to the "KYC Maintenance" screen using "STDKYCMN"
#    Then user verify "KYC Maintenance" is displayed successfully
#    When user retrieves the existing KYC details "KYCRefNo"
#    And user click "Authorize"
#    And user click "AuthAccept"
#    Then user verify the pop up for "success" message "Record Successfully Authorized"
#    When user click "InfoOk"
#    Then user is able to validate authorization status as "Authorized"
#    When user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
#
## MAKER FINALIZE
#    Given user "Maker" is logged into "FCUBS" with appropriate privileges
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user retrieves the Branch date "BranchDate"
#    And user navigates to the "Customer Maintenance" screen using "STDCIF"
#    Then user verify "Customer Maintenance" is displayed successfully
#    When user retrieves the existing customer details "CustomerNumber"
#    And user click "Unlock"
#    And user selectOption "KYCStatus" under "KYCDetails" screen
#    And user enters the following field details under "KYCDetails" screen
#      | KYCReference |
#    When user click "Save"
#    And user Accepts the Override message
#    Then user verify the pop up for "success" message "Record Successfully Modified"
#    When user click "InfoOk"
#    Then user is able to validate authorization status as "Unauthorized"
#    And user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
#
## Checker- Authorize modified customer record
#    Given user "Checker" is logged into "FCUBS" with appropriate privileges
#    And user verify "Dashboard" is visible
#    When user switch to branch
#    And user navigates to the "Customer Maintenance" screen using "STDCIF"
#    Then user verify "Customer Maintenance" is displayed successfully
#    When user retrieves the existing customer details "CustomerNumber"
#    Then user verifies the modified field details under "KYCDetails" screen
#      | KYCReference |
#      | KYCStatus    |
#    When user click "Authorize"
#    And user click "AuthAccept"
#    Then user verify the pop up for "success" message "Record Successfully Authorized"
#    When user click "InfoOk"
#    Then user is able to validate authorization status as "Authorized"
#    When user click "Exit"
#    And user switch to "HomeBranch"
#    Then user logout of the FCUBS application
