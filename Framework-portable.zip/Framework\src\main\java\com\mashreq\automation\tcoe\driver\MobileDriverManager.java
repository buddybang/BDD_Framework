


package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.utils.LogUtils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.CommandPayload;
import org.openqa.selenium.remote.Response;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.http.ClientConfig;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MobileDriverManager
 *
 * Supports:
 *
 * LOCAL
 *   - Android
 *   - iOS
 *
 * BROWSERSTACK
 *   - Android
 *   - iOS
 *   - Corporate / Zscaler proxy
 *
 * Configuration is controlled through FrameworkConstants,
 * which reads values from config.properties and/or system properties.
 *
 * ThreadLocal is used so the driver and execution mode are safe
 * for parallel execution.
 *
 * NOTE:
 *   Video / screen recording has been completely removed.
 */
public final class MobileDriverManager {

    private static final ThreadLocal<AppiumDriver> DRIVER =
            new ThreadLocal<>();

    private static final ThreadLocal<String> EXECUTION_MODE =
            new ThreadLocal<>();

    /** Per thread: parallel scenarios run on different devices. */
    private static final ThreadLocal<String> DEVICE_DETAILS = new ThreadLocal<>();

    /**
     * Why the current session is no longer usable (a command lost the connection or the session is gone); null = usable.
     * Then no more screenshots and no BrowserStack status update are sent: they would only wait for the timeout again
     * and hide the first failure.
     */
    private static final ThreadLocal<String> SESSION_LOST_REASON = new ThreadLocal<>();

    /** What quitDriver did, so the hooks log the truth instead of always "closed successfully". */
    public enum QuitOutcome {
        /** There was no driver on this thread (e.g. the session was never created). */
        NO_DRIVER,
        /** The session was ended. */
        QUIT,
        /** Ending the session failed (local state was cleared anyway). */
        QUIT_FAILED
    }

    /** Marks the current session as unusable (see {@link #isSessionUsable()}); the first reason is kept. */
    public static void markSessionUnusable(String reason) {
        if (DRIVER.get() != null && SESSION_LOST_REASON.get() == null) {
            SESSION_LOST_REASON.set(reason);
            LogUtils.warn("-----> Mobile session marked unusable: " + reason);
        }
    }

    /** True when a driver exists and no command has lost the connection / session. */
    public static boolean isSessionUsable() {
        return DRIVER.get() != null && SESSION_LOST_REASON.get() == null;
    }

    /** The current thread's device, e.g. "ANDROID [BROWSERSTACK] - RZGL412B8DJ"; null before a driver is started. */
    public static String getDeviceDetails() {
        return DEVICE_DETAILS.get();
    }

    private MobileDriverManager() {
        // Utility class
    }

    // ================================================================
    // INIT DRIVER
    // ================================================================

    /**
     * Initializes the Appium driver for the current thread.
     */
    public static void initDriver() {

        if (DRIVER.get() != null) {
            // a session left over from an earlier scenario on this thread: reusing it would carry its app state over
            throw new IllegalStateException(
                    "A mobile session already exists on this thread (session " + DRIVER.get().getSessionId()
                            + "); the previous scenario was not torn down.");
        }

        String executionMode =
                getExecutionMode();

        String platform =
                getPlatform();

        EXECUTION_MODE.set(
                executionMode
        );

        LogUtils.info("");
        LogUtils.info(
                "=================================================="
        );
        LogUtils.info(
                "Mobile Execution Mode : " + executionMode
        );
        LogUtils.info(
                "Mobile Platform       : " + platform
        );
        LogUtils.info(
                "=================================================="
        );

        long creationStarted = System.nanoTime();

        try {

            AppiumDriver appiumDriver;

            if ("browserstack".equals(executionMode)) {

                LogUtils.info(
                        "-----> Starting BrowserStack App Automate session"
                );

                FrameworkConstants.validateBrowserStackConfig();

                appiumDriver =
                        createBrowserStackDriver(
                                platform
                        );

            } else if ("local".equals(executionMode)) {

                LogUtils.info(
                        "-----> Starting local Appium session"
                );

                appiumDriver =
                        createLocalDriver(
                                platform
                        );

            } else {

                throw new IllegalArgumentException(
                        "Unsupported MOBILE_EXECUTION_MODE: "
                                + executionMode
                                + ". Supported values: local, browserstack"
                );
            }

            DRIVER.set(
                    appiumDriver
            );

            LogUtils.info(
                    "-----> Mobile session created in " + elapsedMs(creationStarted) + " ms"
            );

            updateDeviceDetails(
                    appiumDriver,
                    platform
            );

            LogUtils.info(
                    "-----> Mobile Driver started successfully"
            );

            LogUtils.info(
                    "-----> Device Details: "
                            + DEVICE_DETAILS.get()
            );

            if ("browserstack".equals(executionMode)) {
                logBrowserStackSessionUrl(appiumDriver);
            }

            LogUtils.info(
                    "-----> Session ID: "
                            + appiumDriver.getSessionId()
            );

        } catch (Exception e) {

            // when the client gave up (timeout), whether BrowserStack still allocated a device is unknown
            LogUtils.warn(
                    "-----> Mobile session creation failed after " + elapsedMs(creationStarted) + " ms: "
                            + e.getClass().getSimpleName()
            );

            try {

                AppiumDriver currentDriver =
                        DRIVER.get();

                if (currentDriver != null) {
                    currentDriver.quit();
                }

            } catch (Exception ignored) {
                // Ignore cleanup failure
            } finally {

                DRIVER.remove();
                EXECUTION_MODE.remove();
                DEVICE_DETAILS.remove();
            }

            throw new RuntimeException(
                    "Failed to initialize Mobile Driver "
                            + "[mode=" + executionMode
                            + ", platform=" + platform + "]",
                    e
            );
        }
    }

    // ================================================================
    // GET DRIVER
    // ================================================================

    /**
     * Returns the Appium driver associated with the current thread.
     */
    public static AppiumDriver getDriver() {
        return DRIVER.get();
    }

    /**
     * Returns true if a driver exists for the current thread.
     */
    public static boolean isDriverAvailable() {
        return DRIVER.get() != null;
    }

    // ================================================================
    // EXECUTION MODE / PLATFORM
    // ================================================================

    private static String getExecutionMode() {

        String value =
                System.getProperty(
                        "MOBILE_EXECUTION_MODE",
                        FrameworkConstants.MOBILE_EXECUTION_MODE
                );

        if (value == null || value.isBlank()) {
            return "local";
        }

        return value.trim().toLowerCase();
    }

    private static String getPlatform() {

        String value =
                System.getProperty(
                        "MOBILE_PLATFORM",
                        FrameworkConstants.MOBILE_PLATFORM
                );

        if (value == null || value.isBlank()) {
            return "android";
        }

        return value.trim().toLowerCase();
    }

    // ================================================================
    // LOCAL DRIVER
    // ================================================================

    private static AppiumDriver createLocalDriver(
            String platform
    ) throws Exception {

        String serverUrl =
                FrameworkConstants.APPIUM_SERVER_URL;

        if (serverUrl == null || serverUrl.isBlank()) {

            throw new IllegalStateException(
                    "APPIUM_SERVER_URL is not configured."
            );
        }

        URL appiumUrl =
                new URL(serverUrl);

        ClientConfig clientConfig =
                ClientConfig.defaultConfig()
                        .baseUrl(appiumUrl);

        if ("android".equals(platform)) {

            LogUtils.info(
                    "-----> Local Android Appium URL: "
                            + serverUrl
            );

            return loggedAndroidDriver(
                    clientConfig,
                    getLocalAndroidOptions()
            );

        } else if ("ios".equals(platform)) {

            LogUtils.info(
                    "-----> Local iOS Appium URL: "
                            + serverUrl
            );

            return loggedIosDriver(
                    clientConfig,
                    getLocalIosOptions()
            );

        } else {

            throw new IllegalArgumentException(
                    "Unsupported MOBILE_PLATFORM: "
                            + platform
            );
        }
    }

    // ================================================================
    // BROWSERSTACK DRIVER
    // ================================================================

    /**
     * Creates BrowserStack App Automate driver.
     *
     * BrowserStack credentials are embedded in the endpoint URL
     * because this matches the standalone BrowserStack implementation
     * used in the corporate proxy environment.
     *
     * Credentials are never printed.
     */
    private static AppiumDriver createBrowserStackDriver(
            String platform
    ) throws Exception {

        validateBrowserStackConfiguration();
        refuseBrowserStackSdkAgent();

        ClientConfig clientConfig =
                createBrowserStackClientConfig();

        if ("android".equals(platform)) {

            UiAutomator2Options options =
                    getBrowserStackAndroidOptions();

            return loggedAndroidDriver(
                    clientConfig,
                    options
            );

        } else if ("ios".equals(platform)) {

            XCUITestOptions options =
                    getBrowserStackIosOptions();

            return loggedIosDriver(
                    clientConfig,
                    options
            );

        } else {

            throw new IllegalArgumentException(
                    "Unsupported MOBILE_PLATFORM: "
                            + platform
                            + ". Supported values: android, ios"
            );
        }
    }

    // ================================================================
    // BROWSERSTACK CLIENT CONFIG
    // ================================================================

    /**
     * Creates the Selenium HTTP client configuration used by Appium.
     *
     * Corporate / Zscaler proxy is applied here.
     */
    static ClientConfig createBrowserStackClientConfig()
            throws Exception {

        // credentials go in an Authorization header (withCredentials), never in the URL or the capabilities:
        // the URL appears in exception messages and logs
        URL browserStackUrl =
                new URL("https://hub-cloud.browserstack.com/wd/hub");

        /*
         * Read timeout above the length of a test (default 180 s): with 90 s, every session that was busy 90 s after it was created
         * lost its connection ("connection closed locally" from the HTTP client's own response timer, while the request
         * that failed had just started) - NeoCorp runs of 2026-10-02, two sessions at the same second.
         * Override with -DBS_READ_TIMEOUT_SECONDS=... or BS_READ_TIMEOUT_SECONDS in config.properties.
         */
        long readTimeoutSeconds =
                secondsSetting("BS_READ_TIMEOUT_SECONDS", 180);

        // time to open the TCP connection (proxy / BrowserStack hub); -DBS_CONNECT_TIMEOUT_SECONDS=... or config.properties
        long connectTimeoutSeconds =
                secondsSetting("BS_CONNECT_TIMEOUT_SECONDS", 30);

        ClientConfig clientConfig =
                withCredentials(
                        ClientConfig.defaultConfig()
                                .baseUrl(browserStackUrl)
                                .connectionTimeout(
                                        Duration.ofSeconds(connectTimeoutSeconds)
                                )
                                .readTimeout(
                                        Duration.ofSeconds(readTimeoutSeconds)
                                ),
                        FrameworkConstants.BROWSERSTACK_USERNAME,
                        FrameworkConstants.BROWSERSTACK_ACCESS_KEY);

        LogUtils.info(
                "-----> BrowserStack timeouts: connect " + connectTimeoutSeconds + " s, read " + readTimeoutSeconds + " s"
        );

        Proxy proxy =
                getBrowserStackProxy();

        if (proxy != null) {

            clientConfig =
                    clientConfig.proxy(proxy);

            LogUtils.info(
                    "-----> BrowserStack proxy enabled"
            );

        } else {

            LogUtils.info(
                    "-----> BrowserStack proxy disabled"
            );
        }

        return clientConfig;
    }

    // ================================================================
    // BROWSERSTACK PROXY
    // ================================================================

    /**
     * Returns the corporate/Zscaler HTTP proxy.
     */
    static Proxy getBrowserStackProxy() {

        // -DBS_USE_PROXY=false skips the corporate proxy (e.g. when working outside the client network).
        // The JDK then falls back to the OS proxy settings if -Djava.net.useSystemProxies=true is also passed.
        if ("false".equalsIgnoreCase(getProperty("BS_USE_PROXY", "true"))) {
            return null;
        }

        String proxyHost =
                getProperty(
                        "BS_PROXY_HOST",
                        FrameworkConstants.BS_PROXY_HOST
                );

        String proxyPortValue =
                getProperty(
                        "BS_PROXY_PORT",
                        FrameworkConstants.BS_PROXY_PORT
                );

        if (proxyHost == null
                || proxyHost.isBlank()
                || proxyPortValue == null
                || proxyPortValue.isBlank()) {

            return null;
        }

        try {

            int proxyPort =
                    Integer.parseInt(
                            proxyPortValue.trim()
                    );

            InetSocketAddress address =
                    new InetSocketAddress(
                            proxyHost.trim(),
                            proxyPort
                    );

            if (address.isUnresolved()) {
                // the corporate proxy's name is not known on this network (another office, home, a build agent):
                // go direct / through the OS proxy instead of failing every session (same as -Poffsite)
                LogUtils.warn(
                        "-----> BrowserStack proxy " + proxyHost.trim() + " is not known on this network; connecting without it."
                                + " (Inside the client network check BS_PROXY_HOST; outside it use -Poffsite to hide this message.)"
                );
                return null;
            }

            return new Proxy(
                    Proxy.Type.HTTP,
                    address
            );

        } catch (NumberFormatException e) {

            throw new IllegalStateException(
                    "Invalid BS_PROXY_PORT: "
                            + proxyPortValue,
                    e
            );
        }
    }

    // ================================================================
    // BROWSERSTACK ANDROID OPTIONS
    // ================================================================

    static UiAutomator2Options
    getBrowserStackAndroidOptions() {

        UiAutomator2Options options =
                new UiAutomator2Options();

        options.setPlatformName(
                "Android"
        );

        options.setAutomationName(
                "UiAutomator2"
        );

        options.setDeviceName(
                FrameworkConstants.BS_DEVICE_NAME
        );

        options.setPlatformVersion(
                FrameworkConstants.BS_OS_VERSION
        );

        options.setApp(
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        /*
         * No userName / accessKey capabilities: authentication is in the hub URL
         * (createBrowserStackClientConfig). Capabilities are printed in plain text by
         * SessionNotCreatedException, so the key must never be one of them.
         *
         * BrowserStack metadata.
         */
        options.setCapability(
                "bstack:options",
                getBrowserStackOptions()
        );

        options.setCapability(
                "autoGrantPermissions",
                true
        );

        options.setCapability(
                "noReset",
                false
        );

        return options;
    }

    // ================================================================
    // BROWSERSTACK SESSION OPTIONS (bstack:options)
    // ================================================================

    /**
     * Metadata for every BrowserStack session, plus the debugging switches
     * when BS_INTERACTIVE_DEBUGGING=true:
     *   interactiveDebugging - tap / type on the device from the session page while the test runs
     *   debug                - visual logs (a screenshot for every command)
     *   idleTimeout 300      - BrowserStack maximum, so an IDE breakpoint does not end the session (default 90 s)
     */
    private static Map<String, Object> getBrowserStackOptions() {

        Map<String, Object> bstackOptions = new HashMap<>();
        bstackOptions.put("projectName", FrameworkConstants.BS_PROJECT);
        bstackOptions.put("buildName", FrameworkConstants.BS_BUILD_NAME);
        // one name per scenario ("Module | SC_id"), so the sessions of a build can be told apart
        com.mashreq.automation.tcoe.context.ScenarioContext ctx = com.mashreq.automation.tcoe.context.ScenarioContext.get();
        bstackOptions.put("sessionName", ctx == null || ctx.getScenarioId() == null
                ? FrameworkConstants.BS_TEST_NAME
                : ctx.getCurrentModule() + " | " + ctx.getScenarioId());

        // how long BrowserStack keeps a session without commands (1-300 s, BrowserStack's default 90)
        long idleTimeout = secondsSetting("BS_IDLE_TIMEOUT_SECONDS", 90);
        if (idleTimeout > 300) {
            throw new IllegalStateException("BS_IDLE_TIMEOUT_SECONDS must be between 1 and 300, but is " + idleTimeout);
        }
        bstackOptions.put("idleTimeout", idleTimeout);

        if (FrameworkConstants.BS_INTERACTIVE_DEBUGGING) {
            bstackOptions.put("interactiveDebugging", true);
            bstackOptions.put("debug", true);
            bstackOptions.put("idleTimeout", 300);
            LogUtils.info(
                    "-----> BrowserStack interactive debugging ON (visual logs, idle timeout 300 s)"
            );
        }

        return bstackOptions;
    }

    /**
     * Logs the BrowserStack session page, where the device can be watched
     * and (with interactive debugging) used. Never fails the test.
     */
    private static void logBrowserStackSessionUrl(AppiumDriver appiumDriver) {

        try {
            Object details = appiumDriver.executeScript(
                    "browserstack_executor: {\"action\": \"getSessionDetails\"}"
            );
            Matcher matcher = Pattern
                    .compile("\"browser_url\"\\s*:\\s*\"([^\"]+)\"")
                    .matcher(String.valueOf(details));
            LogUtils.info(
                    "-----> BrowserStack session: "
                            + (matcher.find()
                            ? matcher.group(1)
                            : "https://app-automate.browserstack.com/dashboard/v2 (session " + appiumDriver.getSessionId() + ")")
            );
        } catch (Exception e) {
            LogUtils.info(
                    "-----> WARN: Could not read the BrowserStack session link: "
                            + e.getMessage()
            );
        }
    }

    // ================================================================
    // BROWSERSTACK IOS OPTIONS
    // ================================================================

    private static XCUITestOptions
    getBrowserStackIosOptions() {

        XCUITestOptions options =
                new XCUITestOptions();

        options.setPlatformName(
                "iOS"
        );

        options.setAutomationName(
                "XCUITest"
        );

        options.setDeviceName(
                FrameworkConstants.BS_DEVICE_NAME
        );

        options.setPlatformVersion(
                FrameworkConstants.BS_OS_VERSION
        );

        options.setApp(
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        // Authentication is in the hub URL only (see getBrowserStackAndroidOptions).
        options.setCapability(
                "bstack:options",
                getBrowserStackOptions()
        );

        applyIosAlertHandling(options);

        options.setCapability(
                "noReset",
                false
        );

        return options;
    }

    // ================================================================
    // LOCAL ANDROID OPTIONS
    // ================================================================

    private static UiAutomator2Options
    getLocalAndroidOptions() {

        UiAutomator2Options options =
                new UiAutomator2Options();

        options.setPlatformName(
                "Android"
        );

        options.setDeviceName(
                FrameworkConstants.DEVICE_NAME
        );

        if (FrameworkConstants.DEVICE_UDID != null
                && !FrameworkConstants.DEVICE_UDID.isBlank()) {

            options.setUdid(
                    FrameworkConstants.DEVICE_UDID
            );
        }

        options.setAutomationName(
                "UiAutomator2"
        );

        if (!FrameworkConstants.ANDROID_APP_PATH.isEmpty()) {
            options.setApp(
                    existingAppFile("ANDROID_APP_PATH", FrameworkConstants.ANDROID_APP_PATH)
            );
        }

        if (FrameworkConstants.APP_PACKAGE.isEmpty() && FrameworkConstants.ANDROID_APP_PATH.isEmpty()) {
            throw new IllegalStateException("Local Android run: set APP_PACKAGE and APP_ACTIVITY (the installed app) "
                    + "or ANDROID_APP_PATH (an .apk to install) in config.properties or with -D.");
        }

        if (!FrameworkConstants.APP_PACKAGE.isEmpty()) {
            options.setAppPackage(
                    FrameworkConstants.APP_PACKAGE
            );
        }

        if (!FrameworkConstants.APP_ACTIVITY.isEmpty()) {
            options.setAppActivity(
                    FrameworkConstants.APP_ACTIVITY
            );
        }

        options.setNoReset(
                false
        );

        // how long Appium keeps an idle local session (e.g. at an IDE breakpoint); -DLOCAL_NEW_COMMAND_TIMEOUT_SECONDS=...
        options.setNewCommandTimeout(
                Duration.ofSeconds(secondsSetting("LOCAL_NEW_COMMAND_TIMEOUT_SECONDS", 60))
        );

        if (FrameworkConstants.PLATFORM_VERSION != null
                && !FrameworkConstants.PLATFORM_VERSION.isBlank()) {

            options.setPlatformVersion(
                    FrameworkConstants.PLATFORM_VERSION
            );
        }

        return options;
    }

    // ================================================================
    // LOCAL IOS OPTIONS
    // ================================================================

    private static XCUITestOptions
    getLocalIosOptions() {

        XCUITestOptions options =
                new XCUITestOptions();

        options.setPlatformName(
                "iOS"
        );

        options.setDeviceName(
                FrameworkConstants.DEVICE_NAME
        );

        if (!FrameworkConstants.IOS_APP_PATH.isEmpty()) {
            options.setApp(
                    existingAppFile("IOS_APP_PATH", FrameworkConstants.IOS_APP_PATH)
            );
        }

        if (FrameworkConstants.DEVICE_UDID != null
                && !FrameworkConstants.DEVICE_UDID.isBlank()) {

            options.setUdid(
                    FrameworkConstants.DEVICE_UDID
            );
        }

        options.setAutomationName(
                "XCUITest"
        );

        options.setNoReset(
                false
        );

        // how long Appium keeps an idle local session (e.g. at an IDE breakpoint); -DLOCAL_NEW_COMMAND_TIMEOUT_SECONDS=...
        options.setNewCommandTimeout(
                Duration.ofSeconds(secondsSetting("LOCAL_NEW_COMMAND_TIMEOUT_SECONDS", 60))
        );

        if (FrameworkConstants.PLATFORM_VERSION != null
                && !FrameworkConstants.PLATFORM_VERSION.isBlank()) {

            options.setPlatformVersion(
                    FrameworkConstants.PLATFORM_VERSION
            );
        }

        applyIosAlertHandling(options);

        return options;
    }

    /**
     * iOS has no autoGrantPermissions (Android grants app permissions automatically). IOS_ALERTS=accept / dismiss makes
     * XCUITest accept / dismiss every system alert (permission pop-ups too); empty (default) = alerts are left to the test.
     * Accepting every alert can hide an alert a test should check, so it is off unless asked for.
     */
    private static void applyIosAlertHandling(XCUITestOptions options) {
        String mode = FrameworkConstants.optionalSetting("IOS_ALERTS").toLowerCase(java.util.Locale.ROOT);
        if ("accept".equals(mode)) {
            options.setAutoAcceptAlerts(true);
        } else if ("dismiss".equals(mode)) {
            options.setAutoDismissAlerts(true);
        } else if (!mode.isEmpty()) {
            throw new IllegalStateException("IOS_ALERTS must be accept, dismiss or empty, but is '" + mode + "'");
        }
    }

    /** The app file for a local session; a clear error when it does not exist (instead of Appium's own). */
    private static String existingAppFile(String key, String path) {
        if (!new java.io.File(path).exists()) {
            throw new IllegalStateException(key + " points to a file that does not exist: " + path);
        }
        return path;
    }

    // ================================================================
    // QUIT DRIVER
    // ================================================================

    /**
     * Quits the Appium driver associated with the current thread.
     *
     * No screen recording or video processing is performed.
     */
    public static QuitOutcome quitDriver() {
        return quitDriver(null, null);
    }

    /**
     * Marks the BrowserStack session as passed/failed (so it does not show
     * as "Unmarked"), then quits the driver.
     *
     * @param passed null to skip marking
     * @param reason short reason shown on the BrowserStack session
     */
    public static QuitOutcome quitDriver(Boolean passed, String reason) {
        return quitDriver(passed, reason, null);
    }

    /**
     * Marks the BrowserStack session, then quits it once. While the session is usable the status goes through the session
     * (browserstack_executor); when it is not, or that fails, through BrowserStack's REST API, which does not need the
     * session's connection. The result is also written to target/browserstack-status/<session>.json ("confirmed": false
     * when neither worked; scripts/Sync-BrowserStackResults.ps1 sends those again). Reporting never prevents the quit.
     *
     * @param restConfig REST client to use (tests); null = api-cloud.browserstack.com with the configured proxy
     */
    static QuitOutcome quitDriver(Boolean passed, String reason, ClientConfig restConfig) {

        AppiumDriver currentDriver =
                DRIVER.get();

        if (currentDriver == null) {

            LogUtils.info(
                    "-----> No mobile driver on this thread: nothing to quit"
            );

            cleanupThreadLocal();

            return QuitOutcome.NO_DRIVER;
        }

        try {
            if (passed != null && "browserstack".equals(EXECUTION_MODE.get())) {
                reportBrowserStackStatus(currentDriver, passed, reason, restConfig);
            }
        } catch (RuntimeException e) {
            LogUtils.warn("-----> BrowserStack status could not be reported: " + e.getMessage());
        } finally {
            long quitStarted = System.nanoTime();
            try {

                currentDriver.quit();

                LogUtils.info(
                        "-----> Mobile Appium driver quit successfully (" + elapsedMs(quitStarted) + " ms)"
                );

                return QuitOutcome.QUIT;

            } catch (Exception e) {

                LogUtils.warn(
                        "-----> Mobile driver quit failed after " + elapsedMs(quitStarted)
                                + " ms (local state cleared anyway): " + e.getMessage()
                );

                return QuitOutcome.QUIT_FAILED;

            } finally {

                cleanupThreadLocal();
            }
        }
    }

    private static void reportBrowserStackStatus(AppiumDriver driver, boolean passed, String reason,
                                                 ClientConfig restConfig) {
        String status = passed ? "passed" : "failed";
        String safeReason = LogUtils.mask(reason == null ? "" : reason.replaceAll("[\\r\\n]+", " "));
        if (safeReason.length() > 250) {
            safeReason = safeReason.substring(0, 250);
        }
        String session = driver.getSessionId() == null ? null : driver.getSessionId().toString();
        boolean confirmed = false;
        String channel = "pending";

        if (SESSION_LOST_REASON.get() == null) {
            long started = System.nanoTime();
            try {
                String payload = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(Map.of(
                        "action", "setSessionStatus",
                        "arguments", Map.of("status", status, "reason", safeReason)));
                driver.executeScript("browserstack_executor: " + payload);
                confirmed = true;
                channel = "session";
                LogUtils.info("-----> BrowserStack session marked " + status + " (" + elapsedMs(started) + " ms)");
            } catch (Exception e) {
                LogUtils.warn("-----> Marking the session through Appium failed after " + elapsedMs(started)
                        + " ms; trying the REST API: " + e.getMessage());
            }
        } else {
            LogUtils.info("-----> Session unusable (" + SESSION_LOST_REASON.get() + "): status sent through the REST API");
        }

        if (!confirmed && session != null) {
            try {
                BrowserStackRestStatus.update(restConfig != null ? restConfig : BrowserStackRestStatus.config(),
                        session, passed, safeReason);
                confirmed = true;
                channel = "rest-api";
                LogUtils.info("-----> BrowserStack session marked " + status + " through the REST API");
            } catch (Exception e) {
                LogUtils.warn("-----> BrowserStack status NOT confirmed (sent later by scripts/Sync-BrowserStackResults.ps1): "
                        + e.getMessage());
            }
        }

        if (session != null) {
            try {
                BrowserStackRestStatus.record(session, passed, safeReason, confirmed, channel);
            } catch (Exception e) {
                LogUtils.warn("-----> Could not write the BrowserStack status record: " + e.getMessage());
            }
        }
    }

    // ================================================================
    // DEVICE DETAILS
    // ================================================================

    private static void updateDeviceDetails(
            AppiumDriver appiumDriver,
            String platform
    ) {

        try {

            Object deviceNameCapability =
                    appiumDriver
                            .getCapabilities()
                            .getCapability(
                                    "deviceName"
                            );

            String deviceName;

            if (deviceNameCapability != null) {

                deviceName =
                        deviceNameCapability.toString();

            } else if (
                    "browserstack".equals(
                            EXECUTION_MODE.get()
                    )
            ) {

                deviceName =
                        FrameworkConstants.BS_DEVICE_NAME;

            } else {

                deviceName =
                        FrameworkConstants.DEVICE_NAME;
            }

            DEVICE_DETAILS.set(
                    platform.toUpperCase()
                            + " ["
                            + EXECUTION_MODE
                            .get()
                            .toUpperCase()
                            + "] - "
                            + deviceName);

        } catch (Exception e) {

            DEVICE_DETAILS.set(
                    platform.toUpperCase()
                            + " ["
                            + (
                            EXECUTION_MODE.get() == null
                                    ? "UNKNOWN"
                                    : EXECUTION_MODE
                                    .get()
                                    .toUpperCase()
                    )
                            + "]");
        }
    }

    // ================================================================
    // CONFIGURATION VALIDATION
    // ================================================================

    private static void validateBrowserStackConfiguration() {

        validateRequired(
                "BROWSERSTACK_USERNAME",
                FrameworkConstants.BROWSERSTACK_USERNAME
        );

        validateRequired(
                "BROWSERSTACK_ACCESS_KEY",
                FrameworkConstants.BROWSERSTACK_ACCESS_KEY
        );

        validateRequired(
                "BROWSERSTACK_APP_URL",
                FrameworkConstants.BROWSERSTACK_APP_URL
        );

        validateRequired(
                "BS_DEVICE_NAME",
                FrameworkConstants.BS_DEVICE_NAME
        );

        validateRequired(
                "BS_OS_VERSION",
                FrameworkConstants.BS_OS_VERSION
        );
    }

    private static void validateRequired(
            String propertyName,
            String value
    ) {

        if (value == null
                || value.isBlank()) {

            throw new IllegalStateException(
                    propertyName
                            + " is not configured."
            );
        }
    }

    // ================================================================
    // SYSTEM PROPERTY OVERRIDE
    // ================================================================

    private static String getProperty(
            String propertyName,
            String defaultValue
    ) {

        String systemValue =
                System.getProperty(
                        propertyName
                );

        if (systemValue != null
                && !systemValue.isBlank()) {

            return systemValue.trim();
        }

        return defaultValue;
    }

    // ================================================================
    // THREADLOCAL CLEANUP
    // ================================================================

    private static void cleanupThreadLocal() {

        DRIVER.remove();

        EXECUTION_MODE.remove();

        DEVICE_DETAILS.remove();

        SESSION_LOST_REASON.remove();
    }

    // ================================================================
    // SETTINGS / GUARDS
    // ================================================================

    /**
     * Adds a preemptive "Authorization: Basic ..." header to every request (BrowserStack does not send a challenge first).
     * Keeps the credentials out of the URL, which Selenium prints in exception messages.
     */
    static ClientConfig withCredentials(ClientConfig config, String username, String accessKey) {
        String authorization = "Basic " + java.util.Base64.getEncoder().encodeToString(
                (username + ":" + accessKey).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return config.withFilter(next -> request -> {
            request.setHeader("Authorization", authorization);
            return next.execute(request);
        });
    }

    private static long elapsedMs(long startedNanos) {
        return (System.nanoTime() - startedNanos) / 1_000_000;
    }

    /** Why the session is unusable, or null. */
    public static String sessionLostReason() {
        return SESSION_LOST_REASON.get();
    }

    /** A whole number of seconds from -D / config.properties, or the default; a clear error for anything else. */
    private static long secondsSetting(String key, long defaultSeconds) {
        String value = getProperty(key, FrameworkConstants.optionalSetting(key));
        if (value == null || value.isBlank()) {
            return defaultSeconds;
        }
        try {
            long seconds = Long.parseLong(value.trim());
            if (seconds <= 0) {
                throw new NumberFormatException("not positive");
            }
            return seconds;
        } catch (NumberFormatException e) {
            throw new IllegalStateException(key + " must be a whole number of seconds above 0, but is '" + value + "'", e);
        }
    }

    /**
     * The framework talks to BrowserStack directly through Appium. The BrowserStack Java SDK agent (-javaagent:...browserstack-java-sdk...)
     * rewrites the capabilities of that session and was found to break it (2026-10-04: legacy capabilities rejected by Selenium);
     * stop with a clear message instead of a confusing session error.
     */
    private static void refuseBrowserStackSdkAgent() {
        for (String arg : java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            String lower = arg.toLowerCase(java.util.Locale.ROOT);
            if (lower.startsWith("-javaagent") && lower.contains("browserstack")) {
                throw new IllegalStateException(
                        "The BrowserStack Java SDK agent is on the JVM command line (" + arg + "). This framework creates "
                                + "BrowserStack sessions itself through Appium; remove the -javaagent (pom.xml surefire argLine "
                                + "or the IDE run configuration) and run again.");
            }
        }
    }

    // ================================================================
    // COMMAND LOG
    // ================================================================

    /**
     * Drivers that log every Appium command: name, session, thread, duration and outcome, never the parameters (typed
     * text, PINs). Logged on the test's own thread (in the scenario's log file). A command that loses the connection or
     * the session marks the session unusable; a failed screenshot does not (it is only a diagnostic).
     */
    static AndroidDriver loggedAndroidDriver(ClientConfig config, Capabilities capabilities) {
        return new AndroidDriver(config, capabilities) {
            @Override
            protected Response execute(CommandPayload payload) {
                return logCommand(payload.getName(), getSessionId(), () -> super.execute(payload));
            }
        };
    }

    static IOSDriver loggedIosDriver(ClientConfig config, Capabilities capabilities) {
        return new IOSDriver(config, capabilities) {
            @Override
            protected Response execute(CommandPayload payload) {
                return logCommand(payload.getName(), getSessionId(), () -> super.execute(payload));
            }
        };
    }

    private static Response logCommand(String command, SessionId session,
                                       java.util.function.Supplier<Response> call) {
        long start = System.nanoTime();
        String sessionText = session == null ? "-" : session.toString();
        try {
            Response response = call.get();
            LogUtils.info(String.format("Appium %-26s | session %s | thread %s | %5d ms | OK",
                    command, sessionText, Thread.currentThread().getName(), (System.nanoTime() - start) / 1_000_000));
            return response;
        } catch (RuntimeException e) {
            long ms = (System.nanoTime() - start) / 1_000_000;
            com.mashreq.automation.tcoe.utils.FailureKind kind = com.mashreq.automation.tcoe.utils.FailureKind.of(e);
            String firstLine = String.valueOf(e.getMessage()).split("\\R", 2)[0];
            String line = String.format("Appium %-26s | session %s | thread %s | %5d ms | %s %s: %s",
                    command, sessionText, Thread.currentThread().getName(), ms, kind, e.getClass().getSimpleName(), firstLine);
            if (kind == com.mashreq.automation.tcoe.utils.FailureKind.LOCATOR) {
                LogUtils.info(line); // element not (yet) there: normal while a wait polls
            } else {
                LogUtils.warn(line);
            }
            if (kind.sessionLikelyLost() && !"screenshot".equalsIgnoreCase(command)) {
                markSessionUnusable(command + " failed after " + ms + " ms (" + kind + "): " + e.getClass().getSimpleName());
            }
            throw e;
        }
    }
}
