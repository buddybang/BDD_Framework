# TCoE Automation Framework — working context

Repo: Azure DevOps `MashreqCorpTech/TCOE/_git/Native_Mobile_Apps` (local clone at this folder). Maven, Java 17, groupId `com.mashreq.automation`, artifact `TCoE`.

## Branch layout (important)
- `master` holds the framework source (merged PR 110504 "IFT-Changes to Master"); this working copy commits on `master`.
- Real framework code lives on branch `payment_tracker` (latest, local), `origin/OAT` ("Framework code" commit) and `origin/IFT` (only in the pack file).
- `git` is not on PATH on this machine. To inspect other branches without git, loose objects were extracted with Python (scratchpad `extract.py`); `IFT` is packed and not extracted.
- `.git/config` contains a plaintext Azure DevOps bearer token in `http.extraHeader`. Never print or copy it; rotate it.

## What the framework is
Keyword-driven BDD framework: Cucumber 7 + TestNG + PicoContainer, with
- Web UI via Playwright Java (Flexcube/OBDX/OBPM/OBTF/OBTFPM style banking UIs)
- Mobile via Appium (Android/iOS, local or BrowserStack App Automate)
- API via Playwright APIRequest (RestAssured version is commented out)
- Custom reporting: Cucumber JSON -> FreeMarker dashboard + per-feature HTML, plus Allure, Extent, cucumber-reporting.

## Layout (branch payment_tracker)
- `flexcube-features/` Gherkin (01.CIF, API, Mobile)
- `src/main/.../keywords` WebUI, MobileUI (action libs); `pages/` page objects; `driver/` DriverManager (ThreadLocal Playwright), MobileDriverManager
- `constants/` generated locator-key constants (CIF, COMMON, MOBILE, TERM...), `Script/LocatorConstantGenerator.java` + `utils/ORGenerator` generate them from `objectrepo/*.json`
- `utils/DataHandler` test data JSON by module/scenarioId; `testdata/` (+ `excel_files/`); `users/` maker/checker pool (BlockingQueue)
- `src/test/.../hooks/ApplicationHooks` (Before/After/AfterStep/AfterAll), `stepdefinitions/`, `runners/` (TestRunner, RerunTestRunner, MainRunner), `listeners/`, `utils/FeatureAggregator` + `FeatureStepCollector` (history/master.json for dashboard)
- Config: `src/main/resources/config/config.properties` + `urls-<ENV>.properties`; `-DENV -DREGION -Dparallel -Dthreads -Dcucumber.tags` overrides
- Run: `mvn test` (suite `src/test/resources/suites/testng.xml`, needs aspectj javaagent); failed scenarios -> `target/rerun.txt`

## Known issues (updated 2026-10-06 - see CHANGELOG-FIXES.md #1-82 and Fixes.xlsx, both sheets, for per-item status)
Fixed: hard-coded runner tag, static ScenarioContext.page and other static per-run state, commented-out code (API layer deleted),
fixed sleeps (remaining Thread.sleep are poll intervals), swallowed exceptions in framework code, duplicate / unused pom
dependencies, BrowserStack key moved to git-ignored `src/main/resources/config/secrets.local.properties`.
2026-10-06: all 19 Fixes.xlsx mobile items and the 50-item audit (#50-73): hook failures no longer shown as PASSED,
runtime test data goes to git-ignored `testdata/.runtime/` (recorded files stay untouched), keys masked in logs/reports,
mobile failures carry a [KIND] prefix and their cause, Appium commands logged per scenario.
Still open: user passwords in testdata/Users/*.json, git token in .git/config and the BrowserStack key (rotate both),
APP_PACKAGE is a demo app, UAT HK/UK URLs are placeholders, nothing verified on a real device / Flexcube since 2026-10-06.
`..\Framework_Fixed` = another engineer's copy (old base + mobile hardening); synced INTO this folder 2026-10-06 (#74-82),
never written to. Offline mobile tests: `mvn test -Pmobile-regression` (fake Appium server, no device).
Rule: when asked "any pending issues?", audit the code file by file; never answer from this list or the changelog.
Rule: never hand-edit Lior-recorded features / test data; fix Lior or the framework.

## Journeys (2026-10-08)
One business case over web and mobile (maker on the app, checkers on the web, maker again) = several single-platform scenarios in
`flexcube-features/Journey/<Name>Journey.feature` (`@Journey @Journey_<Name>`, `@JourneyPart_<n>`), made by Lior's "Journey..." window.
`utils/Journey`: parts run in order, a part is SKIPPED when the one before it did not pass, `${journey:Name}` hands values (reference
numbers) to later parts in test data and locators. Run `mvn test -Pjourney -Dcucumber.tags="@Journey_<Name>"`; -Pweb / -Pmobile leave
journeys out. Details: CHANGELOG-FIXES.md #83-#87.

## Portability (2026-10-08)
Runs from any folder / machine: settings are -D or environment overrides, Edge/Chrome fall back to each other and Playwright's Chromium,
no screen = headless, no Playwright browser download for Edge/Chrome, unknown client proxy = direct, test data names any case, UTF-8 JVMs.
Proven in a copy under a path with spaces (CHANGELOG-FIXES #88-#92). Needs JDK 17+ and Maven 3.9+ (no wrapper yet).

## Web / mobile separation (2026-10-02)
`Platform` (WEB/MOBILE/API) comes from scenario tags and is stored in `ScenarioContext`; `DataHandler` reads only
`objectrepo/Web` or `objectrepo/Mobile` for that platform. Run with `-Pweb` / `-Pmobile`. `@WIP` scenarios are excluded.
Lior (the recorder in ..\Web_Element\element-extractor) writes into the same layout and adds `stepdefinitions/Web/LiorWebSteps.java`
(+ `Mobile/LiorMobileSteps.java` when needed) and `url.<REGION>.<APP>` lines in `urls-<ENV>.properties`. Details: CHANGELOG-FIXES.md #14-20.
`git` IS on PATH now (C:\Program Files\Git). The working tree has many uncommitted changes on `master`; nothing was committed.
