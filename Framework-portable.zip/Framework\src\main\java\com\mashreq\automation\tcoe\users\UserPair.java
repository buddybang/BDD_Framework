package com.mashreq.automation.tcoe.users;

import lombok.Data;

@Data
public class UserPair {
    private String pairId;
    private User maker;
    private User checker;
    //Changes to handle OBPM login - 19Nov
    private User maker1;
    private User checker1;
    private User checkerOBAPY;
    private User makerOBPAY;
    private User usobtfpmMaker;
    private User usobtfpmChecker;
    private User usobtfmaker;
    private User usobtfChecker;
    private User ukobtfpmMaker;
    private User ukobtfpmChecker;
    private User ukobtfmaker;
    private User ukobtfChecker;

    public String getPairId() {
        return pairId;
    }

    public void setPairId(String pairId) {
        this.pairId = pairId;
    }

    public User getMaker() {
        return maker;
    }

    public void setMaker(User maker) {
        this.maker = maker;
    }

    public User getChecker() {
        return checker;
    }

    public void setChecker(User checker) {
        this.checker = checker;
    }

    public User getMaker1() {
        return maker1;
    }

    public void setMaker1(User maker1) {
        this.maker1 = maker1;
    }

    public User getChecker1() {
        return checker1;
    }

    public void setChecker1(User checker1) {
        this.checker1 = checker1;
    }

    public User checkerOBAPY() {
        return checkerOBAPY;
    }

    public User makerOBPAY() {
        return makerOBPAY;

    }

    public User usobtfpmMaker() {
        return  usobtfpmMaker;

    }

    public User usobtfpmChecker() {
        return  usobtfpmChecker;
    }

    public User usobtfmaker() {
        return usobtfmaker;
    }

    public User usobtfChecker() {
        return usobtfChecker;
    }

    public User ukobtfpmMaker() {
        return ukobtfpmMaker;
    }

    public User ukobtfpmChecker() {
        return ukobtfpmChecker;
    }

    public User ukobtfmaker() {
        return ukobtfmaker;
                
    }

    public User ukobtfChecker() {
        return ukobtfChecker;
    }
}