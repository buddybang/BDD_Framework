#Feature: API User Validation

#  Scenario: Verify user details from ReqRes API
#    Given the user sets the base API headers
#    When the user sends a GET request to "https://reqres.in/api/users/2"
#    Then the API status code should be 200
#    And the JSON response at "data.first_name" should be "Janet"

Feature: User Management API Validation

  @API
  Scenario: Verify full lifecycle of User API
    # POST
    Given the User API is initialized
    When I send a POST request to "/api/users" with name "John" and job "Leader"
    Then the response status code should be 201
    And the response field "$.data.name" should be "John"

    # GET
    When I send a GET request to "/api/users/2"
    Then the response status code should be 200
    And the response field "$.data.id" should be "2"

    # PUT
    When I send a PUT request to "/api/users/2" with name "John" and job "Manager"
    Then the response status code should be 200
    And the response field "$.job" should be "Manager"

    # DELETE
    When I send a DELETE request to "/api/users/2"
    Then the response status code should be 204