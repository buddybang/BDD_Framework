@CIF @Regression @HK @UK
Feature: This feature is to test Customer Maintenance Functionality

   @SC_001 @Day0
  Scenario: CIF|PREREQCIF_CIF01_SC_001|Customer creation for CIF
     # Maker Customer Creation
    Given user "Maker" is logged into "FCUBS" with appropriate privileges
    Then user verify "Dashboard" is visible
    When user switch to branch
    And user retrieves the Branch date "BranchDate"
    When user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user click "New"
    And user click "BranchOk"
    Then user verify "Transaction Branch Code" is displayed successfully
    When user click "CustomerType"
    And user enters the following field details under "GeneralDetails" screen
      | CustomerCategory |
    When user click "PopulateCustomerNo"
    And user retrieve the Customer number "CustomerNumber"
    When user enters the following field details under "GeneralDetails" screen
      | CustomerFullName  |
      | CustomerShortName |
      | CustomerCategory  |
      | Name              |
      | AddressLine       |
      | AddressLine2      |
      | AddressLine3      |
      | Country           |
      | AddressLine4      |
      | Language          |
    And user click "Additional" under "AdditionalDetails" screen
    When user enters the following field details under "AdditionalDetails" screen
      | Location     |
      | Media        |
      | RMID         |
      | RMName       |
      | BusinessCode |
      | PurposeCode  |
    And user click "Auxiliary"
    When user select the following field details under "AuxiliaryDetails" screen
      | CRSCustomerType |
    And user click "RelatedParties"
    When user click "AddIconRelatedParties"
    And user enters the following field details under "RelatedPartiesDetails" screen
      | CustomerName         |
      | IdentificationType   |
      | CountryOfIssue       |
      | CountryRelatedPaties |
      | Nationality          |
      | Position             |
      | IDNumber             |
      | IDIssuePlace         |
      | IDIssueDate          |
      | IDExpiryDate         |
      | Email                |
    When user click "MIS"
    Then user verify "MIS" is displayed successfully
    When user enters the following field details under "MIS" screen
      | CustomerMISCode |
    And user click "CompositeTab" under "MIS" screen
    When user enters the following field details under "MIS" screen
      | BUS_GRP   |
      | CUST_SGMT |
      | SRC_BRN   |
      | GEOGRAPHY |
    And user click "CustomerOK"
    When user click "UPArrow"
    And user click "FATCA" under "FATCADetails" screen
    When user enters the following field details under "FATCADetails" screen
      | Nationality          |
      | CountryOfBirth       |
      | ParentCoCountryIncor |
    And user click "ActiveOrPassiveNFFE" under "FATCADetails" screen
    When user click "AccountClassification" under "FATCADetails" screen
    And user click "FATCAOK" under "FATCADetails" screen
    When user click "Save"
    Then user verify "Remarks" is displayed successfully
    When user Accepts the Override message
    Then user verify the pop up for "success" message "Record Successfully Saved"
    When user click "InfoOk"
    Then user is able to validate authorization status as "Unauthorized"
    When user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application

  # Checker- Authorize modified customer record
    Given user "Checker" is logged into "FCUBS" with appropriate privileges
    Then user verify "Dashboard" is visible
    When user switch to branch
    And user retrieves the Branch date "BranchDate"
    When user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user retrieves the existing customer details "CustomerNumber"
    And user click "Authorize"
    When user click "AuthAccept"
    And user click "AcceptAndOverride"
    Then user verify the pop up for "success" message "Record Successfully Authorized"
    When user click "InfoOk"
    Then user is able to validate authorization status as "Authorized"
    When user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application
