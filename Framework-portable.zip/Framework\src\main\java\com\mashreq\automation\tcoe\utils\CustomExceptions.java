package com.mashreq.automation.tcoe.utils;

/**
 * A collection of custom unchecked exceptions used throughout the framework.
 * <p>
 * These exceptions extend {@link RuntimeException}, allowing for more specific and meaningful
 * error handling within the framework's execution flow without requiring explicit catch blocks.
 */
@SuppressWarnings("serial")
public class CustomExceptions {

    /**
     * Thrown to indicate a serious error in the test framework, which should
     * typically halt execution immediately.
     */
    public static class FrameworkException extends RuntimeException {

        /**
         * Constructs a new {@code FrameworkException} with the specified detail message.
         *
         * @param message the detail message
         */
        public FrameworkException(String message) {
            super(message);
        }

        /**
         * Constructs a new {@code FrameworkException} with the specified detail message and cause.
         *
         * @param message the detail message
         * @param cause   the cause of the exception
         */
        public FrameworkException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Thrown when a required key (e.g., from a properties file, map, or config) cannot be found.
     */
    public static class KeyNotFoundException extends RuntimeException {

        /**
         * Constructs a new {@code KeyNotFoundException} with the specified detail message.
         *
         * @param message the detail message
         */
        public KeyNotFoundException(String message) {
            super(message);
        }
    }
}
