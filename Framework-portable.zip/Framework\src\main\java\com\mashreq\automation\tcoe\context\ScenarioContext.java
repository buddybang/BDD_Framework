package com.mashreq.automation.tcoe.context;

import com.mashreq.automation.tcoe.users.UserPair;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Page;
import io.appium.java_client.AppiumDriver;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Per-scenario context (PicoContainer injects a fresh instance for each scenario).
 * Holds the Playwright Page, scenario metadata, and any ad-hoc scenario data.
 */
public class ScenarioContext {

    // ---- Playwright ----
    // Instance field (was static): each scenario gets its own ScenarioContext, so each thread keeps its own page.
    @Getter @Setter private Page page;

    // ---- Scenario metadata ----
    @Getter @Setter private String testCaseId;
    @Getter @Setter private String scenarioId;
    @Getter @Setter private String currentModule;
    @Getter @Setter private String currentScreen;
    @Getter @Setter private Instant scenarioStartTime;
    @Getter @Setter private UserPair userPair;
    @Getter @Setter private AppiumDriver mobileDriver;
    /** WEB / MOBILE / API, set from the scenario's tags before anything else runs; decides the object repository folder. */
    @Getter @Setter private Platform platform;

    // ---- Failure diagnostics (one failure screenshot per scenario) ----
    /** A failure screenshot was already taken (by a keyword or the @After hook): do not take another one. */
    @Getter @Setter private boolean failureScreenshotTaken;
    /** A screenshot request failed: no more screenshots in this scenario (each one could wait for the full timeout). */
    @Getter @Setter private boolean screenshotsSuppressed;

    // ---- API ----
    @Getter @Setter private APIResponse apiResponse;
    @Getter @Setter private String authToken;

    // ---- Arbitrary per-scenario data ----
    private final Map<String, Object> scenarioData = new HashMap<>();

    public void setScenarioData(String key, Object value) { scenarioData.put(key, value); }
    public Object getScenarioData(String key) { return scenarioData.get(key); }

    private static final ThreadLocal<ScenarioContext> CURRENT = new ThreadLocal<>();

    public static void  set(ScenarioContext ctx) {CURRENT.set(ctx);}
    public static ScenarioContext get(){ return CURRENT.get();}
    public static void  clear() { CURRENT.remove();}

    private static final ThreadLocal<String> PENDING_CASE_ID = new ThreadLocal<>();

    public static void setPendingCaseId(String testcaseId) {
        PENDING_CASE_ID.set(testcaseId);
    }

    public static String consumePendingCaseId() {
        String id = PENDING_CASE_ID.get();
        PENDING_CASE_ID.remove();
        return id;
    }
}
