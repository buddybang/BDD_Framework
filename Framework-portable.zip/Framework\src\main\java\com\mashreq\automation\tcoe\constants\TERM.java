package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_Term.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class TERM {

    private TERM() {}

    // ===== Loginflow =====
    public static final String LOGINFLOW_PAGE1TITLE = "TERM/Loginflow/Page1title";
    public static final String LOGINFLOW_PAGE1SUBTITLE = "TERM/Loginflow/Page1subtitle";
    public static final String LOGINFLOW_PAGE2TITLE = "TERM/Loginflow/Page2title";
    public static final String LOGINFLOW_PAGE2SUBTITLE = "TERM/Loginflow/Page2subtitle";
    public static final String LOGINFLOW_PAGE3TITLE = "TERM/Loginflow/Page3title";
    public static final String LOGINFLOW_PAGE3SUBTITLE = "TERM/Loginflow/Page3subtitle";
    public static final String LOGINFLOW_PAGE4TITLE = "TERM/Loginflow/Page4title";
    public static final String LOGINFLOW_PAGE4SUBTITLE = "TERM/Loginflow/Page4subtitle";
    public static final String LOGINFLOW_USERID = "TERM/Loginflow/Userid";
    public static final String LOGINFLOW_LOGINWITHPASSWORD = "TERM/Loginflow/Loginwithpassword";
    public static final String LOGINFLOW_LOGIN = "TERM/Loginflow/Login";
    public static final String LOGINFLOW_PASSWORD = "TERM/Loginflow/Password";
    public static final String LOGINFLOW_FORWARDARROW = "TERM/Loginflow/ForwardArrow";
    public static final String LOGINFLOW_LOGIN1 = "TERM/Loginflow/Login1";
    public static final String LOGINFLOW_LOGINPIN = "TERM/Loginflow/Loginpin";
    public static final String LOGINFLOW_SETUPYOURLOGINPIN = "TERM/Loginflow/Setupyourloginpin";
    public static final String LOGINFLOW_CONFIRMLOGINPIN = "TERM/Loginflow/Confirmloginpin";
    public static final String LOGINFLOW_CONTINUE = "TERM/Loginflow/Continue";
    public static final String LOGINFLOW_PINCONTINUE = "TERM/Loginflow/PINContinue";
    public static final String LOGINFLOW_BIOMETRICSLATER = "TERM/Loginflow/Biometricslater";
    public static final String LOGINFLOW_LOGIN2 = "TERM/Loginflow/Login2";
    public static final String LOGINFLOW_LOGINWITHPIN = "TERM/Loginflow/LoginwithPIN";
    public static final String LOGINFLOW_ENTERSIXDIGITPIN = "TERM/Loginflow/EntersixdigitPIN";
    public static final String LOGINFLOW_TERMSANDCONDITION = "TERM/Loginflow/Termsandcondition";
    public static final String LOGINFLOW_AGREEANDCONTINUE = "TERM/Loginflow/Agreeandcontinue";
    public static final String LOGINFLOW_BACK = "TERM/Loginflow/Back";
    public static final String LOGINFLOW_BACKARROW = "TERM/Loginflow/Backarrow";
    public static final String LOGINFLOW_HELP = "TERM/Loginflow/Help";
    public static final String LOGINFLOW_LANGUAGE = "TERM/Loginflow/Language";
    public static final String LOGINFLOW_NEWCORPTEXT = "TERM/Loginflow/Newcorptext";
    public static final String LOGINFLOW_SIGINTEXT = "TERM/Loginflow/sigintext";
    public static final String LOGINFLOW_HELPICON = "TERM/Loginflow/Helpicon";
    public static final String LOGINFLOW_HELPYOU = "TERM/Loginflow/Helpyou";
    public static final String LOGINFLOW_PHONE = "TERM/Loginflow/Phone";
    public static final String LOGINFLOW_EMAIL = "TERM/Loginflow/Email";
    public static final String LOGINFLOW_ASKEDQUESTIONS = "TERM/Loginflow/Askedquestions";
    public static final String LOGINFLOW_ARROW = "TERM/Loginflow/Arrow";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS1 = "TERM/Loginflow/Frequentlyaskedquestions1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE1 = "TERM/Loginflow/Frequentlyaskedquestionssubtitle1";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS2 = "TERM/Loginflow/Frequentlyaskedquestions2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONSSUBTITLE2 = "TERM/Loginflow/Frequentlyaskedquestionssubtitle2";
    public static final String LOGINFLOW_FREQUENTLYASKEDQUESTIONS3 = "TERM/Loginflow/Frequentlyaskedquestions3";
    public static final String LOGINFLOW_VIEWALLFAQS = "TERM/Loginflow/ViewallFAQs";
    public static final String LOGINFLOW_ERRORMESSAGE = "TERM/Loginflow/Errormessage";

    // ===== DepositHomepage =====
    public static final String DEPOSITHOMEPAGE_DEPOSITS = "TERM/DepositHomepage/Deposits";
    public static final String DEPOSITHOMEPAGE_TERMWAKALADEPOSITS = "TERM/DepositHomepage/TermWakalaDeposits";
    public static final String DEPOSITHOMEPAGE_AEDWIDGET = "TERM/DepositHomepage/AEDWidget";
    public static final String DEPOSITHOMEPAGE_DEPOSITSUMMARYHEADER = "TERM/DepositHomepage/DepositSummaryHeader";
    public static final String DEPOSITHOMEPAGE_AEDWIDGETACCOUNT = "TERM/DepositHomepage/AEDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITCAROUSEL = "TERM/DepositHomepage/DepositCarousel";
    public static final String DEPOSITHOMEPAGE_CURRENCY = "TERM/DepositHomepage/Currency";
    public static final String DEPOSITHOMEPAGE_DEPOSITWIDGETCARD = "TERM/DepositHomepage/DepositWidgetCard";
    public static final String DEPOSITHOMEPAGE_SEARCH = "TERM/DepositHomepage/Search";
    public static final String DEPOSITHOMEPAGE_USDWIDGETACCOUNT = "TERM/DepositHomepage/USDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_USDCURRENCY = "TERM/DepositHomepage/USDCurrency";
    public static final String DEPOSITHOMEPAGE_BHDWIDGETACCOUNT = "TERM/DepositHomepage/BHDWidgetAccount";
    public static final String DEPOSITHOMEPAGE_SEARCHFIELD = "TERM/DepositHomepage/SearchField";
    public static final String DEPOSITHOMEPAGE_ACCOUNTCARD = "TERM/DepositHomepage/AccountCard";
    public static final String DEPOSITHOMEPAGE_SEARCHTEXT = "TERM/DepositHomepage/SearchText";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTSTYPE = "TERM/DepositHomepage/ConventionalAccountsType";
    public static final String DEPOSITHOMEPAGE_SEARCHICON = "TERM/DepositHomepage/SearchIcon";
    public static final String DEPOSITHOMEPAGE_MATCHINGDEPOSITCARD = "TERM/DepositHomepage/MatchingDepositCard";
    public static final String DEPOSITHOMEPAGE_CURRENCYSEARCH = "TERM/DepositHomepage/CurrencySearch";
    public static final String DEPOSITHOMEPAGE_NOTERMWAKALADEPOSITSAVAILABLE = "TERM/DepositHomepage/NoTermWakalaDepositsAvailable";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY = "TERM/DepositHomepage/AEDCurrency";
    public static final String DEPOSITHOMEPAGE_CLOSECURRENCYPANEL = "TERM/DepositHomepage/CloseCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_SEARCHMATURITYDATE = "TERM/DepositHomepage/SearchMaturityDate";
    public static final String DEPOSITHOMEPAGE_SEARCHSTATUS = "TERM/DepositHomepage/SearchStatus";
    public static final String DEPOSITHOMEPAGE_SEARCHDATE = "TERM/DepositHomepage/SearchDate";
    public static final String DEPOSITHOMEPAGE_SEARCHACCOUNTNUMBER = "TERM/DepositHomepage/SearchAccountNumber";
    public static final String DEPOSITHOMEPAGE_DEPOSITTYPE = "TERM/DepositHomepage/DepositType";
    public static final String DEPOSITHOMEPAGE_AEDDEPOSITCARD = "TERM/DepositHomepage/AEDDepositCard";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALACCOUNTTYPE = "TERM/DepositHomepage/ConventionalAccountType";
    public static final String DEPOSITHOMEPAGE_AEDVERIFY = "TERM/DepositHomepage/AEDVerify";
    public static final String DEPOSITHOMEPAGE_SUMMARYLIST = "TERM/DepositHomepage/SummaryList";
    public static final String DEPOSITHOMEPAGE_USDACCOUNT = "TERM/DepositHomepage/USDAccount";
    public static final String DEPOSITHOMEPAGE_DEPOSITSTITLE = "TERM/DepositHomepage/DepositsTitle";
    public static final String DEPOSITHOMEPAGE_SELECTEDCURRENCY = "TERM/DepositHomepage/SelectedCurrency";
    public static final String DEPOSITHOMEPAGE_ACTIVEACCOUNTCOUNT = "TERM/DepositHomepage/ActiveAccountCount";
    public static final String DEPOSITHOMEPAGE_TOTALAVAILABLEBALANCE = "TERM/DepositHomepage/TotalAvailableBalance";
    public static final String DEPOSITHOMEPAGE_CURRENCYDROPDOWN = "TERM/DepositHomepage/CurrencyDropdown";
    public static final String DEPOSITHOMEPAGE_CURRENCYBOTTOMSHEET = "TERM/DepositHomepage/CurrencyBottomSheet";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCY1 = "TERM/DepositHomepage/AEDCurrency1";
    public static final String DEPOSITHOMEPAGE_SELECTCURRENCYPANEL = "TERM/DepositHomepage/SelectCurrencyPanel";
    public static final String DEPOSITHOMEPAGE_AEDCURRENCYOPTION = "TERM/DepositHomepage/AEDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_BHDCURRENCYOPTION = "TERM/DepositHomepage/BHDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDCURRENCYOPTION = "TERM/DepositHomepage/USDCurrencyOption";
    public static final String DEPOSITHOMEPAGE_USDBALANCE = "TERM/DepositHomepage/USDBalance";
    public static final String DEPOSITHOMEPAGE_USDDEPOSITCARD = "TERM/DepositHomepage/USDDepositCard";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTCOUNT = "TERM/DepositHomepage/USDAccountCount";
    public static final String DEPOSITHOMEPAGE_SEARCHBAR = "TERM/DepositHomepage/SearchBar";
    public static final String DEPOSITHOMEPAGE_MATURITYYEAR = "TERM/DepositHomepage/MaturityYear";
    public static final String DEPOSITHOMEPAGE_DEPOSITBALANCE = "TERM/DepositHomepage/DepositBalance";
    public static final String DEPOSITHOMEPAGE_BALANCE = "TERM/DepositHomepage/Balance";
    public static final String DEPOSITHOMEPAGE_CONVENTIONALTYPE = "TERM/DepositHomepage/ConventionalType";
    public static final String DEPOSITHOMEPAGE_PARTIALSEARCHTEXT = "TERM/DepositHomepage/PartialSearchText";
    public static final String DEPOSITHOMEPAGE_INVALIDSEARCHTEXT = "TERM/DepositHomepage/InvalidSearchText";
    public static final String DEPOSITHOMEPAGE_SEARCHPARTIALTEXT = "TERM/DepositHomepage/SearchPartialText";
    public static final String DEPOSITHOMEPAGE_PARTIALTEXT = "TERM/DepositHomepage/PartialText";
    public static final String DEPOSITHOMEPAGE_NODEPOSITFOUNDMESSAGE = "TERM/DepositHomepage/NoDepositFoundMessage";
    public static final String DEPOSITHOMEPAGE_NORECORDSFOUND = "TERM/DepositHomepage/NoRecordsFound";
    public static final String DEPOSITHOMEPAGE_USDACCOUNTSEARCHTEXT = "TERM/DepositHomepage/USDAccountSearchText";

    // ===== DepositFilter =====
    public static final String DEPOSITFILTER_FILTERICON = "TERM/DepositFilter/FilterIcon";
    public static final String DEPOSITFILTER_FILTER = "TERM/DepositFilter/Filter";
    public static final String DEPOSITFILTER_FILTERSHEADER = "TERM/DepositFilter/FiltersHeader";
    public static final String DEPOSITFILTER_ACCOUNTTYPE = "TERM/DepositFilter/AccountType";
    public static final String DEPOSITFILTER_PARTYSECTIONTYPE = "TERM/DepositFilter/PartySectionType";
    public static final String DEPOSITFILTER_ACCOUNTTYPESECTION = "TERM/DepositFilter/AccountTypeSection";
    public static final String DEPOSITFILTER_PARTYSECTION = "TERM/DepositFilter/PartySection";
    public static final String DEPOSITFILTER_APPLYBUTTON = "TERM/DepositFilter/ApplyButton";
    public static final String DEPOSITFILTER_APPLY = "TERM/DepositFilter/Apply";
    public static final String DEPOSITFILTER_APPLYBUTTONS = "TERM/DepositFilter/ApplyButtons";
    public static final String DEPOSITFILTER_ISLAMIC = "TERM/DepositFilter/Islamic";
    public static final String DEPOSITFILTER_CONVENTIONAL = "TERM/DepositFilter/Conventional";
    public static final String DEPOSITFILTER_PARTYALL = "TERM/DepositFilter/PartyAll";
    public static final String DEPOSITFILTER_ISLAMICVERIFY = "TERM/DepositFilter/Islamicverify";
    public static final String DEPOSITFILTER_PARTYHEADER = "TERM/DepositFilter/PartyHeader";
    public static final String DEPOSITFILTER_PARTYID = "TERM/DepositFilter/PartyId";
    public static final String DEPOSITFILTER_PARTYIDISLAMIC = "TERM/DepositFilter/PartyIdIslamic";
    public static final String DEPOSITFILTER_ACCOUNTALL = "TERM/DepositFilter/AccountAll";
    public static final String DEPOSITFILTER_ACCOUNTTYPEALL = "TERM/DepositFilter/AccountTypeAll";
    public static final String DEPOSITFILTER_PARTYID1 = "TERM/DepositFilter/PartyId1";
    public static final String DEPOSITFILTER_NORECORD = "TERM/DepositFilter/NoRecord";
    public static final String DEPOSITFILTER_PARTYALLS = "TERM/DepositFilter/PartyAlls";

    // ===== AccountDetails =====
    public static final String ACCOUNTDETAILS_CUSTOMERID = "TERM/AccountDetails/CustomerID";
    public static final String ACCOUNTDETAILS_ACCOUNTCARD = "TERM/AccountDetails/AccountCard";
    public static final String ACCOUNTDETAILS_CUSTOMERNAME = "TERM/AccountDetails/CustomerName";
    public static final String ACCOUNTDETAILS_ACCOUNTNAME = "TERM/AccountDetails/AccountName";
    public static final String ACCOUNTDETAILS_ACCOUNTBRANCH = "TERM/AccountDetails/AccountBranch";

    // ===== TermWakalaDepositDetails =====
    public static final String TERMWAKALADEPOSITDETAILS_TENURE = "TERM/TermWakalaDepositDetails/Tenure";
    public static final String TERMWAKALADEPOSITDETAILS_VALUEDATE = "TERM/TermWakalaDepositDetails/ValueDate";
    public static final String TERMWAKALADEPOSITDETAILS_DEPOSITCERTIFICATENUMBER = "TERM/TermWakalaDepositDetails/DepositCertificateNumber";

    // ===== MaturityDetails =====
    public static final String MATURITYDETAILS_MATURITYDATE = "TERM/MaturityDetails/MaturityDate";
    public static final String MATURITYDETAILS_MATURITYINSTRUCTION = "TERM/MaturityDetails/MaturityInstruction";

}
