package com.mashreq.automation.tcoe.context;

public class ScreenshotContextHolder {
    private static final ThreadLocal<String> plannedScreenshotName = new ThreadLocal<>();
    private static final ThreadLocal<String> lastScreenshotPath = new ThreadLocal<>();
    private static final ThreadLocal<Integer> stepNo = new ThreadLocal<>();
    private static final ThreadLocal<Integer> actionNo = new ThreadLocal<>();
    private static final ThreadLocal<String> fieldName = new ThreadLocal<>();

    public static void planScreenshot(int step, int action) {
        stepNo.set(step);
        actionNo.set(action);
    }

    public static Integer getStepNo() {
        return stepNo.get();
    }

    public static Integer getActionNo() {
        return actionNo.get();
    }

    public static void publishLastScreenshotPath(String path) {
        lastScreenshotPath.set(path);
    }

    public static String consumeLastScreenshotPath() {
        String path = lastScreenshotPath.get();
        lastScreenshotPath.remove();
        return path;
    }

    public static void setFieldName(String name) {
        fieldName.set(name);
    }

    public static String getFieldName() {
        return fieldName.get();
    }

    public static void clear() {
        stepNo.remove();
        actionNo.remove();
        lastScreenshotPath.remove();
        fieldName.remove();
    }
}
