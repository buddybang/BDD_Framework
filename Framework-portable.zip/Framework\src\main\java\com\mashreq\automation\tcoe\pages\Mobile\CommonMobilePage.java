package com.mashreq.automation.tcoe.pages.Mobile;

import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.keywords.IActionLogger;
import com.mashreq.automation.tcoe.keywords.MobileUI;
import com.mashreq.automation.tcoe.utils.LocatorUtils;
import org.testng.Assert;

public class CommonMobilePage {
    private final MobileUI mobile;

    public CommonMobilePage(ScenarioContext ctx, IActionLogger logger) {

        this.mobile = new MobileUI(ctx, logger);
    }

    /**
     * Press Android Back button
     */
    public void pressBackButton() {

        try {

            mobile.pressBack();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to press Android Back button | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Press Android Home button
     */
    public void pressHomeButton() {

        try {

            mobile.pressHome();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to press Android Home button | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Open Android Recent Apps
     */
    public void openRecentAppsScreen() {

        try {

            mobile.openRecentApps();

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to open Android Recent Apps | Reason: "
                            + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Generic Mobile Input Method
     */
    public void enter(String moduleName,
                      String screenName,
                      String fieldName,
                      String value) {

        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }

        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }

        try {

            // Build JSON Path
            String fieldPath = moduleName + "/" + screenName + "/" + fieldName;

            String locator = LocatorUtils.byPath(fieldPath);

            if (locator == null || locator.isEmpty()) {
                throw new RuntimeException(
                        "Locator not found for field: " + fieldName);
            }

            // Enter Value
            mobile.sendKeys(locator, value);



        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to enter value for field: "
                            + fieldName
                            + " | Reason: "
                            + e.getMessage(),
                    e);
        }
    }



    /**
     * Generic "button by key" for Mobile JSON (Login Flow)
     */
    public void clickButton(String buttonKey,String ModuleName,String Screenname) {

        if (buttonKey == null || buttonKey.trim().isEmpty()) {
            throw new IllegalArgumentException("Button key cannot be null or empty");
        }

        String locator;

        try {
            // Build JSON path
            String buttonPath = ModuleName + "/" + Screenname + "/" + buttonKey;
            locator = LocatorUtils.byPath(buttonPath);

            if (locator == null || locator.isEmpty()) {
                throw new RuntimeException("Locator not found for key: " + buttonKey);
            }

            // Wait + Click

            mobile.click(locator);

        } catch (Exception e) {
            throw new RuntimeException("Failed to click button: " + buttonKey + " | Reason: " + e.getMessage(), e);
        }
    }



    public void scrollToElementAndClick(
            String elementKey,
            String moduleName,
            String screenName) {

        String elementPath =
                moduleName + "/" + screenName + "/" + elementKey;

        String locator =
                LocatorUtils.byPath(elementPath);

        // scrolls only until the element is visible (at most 10 times); it always made 11 scrolls before
        mobile.scrollToElement(locator);
        mobile.click(locator);
    }

    /**
     * Scrolls to the end of the T&C, ticks the checkbox and waits for the
     * confirm button to become enabled, re-clicking the checkbox if the
     * first tap did not register (it intermittently does not).
     */
    public void acceptTermsAndContinue(
            String termsKey,
            String confirmKey,
            String moduleName,
            String screenName) {

        String termsLocator =
                LocatorUtils.byPath(moduleName + "/" + screenName + "/" + termsKey);
        String confirmLocator =
                LocatorUtils.byPath(moduleName + "/" + screenName + "/" + confirmKey);

        // to the end of the terms: the app enables the tick box only after they were scrolled through
        for (int i = 0; i <= 10; i++) {
            mobile.scrollDown();
        }

        boolean enabled = false;
        for (int attempt = 1; attempt <= 3 && !enabled; attempt++) {
            mobile.click(termsLocator);
            // the confirm button becomes enabled once the tick registered; the tap is sometimes lost, then tap again
            enabled = mobile.waitUntilEnabled(confirmLocator, java.time.Duration.ofSeconds(3));
        }
        if (!enabled) {
            // tapping a disabled button would only fail later with a less clear message
            Assert.fail("'" + confirmKey + "' stayed disabled after ticking '" + termsKey + "' 3 times on " + screenName);
        }

        mobile.click(confirmLocator);
    }

    /** Swipes up / down ({@code times} <= 0: to the end of the content), then taps the element. Replays Lior's "Swipe and tap". */
    public void swipeVerticallyAndClick(String direction, int times, String buttonKey, String moduleName, String screenName) {
        String d = direction == null ? "" : direction.trim().toLowerCase(java.util.Locale.ROOT);
        if (!d.equals("up") && !d.equals("down")) {
            throw new IllegalArgumentException("Swipe direction must be 'up' or 'down', not '" + direction + "'");
        }
        String locator = LocatorUtils.byPath(moduleName + "/" + screenName + "/" + buttonKey);
        mobile.swipeVertically(d.equals("up"), times);
        mobile.click(locator);
    }

    public void swipeAndClickButton(
            String buttonKey,
            String moduleName,
            String screenName) {

        String buttonPath =
                moduleName + "/" + screenName + "/" + buttonKey;

        String locator =
                LocatorUtils.byPath(buttonPath);

        mobile.swipeHorizontalUntilVisibleClick(locator);
    }



    public void inputandEnter(String moduleName,
                              String screenName,
                              String fieldName,
                              String value) {

        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }

        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }

        try {

            // Build JSON Path
            String fieldPath = moduleName + "/" + screenName + "/" + fieldName;

            String locator = LocatorUtils.byPath(fieldPath);

            if (locator == null || locator.isEmpty()) {
                throw new RuntimeException(
                        "Locator not found for field: " + fieldName);
            }

            // Enter Value
            mobile.sendKeyswithEnter(locator, value);


        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to enter value for field: "
                            + fieldName
                            + " | Reason: "
                            + e.getMessage(),
                    e);
        }
    }



    public void verifyElementState(
            String elementName,
            String expectedState,
            String module,
            String screenName) {

        if (elementName == null || elementName.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Element name cannot be null or empty");
        }

        if (expectedState == null || expectedState.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Expected state cannot be null or empty");
        }

        if (module == null || module.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Module cannot be null or empty");
        }

        if (screenName == null || screenName.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Screen name cannot be null or empty");
        }

        try {

            String elementPath =
                    module + "/" + screenName + "/" + elementName;

            String locator =
                    LocatorUtils.byPath(elementPath);

            if (locator == null || locator.trim().isEmpty()) {
                throw new RuntimeException(
                        "Locator not found for path: " + elementPath);
            }

            mobile.verifyElementState(
                    locator,
                    expectedState);

        } catch (AssertionError e) {

            throw e;

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to verify element state: "
                            + elementName
                            + " | Expected State: " + expectedState
                            + " | Screen: " + screenName
                            + " | Module: " + module
                            + " | Reason: " + e.getMessage(),
                    e);
        }
    }


    public void verifyMessage(

            String messageKey,

            String expectedValue,

            String screenName,

            String module) {


        if (messageKey == null || messageKey.trim().isEmpty()) {

            throw new IllegalArgumentException(

                    "Message key cannot be null or empty");

        }


        if (expectedValue == null) {

            throw new IllegalArgumentException(

                    "Expected value cannot be null");

        }


        try {


            String messagePath =

                    module + "/" + screenName + "/" + messageKey;


            String locator = LocatorUtils.byPath(messagePath);


            if (locator == null || locator.trim().isEmpty()) {

                throw new RuntimeException(

                        "Locator not found for path: " + messagePath);

            }


            mobile.verifyText(locator, expectedValue);


        } catch (Exception e) {


            throw new RuntimeException(

                    "Failed to verify field: " + messageKey +

                            " | Expected: " + expectedValue +

                            " | Screen: " + screenName +

                            " | Reason: " + e.getMessage(),

                    e);

        }

    }


    public String retrieveText(
            String elementName,
            String module,
            String screenName) {

        if (elementName == null || elementName.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Element name cannot be null or empty");
        }

        if (module == null || module.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Module cannot be null or empty");
        }

        if (screenName == null || screenName.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Screen name cannot be null or empty");
        }

        try {

            String elementPath =
                    module + "/" + screenName + "/" + elementName;

            String locator =
                    LocatorUtils.byPath(elementPath);

            if (locator == null || locator.trim().isEmpty()) {
                throw new RuntimeException(
                        "Locator not found for path: " + elementPath);
            }

            return mobile.retrieveText(locator);

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to retrieve text for element: "
                            + elementName
                            + " | Screen: " + screenName
                            + " | Module: " + module
                            + " | Reason: " + e.getMessage(),
                    e);
        }
    }



    public void scrollAndVerifyText(
            String fieldKey,
            String expectedValue,
            String screenName,
            String moduleName) {

        mobile.scrollandVerifyText(
                fieldKey,
                expectedValue,
                screenName,
                moduleName);
    }

    public void doubleClick(
            String elementName,
            String moduleName,
            String screenName) {

        String elementPath =
                moduleName + "/" + screenName + "/" + elementName;

        String locator =
                LocatorUtils.byPath(elementPath);

        mobile.doubleClick(locator);
    }





}


