package com.mashreq.automation.tcoe.utils;

import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.remote.UnreachableBrowserException;

import java.util.Locale;

/**
 * What kind of failure a mobile keyword ran into, shown as a prefix in the step error ("[LOCATOR] Failed to click ..."),
 * so a report tells a wrong / missing element apart from a lost connection or a dead session.
 */
public enum FailureKind {
    /** The element was not found, not found in time, or the locator itself is wrong. */
    LOCATOR,
    /** The HTTP connection to Appium / BrowserStack failed (timeout, connection closed, unreachable). */
    TRANSPORT,
    /** The session no longer exists or could not be created. */
    SESSION,
    /** Wrong configuration or test data, or no driver (setup failed). */
    SETUP,
    /** The element was there but the action on it failed. */
    ACTION;

    /** Classifies by the exception and its causes; the most specific match in the chain wins. */
    public static FailureKind of(Throwable error) {
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            String message = String.valueOf(t.getMessage()).toLowerCase(Locale.ROOT);
            if (t instanceof NoSuchSessionException || t instanceof SessionNotCreatedException
                    || message.contains("invalid session id") || message.contains("session is either terminated")) {
                return SESSION;
            }
            // an HTTP read timeout arrives as Selenium's TimeoutException with a java.util.concurrent.TimeoutException
            // cause: TRANSPORT, not "element not found in time" (that TimeoutException has no such cause)
            if (t instanceof UnreachableBrowserException || t instanceof java.net.ConnectException
                    || t instanceof java.io.IOException || t instanceof java.io.UncheckedIOException
                    || t instanceof java.util.concurrent.TimeoutException
                    || t instanceof java.net.http.HttpTimeoutException
                    || message.contains("error communicating with the remote browser")
                    || message.contains("connection closed") || message.contains("connection reset")) {
                return TRANSPORT;
            }
        }
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            if (t instanceof NoSuchElementException || t instanceof InvalidSelectorException
                    || t instanceof StaleElementReferenceException || t instanceof TimeoutException) {
                return LOCATOR;
            }
            if (t instanceof IllegalStateException || t instanceof IllegalArgumentException) {
                return SETUP;
            }
        }
        return ACTION;
    }

    /** True for failures after which the session should not be used for more commands (status update, screenshots). */
    public boolean sessionLikelyLost() {
        return this == SESSION || this == TRANSPORT;
    }
}
