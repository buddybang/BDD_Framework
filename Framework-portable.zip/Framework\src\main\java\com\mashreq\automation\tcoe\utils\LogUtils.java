package com.mashreq.automation.tcoe.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class LogUtils {

    private static Logger logger = LogManager.getLogger();
    private static final ThreadLocal<String> currentScenario = new ThreadLocal<>();
    /** ThreadContext key that log4j2.xml routes on (${ctx:logFileName}): set = the scenario's own file, unset = suite.log. */
    private static final String LOG_FILE_KEY = "logFileName";

    private LogUtils() {
        // Prevent instantiation
    }

    /**
     * Initialize per-scenario logging — sets file name in ThreadContext.
     */
    public static synchronized void startScenario(String scenarioName, String logFileName) {
        String safeScenario = sanitize(scenarioName);

        currentScenario.set(safeScenario);
        startLog(System.getProperty("user.dir") + "/logs/", logFileName);

        info("************** Starting Scenario: " + scenarioName + " **************");
    }

    /**
     * End scenario log context.
     */
    public static synchronized void endScenario() {
        info("************** Ending Scenario: " + currentScenario.get() + " **************");
        currentScenario.remove();
        // was remove("logFilename") (other spelling): the key stayed set, so everything logged on this thread after the
        // scenario (the next scenario's user-pair wait, @AfterAll) went into this scenario's file
        ThreadContext.remove(LOG_FILE_KEY);
    }

    /**
     * Initializes the log file in the specified directory.
     *
     * @param dirPath     Directory path where logs are stored
     * @param logFileName Name of the log file
     */
    private static void startLog(String dirPath, String logFileName) {
        if (!SystemHelpers.createFolder(dirPath)) {
            System.err.println("Failed to create or access the log directory " + dirPath + "; logging to the console only.");
        }
        ThreadContext.put(LOG_FILE_KEY, logFileName);
    }

    private static String sanitize(String input) {
        return input.replaceAll("[^a-zA-Z0-9]", "_").replaceAll("_+", "_");
    }

    /**
     * Returns the logger instance.
     *
     * @return Logger instance
     */
    public static Logger getCurrentLog() {
        return logger;
    }

    /**
     * Builds a log context string including scenario name, class, method, and line number.
     *
     * @return Formatted string with contextual information
     */
    public static String getCallInfo() {
        String scenarioName = currentScenario.get();
        int scenarioNameLength = scenarioName != null ? scenarioName.length() : 10;

        // The first caller outside LogUtils that is not a lambda or the logAction wrapper. StackWalker reads only the
        // frames it needs (getStackTrace() built the whole stack on every log line).
        StackWalker.StackFrame element = StackWalker.getInstance().walk(frames -> frames
                .filter(f -> !f.getClassName().equals(LogUtils.class.getName()))
                .filter(f -> !f.getMethodName().contains("lambda$") && !f.getMethodName().equals("logAction"))
                .findFirst()
                .orElse(null));
        if (element == null) {
            return String.format("[ %-" + scenarioNameLength + "s ] ", scenarioName);
        }
        String fullClassName = element.getClassName();
        String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
        String methodName = element.getMethodName();
        int lineNumber = element.getLineNumber();

        return String.format("[ %-" + scenarioNameLength + "s ] [ %-15.15s:%-22.22s:%04d ] ",
                scenarioName, simpleClassName, methodName, lineNumber);
    }


    // ================== INFO ==================
    public static void info(String message) {
        getCurrentLog().info(mask(getCallInfo() + message));
    }

    public static void info(Object message) {
        getCurrentLog().info(mask(getCallInfo() + message));
    }

    public static void info(String message, Throwable throwable) {
        getCurrentLog().info(withStackTrace(getCallInfo() + message, throwable));
    }

    public static void info(String format, Object... args) {
        getCurrentLog().info(mask(getCallInfo() + String.format(format, args)));
    }

    // ------------------- Warn Level Logging -------------------

    public static void warn(String message) {
        getCurrentLog().warn(mask(getCallInfo() + message));
    }

    public static void warn(Object message) {
        getCurrentLog().warn(mask(getCallInfo() + message));
    }

    public static void warn(String format, Object... args) {
        getCurrentLog().warn(mask(getCallInfo() + String.format(format, args)));
    }

    // ------------------- Error Level Logging -------------------

    public static void error(String message) {
        getCurrentLog().error(mask(getCallInfo() + message));
    }

    public static void error(String message, Throwable throwable) {
        getCurrentLog().error(withStackTrace(getCallInfo() + message, throwable));
    }

    public static void error(Object message) {
        getCurrentLog().error(mask(getCallInfo() + message));
    }

    public static void error(Object message, Throwable throwable) {
        getCurrentLog().error(withStackTrace(getCallInfo() + message, throwable));
    }

    public static void error(String format, Object... args) {
        getCurrentLog().error(mask(getCallInfo() + String.format(format, args)));
    }

    public static void error(String format, Throwable throwable, Object... args) {
        getCurrentLog().error(withStackTrace(getCallInfo() + String.format(format, args), throwable));
    }

    // ------------------- Fatal Level Logging -------------------

    public static void fatal(String message) {
        getCurrentLog().fatal(mask(getCallInfo() + message));
    }

    public static void fatal(Object message) {
        getCurrentLog().fatal(mask(getCallInfo() + message));
    }

    public static void fatal(Object message, Throwable throwable) {
        getCurrentLog().fatal(withStackTrace(getCallInfo() + message, throwable));
    }

    // ------------------- Debug Level Logging -------------------

    public static void debug(String message) {
        getCurrentLog().debug(mask(getCallInfo() + message));
    }

    public static void debug(Object message) {
        getCurrentLog().debug(mask(getCallInfo() + message));
    }

    public static void debug(Object message, Throwable throwable) {
        getCurrentLog().debug(withStackTrace(getCallInfo() + message, throwable));
    }

    // ------------------- Trace Level Logging -------------------

    public static void trace(Object message) {
        getCurrentLog().trace(mask(message));
    }

    public static void trace(Object message, Throwable throwable) {
        getCurrentLog().trace(withStackTrace(message, throwable));
    }

    // ================== Secret masking ==================

    /** user:password@ in a URL, e.g. the BrowserStack hub URL https://<user>:<key>@hub-cloud.browserstack.com/wd/hub. */
    private static final Pattern URL_CREDENTIALS = Pattern.compile("(?i)(https?://)[^/\\s:@\"']+:[^/\\s@\"']+@");

    /** Secret values (BrowserStack access key) that must never reach a log file or the console. Read once, on first use. */
    private static volatile List<String> secrets;

    /**
     * Replaces secret values and URL credentials with ***. Every LogUtils method goes through this, so an exception message
     * that carries the key (e.g. SessionNotCreatedException, which prints every capability) is masked in logs/ and on the console.
     */
    /** Authorization: Basic / Bearer header values. */
    private static final Pattern AUTH_HEADER =
            Pattern.compile("(?i)(authorization[\\\"'\\s:=]+)(?:Basic|Bearer)\\s+[^\\s,}\\]\\\"']+");

    /** accessKey: x, password=x, "authToken":"x", apiKey ... (key and separator kept, value masked). */
    private static final Pattern SECRET_FIELD = Pattern.compile(
            "(?i)((?:access[_-]?key|password|passwd|auth[_-]?token|api[_-]?key)[\\\"'\\s]*[:=][\\\"'\\s]*)([^\\s,}\\]\\\"']+)");

    public static String mask(Object message) {
        if (message == null) {
            return null;
        }
        String text = URL_CREDENTIALS.matcher(String.valueOf(message)).replaceAll("$1***:***@");
        text = AUTH_HEADER.matcher(text).replaceAll("$1***");
        text = SECRET_FIELD.matcher(text).replaceAll("$1***");
        for (String secret : secrets()) {
            text = text.replace(secret, "***");
        }
        return text;
    }

    private static List<String> secrets() {
        List<String> values = secrets;
        if (values == null) {
            List<String> found = new ArrayList<>();
            for (String name : new String[]{"BROWSERSTACK_ACCESS_KEY", "BROWSERSTACK_USERNAME"}) {
                String value = PropertiesHelpers.getSecretValue(name);
                if (value != null && value.length() >= 8) { // a short value would mask ordinary words
                    found.add(value);
                }
            }
            values = List.copyOf(found);
            secrets = values;
        }
        return values;
    }

    /**
     * A copy of an exception chain with every message masked; types (shown by name), stack frames, causes and suppressed
     * exceptions are kept. For exceptions that go to Cucumber / Allure / Extent reports, which LogUtils does not see.
     */
    public static Throwable sanitized(Throwable error) {
        return sanitizedCopy(error, new java.util.IdentityHashMap<>());
    }

    /** True when the exception chain's text contains something mask() would hide. */
    public static boolean containsSecret(Throwable error) {
        String trace = getFullStackTrace(error);
        return !trace.equals(mask(trace));
    }

    private static Throwable sanitizedCopy(Throwable source, java.util.IdentityHashMap<Throwable, Throwable> seen) {
        if (source == null) {
            return null;
        }
        if (seen.containsKey(source)) {
            return seen.get(source);
        }
        MaskedException copy = new MaskedException(source.getClass().getName(), mask(source.getMessage()));
        seen.put(source, copy);
        copy.setStackTrace(source.getStackTrace());
        Throwable cause = sanitizedCopy(source.getCause(), seen);
        if (cause != null && cause != copy) {
            copy.initCause(cause);
        }
        for (Throwable suppressed : source.getSuppressed()) {
            Throwable s = sanitizedCopy(suppressed, seen);
            if (s != copy) {
                copy.addSuppressed(s);
            }
        }
        return copy;
    }

    /** Stands in for the original exception (its class name is shown) with a masked message. */
    private static final class MaskedException extends RuntimeException {
        private final String originalType;

        private MaskedException(String originalType, String message) {
            super(message);
            this.originalType = originalType;
        }

        @Override
        public String toString() {
            return originalType + (getMessage() == null || getMessage().isEmpty() ? "" : ": " + getMessage());
        }
    }

    /** The message and the full stack trace, masked; log4j would otherwise print the throwable unmasked. */
    private static String withStackTrace(Object message, Throwable throwable) {
        String text = String.valueOf(message);
        return throwable == null
                ? mask(text)
                : mask(text + System.lineSeparator() + getFullStackTrace(throwable));
    }

    // ================== Utility ==================
    public static String getFullStackTrace(Throwable t) {
        if (t == null) return "";
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }
}