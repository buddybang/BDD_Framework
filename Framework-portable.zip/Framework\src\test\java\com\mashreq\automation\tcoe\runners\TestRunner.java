package com.mashreq.automation.tcoe.runners;

import com.mashreq.automation.tcoe.utils.LogUtils;
import com.mashreq.automation.tcoe.reporting.DashboardGenerator;
import com.mashreq.automation.tcoe.reporting.FeatureDetailsGenerator;
import com.mashreq.automation.tcoe.utils.ScenarioGroups;
import com.mashreq.automation.tcoe.utils.ReportUtils;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@CucumberOptions(
        // Path to your feature files
        features = {"flexcube-features"},

        // Package containing your step definitions, hooks, and context
        glue = "com.mashreq.automation.tcoe",

        // Generates different report formats
        plugin = {
                "pretty",
                "html:reports/latest/cucumber-reports/cucumber-report.html",
                "json:reports/latest/cucumber-reports/cucumber-report.json",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
                "json:target/cucumber-reports/cucumber.json",
                "com.mashreq.automation.tcoe.listeners.StepEventListener",
                "rerun:target/rerun.txt" //To write failed scenarios
        },

        monochrome = true

        // Tags are NOT hard-coded here. Choose what to run from the command line, e.g.
        //   mvn test -Dcucumber.tags="@Mobile and @SC_2741358"
        // (the pom forwards it as cucumber.filter.tags). No tag = run every scenario.
        // Groups of scenarios: run-groups.properties (see ScenarioGroups).
)

public class TestRunner extends AbstractTestNGCucumberTests {

    static {
        // Before Cucumber reads its options (AbstractTestNGCucumberTests.setUpClass)
        ScenarioGroups.apply();
    }

    /**
     * This method enables parallel execution of scenarios.
     * The @DataProvider(parallel = true) annotation tells TestNG that the scenarios
     * returned by the superclass method can be distributed among worker threads.
     */
    @Override
    // Always parallel-capable; the real thread count comes from ParallelExecutionListener
    // (-Dparallel=true -Dthreads=N). Without those flags the count is 1, i.e. sequential.
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        boolean isParallel = Boolean.parseBoolean(System.getProperty("parallel", "false"));
        System.setProperty("dataprovider.parallel", String.valueOf(isParallel));
        return super.scenarios();
    }

    /**
     * This method generates the Maven Cucumber report.
     * IMPORTANT: The 'ReportUtils.generateCucumberReport()' method must also be
     * configured internally to read from "target/cucumber-reports/cucumber.json".
     */
    @AfterSuite(alwaysRun = true)
    public void generateReportsAfterSuite() {
        ReportUtils.generateCucumberReport();
    }


    /**
     * This method generates our custom FreeMarker dashboard report.
     */
    @AfterSuite(alwaysRun = true) // Added alwaysRun = true for consistency
    public void generateCustomReport() {
        try {
            System.out.println("Starting custom report generation...");

            // Path to point to the JSON file generated required for Custom Report
            String userDir = System.getProperty("user.dir");
            String masterJsonPathStr = userDir + "/reports/latest/custom-report/json/master.json";
            String templateDirStr = userDir + "/src/main/resources/templates";
            String dashboardOutputPathStr = userDir + "/reports/latest/custom-report/Dashboard.html";

            // No scenario ran (ApplicationHooks.afterAll skipped aggregation), so there is nothing to report
            if (!Files.exists(Paths.get(masterJsonPathStr))) {
                LogUtils.warn("Custom report skipped: " + masterJsonPathStr + " was not created (no scenario ran).");
                return;
            }

            // Dashboard Report Generator
            DashboardGenerator.generateReport(masterJsonPathStr, templateDirStr, dashboardOutputPathStr);

            // Feature file HTML report generator

            // 1. Define paths
            Path reportsDir = Paths.get(userDir, "reports", "latest", "custom-report");
            Path jsonSourceDir = reportsDir.resolve("json");
            Path templateDir = Paths.get(templateDirStr);

            // 2. Initialize the generator
            FeatureDetailsGenerator reportGenerator = new FeatureDetailsGenerator(templateDir);

            // 3. Call the method to generate all feature reports
            reportGenerator.generateAllFeatureReports(jsonSourceDir, reportsDir);

        } catch (Exception e) {
            LogUtils.error("Could not generate the feature reports: " + e.getMessage(), e);
        }
    }
}