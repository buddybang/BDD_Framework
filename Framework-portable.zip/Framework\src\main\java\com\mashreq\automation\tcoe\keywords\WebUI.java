package com.mashreq.automation.tcoe.keywords;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.mashreq.automation.tcoe.context.ScreenshotContextHolder;
import com.mashreq.automation.tcoe.context.ScenarioContext;
import com.mashreq.automation.tcoe.utils.CaptureHelpers;
import com.mashreq.automation.tcoe.utils.LogUtils;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.SelectOption;
import com.microsoft.playwright.options.WaitForSelectorState;
import io.cucumber.datatable.DataTable;
import org.testng.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.text.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

/**
 * A comprehensive keyword-driven engine for web UI interactions using Playwright.
 * This class provides a high-level API for actions like click, type, select, and wait,
 * abstracting low-level Playwright calls. It includes built-in logging, waiting, highlighting, and frame handling.
 * WebUI relies solely on ScenarioContext:
 * - Page from ctx (per-scenario, thread-safe)
 * - ScenarioId from ctx (for screenshots/logs)
 * No DriverManager/TestContextHolder calls inside.
 */
public final class WebUI {

    private final IActionLogger logger;
    private final ScenarioContext ctx;
    private final int timeout = FrameworkConstants.DEFAULT_TIMEOUT_MS;

    // The constructor that accepts the logger
    public WebUI(ScenarioContext ctx, IActionLogger logger) {
        this.ctx = ctx;
        this.logger = (logger != null) ? logger : new NoOpActionLogger();
    }

    /* ------------- accessors ------------- */
    public Page page() {
        Page p = ctx.getPage();
        if (p == null) throw new IllegalStateException("Context Page is null. Did you set it in @Before?");
        return p;
    }

    private String scenarioId() {
        return ctx.getScenarioId();
    }

    // ===========================================================
    // ELEMENT SEARCH & FRAME UTILITIES
    // ===========================================================

    /**
     * Searches for a visible element across all frames (main + nested) with short polling.
     * Handles nested frames and retries until the timeout is reached.
     *
     * @param selector CSS or XPath selector of the element
     * @return the Locator representing the found element
     * @throws PlaywrightException if the element is not found within the timeout
     */
    public Locator findElementInFrame(String selector) {
        return findElementInFrame(selector, true);
    }

    /**
     * Like {@link #findElementInFrame(String)}; with {@code mustBeVisible} false an element that is in the page but hidden is
     * found too (the first one). Used for file uploads: file boxes are usually hidden behind a "Click to upload" area.
     */
    public Locator findElementInFrame(String selector, boolean mustBeVisible) {
        // Split combined "field|locator" if present
        String fieldName = null;
        String locatorToUse = selector;
        if (selector != null) {
            int sep = selector.indexOf('|'); // split on first pipe
            if (sep >= 0) {
                fieldName = selector.substring(0, sep);
                locatorToUse = selector.substring(sep + 1);
                if (fieldName != null) fieldName = fieldName.trim();
                if (locatorToUse != null) locatorToUse = locatorToUse.trim();

                // store final field name in ThreadLocal for reporting/logging
                try {
                    ScreenshotContextHolder.setFieldName(fieldName);
                    LogUtils.debug("FiledName:" + fieldName);
                } catch (Exception e) {
                    // safe-guard: do not break element lookup if setter is missing or fails
                    LogUtils.debug("Unable to set fieldName in ScreenshotContextHolder: " + e.getMessage());
                }
            }
        }

        Page page = page();
        long totalTimeout = timeout;
        long deadline = System.currentTimeMillis() + totalTimeout;
        long perFrameCheckInterval = 500;

        PlaywrightException lastException = null;

        while (System.currentTimeMillis() < deadline) {
            List<Frame> allFrames = new ArrayList<>();
            collectAllFrames(page.mainFrame(), allFrames);

            for (Frame frame : allFrames) {
                if (frame.isDetached()) continue;
                try {
                    Locator element = frame.locator(locatorToUse);
                    if (!mustBeVisible && element.count() > 0) {
                        element = element.first();
                    }
                    if (mustBeVisible ? element.isVisible() : element.count() > 0) {
                        LogUtils.info("Element found in frame: " +
                                (frame.name().isEmpty() ? frame.url() : frame.name())
                                + " using locator: " + locatorToUse
                                + (fieldName != null ? " (field=" + fieldName + ")" : ""));
                        return element;
                    }
                } catch (PlaywrightException e) {
                    lastException = e;
                    LogUtils.debug("Element not in frame: " +
                            (frame.name().isEmpty() ? frame.url() : frame.name()) +
                            " using locator: " + locatorToUse);
                }
            }

            page.waitForTimeout(perFrameCheckInterval);
        }

        String message = "Element not found with selector: [" + selector + "] within " + totalTimeout + "ms";
        if (lastException != null) {
            throw new PlaywrightException(message, lastException);
        } else {
            throw new PlaywrightException(message);
        }
    }

    /**
     * The first VISIBLE element of all matches of the selector ("field|locator" allowed), in the page or any frame;
     * waits up to the timeout for one to appear.
     */
    private Locator findFirstVisibleInFrames(String selector) {
        String locatorToUse = selector;
        int sep = selector == null ? -1 : selector.indexOf('|');
        if (sep >= 0) {
            ScreenshotContextHolder.setFieldName(selector.substring(0, sep).trim());
            locatorToUse = selector.substring(sep + 1).trim();
        }
        Page page = page();
        long deadline = System.currentTimeMillis() + timeout;
        while (System.currentTimeMillis() < deadline) {
            List<Frame> allFrames = new ArrayList<>();
            collectAllFrames(page.mainFrame(), allFrames);
            for (Frame frame : allFrames) {
                if (frame.isDetached()) continue;
                Locator all = frame.locator(locatorToUse);
                int count = all.count();
                for (int i = 0; i < count; i++) {
                    if (all.nth(i).isVisible()) {
                        LogUtils.info("Visible element " + (i + 1) + " of " + count + " found for: " + locatorToUse);
                        return all.nth(i);
                    }
                }
            }
            page.waitForTimeout(500); // poll interval
        }
        throw new PlaywrightException("No visible element for selector [" + selector + "] within " + timeout + "ms");
    }

    /** Wait for an element that may or may not appear (overrides table, "last page" link): short, not the full timeout. */
    private static final long OPTIONAL_ELEMENT_WAIT_MS = 3000;

    /**
     * True when the element ("field|locator" allowed) is visible in the page or a frame within {@code millis}.
     * For optional elements: does not fail the step and does not wait the full element timeout.
     */
    public boolean isVisibleWithin(String selector, long millis) {
        String locatorToUse = selector;
        int sep = selector == null ? -1 : selector.indexOf('|');
        if (sep >= 0) {
            locatorToUse = selector.substring(sep + 1).trim();
        }
        Page page = page();
        long deadline = System.currentTimeMillis() + millis;
        while (true) {
            if (firstVisibleMatch(page, locatorToUse) != null) {
                return true;
            }
            if (System.currentTimeMillis() >= deadline) {
                return false;
            }
            page.waitForTimeout(250); // poll interval
        }
    }

    /** Sets a (read-only) field's value from JavaScript, passing the value as an argument, and fires input + change. */
    private static void setValueWithEvents(Locator element, String value) {
        element.evaluate("(el, v) => { el.value = v;"
                + " el.dispatchEvent(new Event('input', { bubbles: true }));"
                + " el.dispatchEvent(new Event('change', { bubbles: true })); }", value);
    }

    /** Values typed into password / PIN / OTP fields are not written to logs and reports. */
    private static final Pattern SECRET_FIELD = Pattern.compile("(?i).*(pass|pwd|pin|otp|secret|cvv|token).*");

    static String shown(String locator, String text) {
        int sep = locator == null ? -1 : locator.indexOf('|');
        String field = sep > 0 ? locator.substring(0, sep) : String.valueOf(ScreenshotContextHolder.getFieldName());
        if (text != null && SECRET_FIELD.matcher(field).matches()) {
            return "*".repeat(Math.min(text.length(), 8));
        }
        return text;
    }

    /**
     * Actual contains Expected as a whole word / number: spaces normalised, no letter or digit directly before or after
     * the match. An empty Expected matches only an empty Actual.
     */
    static boolean containsWhole(String actual, String expected) {
        String a = actual == null ? "" : actual.replaceAll("\\s+", " ").trim();
        String e = expected == null ? "" : expected.replaceAll("\\s+", " ").trim();
        if (e.isEmpty()) {
            return a.isEmpty();
        }
        for (int i = a.indexOf(e); i >= 0; i = a.indexOf(e, i + 1)) {
            int end = i + e.length();
            boolean startOk = !Character.isLetterOrDigit(e.charAt(0)) || (i == 0 || !Character.isLetterOrDigit(a.charAt(i - 1))
                    && !(Character.isDigit(e.charAt(0)) && isNumberSeparator(a, i - 1, -1)));
            boolean endOk = !Character.isLetterOrDigit(e.charAt(e.length() - 1)) || (end == a.length()
                    || !Character.isLetterOrDigit(a.charAt(end))
                    && !(Character.isDigit(e.charAt(e.length() - 1)) && isNumberSeparator(a, end, 1)));
            if (startOk && endOk) {
                return true;
            }
        }
        return false;
    }

    /** A ',' or '.' at {@code at} with a digit on its far side: inside a number such as 1,100.00. */
    private static boolean isNumberSeparator(String text, int at, int direction) {
        int beyond = at + direction;
        return at >= 0 && at < text.length() && (text.charAt(at) == ',' || text.charAt(at) == '.')
                && beyond >= 0 && beyond < text.length() && Character.isDigit(text.charAt(beyond));
    }

    /**
     * Recursively collects all frames starting from the root frame.
     *
     * @param root        starting frame
     * @param accumulator list to store all frames
     */
    private static void collectAllFrames(Frame root, List<Frame> accumulator) {
        accumulator.add(root);
        for (Frame child : root.childFrames()) {
            collectAllFrames(child, accumulator);
        }
    }

    public void highlightElement(Locator locator) {
        if (locator == null) return;

        boolean highlightApplied = false;

        try {
            if (FrameworkConstants.HIGHLIGHT) {
                locator.evaluate("element => element.style.border = '3px solid red'");
                highlightApplied = true;
            }
            locator.scrollIntoViewIfNeeded();
        } catch (Exception e) {
            LogUtils.warn("Highlight or scroll failed: " + e.getMessage());
        } finally {
            try {
                capturescreenshot();
            } catch (Exception e) {
                LogUtils.warn("Screenshot capture failed: " + e.getMessage());
            }

            if (highlightApplied) {
                try {
                    locator.evaluate("element => element.style.border = ''");
                } catch (Exception e) {
                    LogUtils.warn("Removing highlight failed: " + e.getMessage());
                }
            }
        }
    }

    public void capturescreenshot() {
        String path = CaptureHelpers.takeScreenshot(
                page(),
                scenarioId()
        );
        ScreenshotContextHolder.publishLastScreenshotPath(path);
    }


    public static String simplifyLocator(String locator) {
        if (locator == null) return null;

        // --- NEW: handle combined "fieldName|locator" format ---
        String fieldName = null;
        String actualLocator = locator;

        int sep = locator.indexOf('|');
        if (sep >= 0) {
            fieldName = locator.substring(0, sep);
            actualLocator = locator.substring(sep + 1);
            // store field name in context (thread-safe)
            ScreenshotContextHolder.setFieldName(fieldName);
        }

        // --- existing simplify logic ---
        actualLocator = actualLocator.trim();
        Pattern p = Pattern.compile("^//[a-zA-Z]+\\[@id=['\"]([^'\"]+)['\"]]$");
        Matcher m = p.matcher(actualLocator);
        if (m.matches()) {
            return "#" + m.group(1); // convert to CSS by id
        }

        // Not a simple @id locator → return as-is
        return actualLocator;
    }


    // ===========================================================
    // PAGE OPERATIONS
    // ===========================================================

    /**
     * Waits for the page to completely load, including DOM, jQuery, and AngularJS.
     */
    public void waitForPageToLoad() {
        try {
            Page page = page();
            page.waitForLoadState(LoadState.DOMCONTENTLOADED, new Page.WaitForLoadStateOptions().setTimeout(60000));
            page.waitForFunction("() => document.readyState === 'complete'");
            page.waitForFunction("() => !window.jQuery || (!window.jQuery.active && !(window.jQuery.ajax && window.jQuery.ajax.active))");
            page.waitForFunction(
                    "() => {" +
                            "if (!window.angular) return true;" +
                            "const injector = window.angular.element(document.body).injector();" +
                            "if (!injector) return true;" +
                            "const $rootScope = injector.get('$rootScope');" +
                            "return !$rootScope.$$phase;" +
                            "}"
            );
        } catch (Exception e) {
            LogUtils.warn("The page did not finish loading within the wait (" + e.getMessage()
                    + "). Continuing: the next step waits for its own element.");
        }
    }

    /**
     * Navigates the browser to a specified URL.
     *
     * @param url URL to navigate to
     */
    /**
     * Browser Back button: goes to the previous page of this tab and waits for it to load.
     * Fails when there is no previous page.
     */
    public void navigateBack() {
        logger.logAction("Go back to the previous page", () -> {
            String from = page().url();
            Response response;
            try {
                response = page().goBack();
            } catch (PlaywrightException e) {
                LogUtils.error("Going back from " + from + " failed", e);
                Assert.fail("Going back from " + from + " failed: " + e.getMessage());
                return null;
            }
            // single-page applications go back without loading a document, so no response does not mean failure
            if (response == null && from.equals(page().url())) {
                Assert.fail("There is no previous page to go back to (still on " + from + ").");
            }
            waitForPageToLoad();
            LogUtils.info("Went back from " + from + " to " + page().url());
            return null;
        });
    }

    public void navigateToUrl(String url) {
        logger.logAction("Navigate to URL: " + url, () -> {
            try {
                page().navigate(url);
                LogUtils.info("Navigated to URL: " + url);
            } catch (Exception e) {
                LogUtils.error("Failed to navigate to URL: " + url, e);
                Assert.fail("Failed to navigate to URL: " + url);
            }
        });
    }

    // ===========================================================
    // ELEMENT INTERACTIONS
    // ===========================================================

    /**
     * Clicks on an element, with fallback to JavaScript click if native click fails.
     *
     * @param locator CSS/XPath of the element
     */
    public void click(String locator) {

        String elementID = simplifyLocator(locator);
        logger.logAction("Click '" + ScreenshotContextHolder.getFieldName() + "'<br>Locator: " + elementID, () -> {
            Locator element;
            try {
                element = findElementInFrame(locator);
                highlightElement(element);

                try {
                    element.click();
                    LogUtils.info("Successfully clicked on element: " + locator);
                } catch (PlaywrightException clickError) {
                    LogUtils.warn("Standard click failed for '" + locator + "', using JS click.");
                    element.evaluate("el => el.click()");
                    LogUtils.info("Successfully clicked on element via JavaScript: " + locator);
                }

            } catch (Exception e) {
                String errorMessage = "Failed to click on element: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Clicks a visible element from a list of elements. If the native click fails, it attempts a JavaScript click as a fallback.
     *
     * @param locator CSS/XPath of the element
     */
    public void clickFirstVisibleElement(String locator) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Click on element: " + ScreenshotContextHolder.getFieldName() + " ( "+ elementID + " )", () -> {
            Locator element;
            try {
                element = findFirstVisibleInFrames(locator);
                highlightElement(element);


                try {
                    element.click();
                    LogUtils.info("Successfully clicked on element: " + locator);
                } catch (PlaywrightException clickError) {
                    LogUtils.warn("Standard click failed for '" + locator + "', using JS click.");
                    element.evaluate("el => el.click()");
                    LogUtils.info("Successfully clicked on element via JavaScript: " + locator);
                }

            } catch (Exception e) {
                String errorMessage = "Failed to click on element: " + locator;
                LogUtils.error(errorMessage, e);
                Assert.fail(errorMessage, e);
            }
        });

    }

    /**
     * Double clicks an element, with JavaScript fallback.
     *
     * @param locator CSS/XPath of the element
     */
    public void doubleClick(String locator) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Double-click '" + ScreenshotContextHolder.getFieldName() + "'<br>Locator: " + elementID, () -> {
            Locator element;
            try {
                element = findElementInFrame(locator);
                highlightElement(element);

                try {
                    element.dblclick();
                    LogUtils.info("Successfully double-clicked on element: " + locator);
                } catch (PlaywrightException clickError) {
                    LogUtils.warn("Native double-click failed for '" + locator + "', using JS fallback.");
                    String jsDblClickScript = """
                            element => {
                                const evt = new MouseEvent('dblclick', { bubbles: true, cancelable: true, view: window });
                                element.dispatchEvent(evt);
                            }
                            """;
                    element.evaluate(jsDblClickScript);
                    LogUtils.info("Successfully double-clicked via JavaScript: " + locator);
                }

            } catch (Exception e) {
                String errorMessage = "Failed to double-click on element: " + locator;
                LogUtils.error(errorMessage, e);
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Sends keys/text to an element. Uses JS fallback if element is readonly.
     *
     * @param locator  CSS/XPath of the element
     * @param testdata text to input
     */
    public void sendKeys(String locator, String testdata) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Enter '" + shown(locator, testdata) + "' in '" + ScreenshotContextHolder.getFieldName() + "' textbox. <br>Locator: " + elementID, () -> {
            Locator element;
            try {
                element = findElementInFrame(locator);

                boolean isReadOnly = Boolean.TRUE.equals(element.evaluate("el => el.hasAttribute('readonly')"));

                if (!isReadOnly) {
                    element.fill(testdata);
                } else {
                    LogUtils.warn("Element is readonly, using JS fallback.");
                    setValueWithEvents(element, testdata);
                }

                highlightElement(element);
                LogUtils.info("Successfully entered '" + shown(locator, testdata) + "' into element: " + locator);

            } catch (Exception e) {
                String errorMessage = "Failed to enter text '" + shown(locator, testdata) + "' into element: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Sends keys/text to an element. Uses JS fallback if element is readonly.
     *
     * @param locator  CSS/XPath of the element
     * @param testdata text to input
     */
    public void sendKeysTab(String locator, String testdata) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Enter '" + shown(locator, testdata) + "' in '" + ScreenshotContextHolder.getFieldName() + "' textbox and press Tab.<br>Locator: " + elementID, () -> {
            Locator element;
            try {
                element = findElementInFrame(locator);

                boolean isReadOnly = Boolean.TRUE.equals(element.evaluate("el => el.hasAttribute('readonly')"));

                if (!isReadOnly) {
                    element.fill(testdata);
                } else {
                    LogUtils.warn("Element is readonly, using JS fallback.");
                    setValueWithEvents(element, testdata);
                }

                highlightElement(element);
                page().keyboard().press("Tab");
                LogUtils.info("Successfully entered '" + shown(locator, testdata) + "' into element: " + locator);

            } catch (Exception e) {
                String errorMessage = "Failed to enter text '" + shown(locator, testdata) + "' into element: " + locator;
                LogUtils.error(errorMessage, e);
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Selects a dropdown option by text or value. Handles standard and custom dropdowns.
     *
     * @param locator  CSS/XPath of the dropdown
     * @param testdata option text/value to select
     */
    public void selectOption(String locator, String testdata) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Select '" + testdata + "' from '" + ScreenshotContextHolder.getFieldName() + "' dropdown.<br>Locator: " + elementID, () -> {
            Locator dropdown = null;

            try {
                dropdown = findElementInFrame(locator);

                highlightElement(dropdown);
                dropdown.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));

                String tagName = dropdown.evaluate("el => el.tagName.toLowerCase()").toString();

                if ("select".equals(tagName)) {
                    // Standard <select> dropdown. The option is picked in the page in one go: the text a person sees
                    // (spaces ignored), else the option value, else the first option whose text contains the value
                    // ("911000000001 — SAVINGS" for "911000000001 — SAVINGS (₹249,880)": the balance changes, so Lior
                    // leaves it out). Playwright's selectOption by a label that is not there waits the full timeout - twice
                    // (label, then value) - before the partial match was tried, which made such a step look stuck.
                    // Options loaded a moment later (from the server) are waited for, up to the timeout.
                    String pick = "(el, want) => { const n = s => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();"
                            + " const w = n(want); const opts = Array.from(el.options);"
                            + " let o = opts.find(x => n(x.label || x.text) === w) || opts.find(x => x.value === want)"
                            + " || opts.find(x => w && n(x.text).includes(w));"
                            + " return o ? { found: true, value: o.value, text: (o.text || '').replace(/\\s+/g, ' ').trim() }"
                            + " : { found: false, text: opts.map(x => (x.text || '').replace(/\\s+/g, ' ').trim()).join(' | ') }; }";
                    long end = System.currentTimeMillis() + timeout;
                    java.util.Map<?, ?> hit;
                    while (true) {
                        hit = (java.util.Map<?, ?>) dropdown.evaluate(pick, testdata);
                        if (Boolean.TRUE.equals(hit.get("found")) || System.currentTimeMillis() > end) {
                            break;
                        }
                        page().waitForTimeout(250);
                    }
                    if (!Boolean.TRUE.equals(hit.get("found"))) {
                        throw new RuntimeException("Option '" + testdata + "' not found in dropdown: " + locator + ". Options shown: " + hit.get("text"));
                    }
                    dropdown.selectOption(new SelectOption().setValue(String.valueOf(hit.get("value"))));
                    LogUtils.info("Successfully selected option '" + hit.get("text") + "' from dropdown: " + locator);
                    return;
                } else {
                    // Custom drop-down (Angular Material, PrimeNG, div/li lists ...): open it, then pick the option
                    // by the text a person sees. Option texts often contain icon names in the page
                    // ("smart_toyAutomation"), so the visible text is read without icons.
                    dropdown.click(); // Playwright waits until the drop-down can be clicked
                    Locator options = page().locator("xpath=//*[@role='option' or contains(concat(' ', normalize-space(@class), ' '), ' mat-mdc-option ')"
                            + " or contains(concat(' ', normalize-space(@class), ' '), ' mat-option ') or self::li[ancestor::*[@role='listbox']]]");
                    try {
                        options.first().waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(timeout));
                    } catch (PlaywrightException noList) {
                        throw new RuntimeException("The option list of " + locator + " did not open.", noList);
                    }
                    String wanted = testdata.trim().replaceAll("\\s+", " ");
                    Locator exact = null;
                    Locator partial = null;
                    int partialCount = 0;
                    List<String> seen = new ArrayList<>();
                    for (int i = 0; i < options.count(); i++) {
                        Locator option = options.nth(i);
                        if (!option.isVisible()) {
                            continue;
                        }
                        String text = String.valueOf(option.evaluate(
                                "el => { const c = el.cloneNode(true);"
                                        + " c.querySelectorAll('mat-icon, .material-icons, .mat-icon, [aria-hidden=\"true\"]').forEach(i => i.remove());"
                                        + " return c.textContent.replace(/\\s+/g, ' ').trim(); }"));
                        seen.add(text);
                        if (text.equalsIgnoreCase(wanted)) {
                            exact = option;
                            break;
                        }
                        if (text.toLowerCase().contains(wanted.toLowerCase())) {
                            partialCount++;
                            if (partial == null) {
                                partial = option;
                            }
                        }
                    }
                    Locator pick = exact != null ? exact : (partialCount == 1 ? partial : null);
                    if (pick == null) {
                        throw new RuntimeException("Option '" + testdata + "' not found in " + locator
                                + (partialCount > 1 ? " (" + partialCount + " options contain it - use the full text)" : "")
                                + ". Options shown: " + seen);
                    }
                    highlightElement(pick);
                    pick.click();
                    LogUtils.info("Successfully selected option '" + testdata + "' from custom dropdown: " + locator);
                }

            } catch (Exception e) {
                String errorMessage = "Failed to select option '" + testdata + "' from dropdown: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Selects a radio button element.
     *
     * @param locator CSS/XPath of the radio button
     */
    public void selectRadioButton(String locator) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Select radio button '" + ScreenshotContextHolder.getFieldName() + "'<br>Locator: " + elementID, () -> {
            Locator radioButton;
            try {
                radioButton = findElementInFrame(locator);
                highlightElement(radioButton);
                radioButton.click();
                if (radioButton.isChecked()) {
                    LogUtils.info("Radio button selected: " + locator);
                } else {
                    throw new RuntimeException("Radio button not selected after click: " + locator);
                }
            } catch (Exception e) {
                String errorMessage = "Failed to select radio button: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Sets the state of a checkbox, leveraging a custom helper method that finds
     * the element across all frames in a performant way for complex applications.
     *
     * @param locator  The Playwright selector for the checkbox input element.
     * @param testdata "check" or "true" to check the box; any other value unchecks it.
     */
    public void selectCheckbox(String locator, String testdata) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Checkbox [" + elementID + "] is " + testdata + "ed.", () -> {
            try {
                Locator checkbox = findElementInFrame(locator);
                boolean shouldBeChecked = testdata != null &&
                        ("check".equalsIgnoreCase(testdata) || "true".equalsIgnoreCase(testdata));

                String action = shouldBeChecked ? "Checking" : "Unchecking";
                LogUtils.info(action + " checkbox [" + locator + "].");

                if (shouldBeChecked) {
                    checkbox.check();
                } else {
                    checkbox.uncheck();
                }

                // Verify the final state using Playwright's auto-retrying assertions.
                if (shouldBeChecked) {
                    assertThat(checkbox).isChecked();
                    LogUtils.info("SUCCESS: Checkbox [" + locator + "] is checked.");
                } else {
                    assertThat(checkbox).not().isChecked();
                    LogUtils.info("SUCCESS: Checkbox [" + locator + "] is unchecked.");
                }

            } catch (Exception e) {
                String errorMessage = "Failed to set checkbox state for: " + locator + ". Reason: " + e.getMessage();
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Waits for a given duration.
     *
     * @param secondsStr duration in seconds (can be fractional)
     */
    public void waitForDuration(String secondsStr) {
        logger.logAction("Waited for " + secondsStr, () -> {
            try {
                double seconds = Double.parseDouble(secondsStr.trim());
                long millis = (long) (seconds * 1000);
                Page page = page();
                LogUtils.info("Waiting for " + seconds + " seconds...");
                page.waitForTimeout(millis);
            } catch (Exception e) {
                String errorMessage = "Invalid wait duration: " + secondsStr;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * Verifies that the given element contains the expected text.
     * This is a convenience method that defaults to standard text verification (no numeric precision logic).
     * By default, this is a hard assertion and will fail the test if the text does not match.
     *
     * @param locator      The selector of the element to verify.
     * @param expectedText The expected text content.
     * @param soft         If true, uses a soft assertion; if false (default), uses a hard assertion.
     * @return A formatted string message indicating the result (PASSED or FAILED).
     */
    public String verifyText(String locator, String expectedText, boolean soft) {
        // We pass '-1' to indicate: "Just do normal text verification, no numeric math"
        return verifyText(locator, expectedText, soft, -1);
    }

    /**
     * Verifies that the given element matches the expected value, with optional numeric precision control.
     * <p>
     * If {@code precision} is <b>-1</b>, performs a standard text verification: Actual contains Expected as a whole word /
     * number (spaces normalised; "10" does not match "100"; an empty Expected only matches an empty Actual).
     *

     * If {@code precision} is <b>0 or greater</b>, performs a strict numeric verification:
     * <ul>
     *     <li>Parses strings to BigDecimals (handling commas).</li>
     *     <li>Truncates (does not round up) both values to the specified decimal places.</li>
     *     <li>Pads with zeros if the actual value has fewer decimals than the precision.</li>
     * </ul>
     *
     * @param locator      The selector of the element to verify.
     * @param expectedText The expected text or numeric value.
     * @param soft         If true, uses a soft assertion; if false, uses a hard assertion.
     * @param precision    The number of decimal places to check. Pass -1 for standard string comparison.
     * @return A formatted string message indicating the result (PASSED or FAILED).
     */
    public String verifyText(String locator, String expectedText, boolean soft, int precision) {
        final int WAIT_SECONDS = 10; // hard-coded wait seconds for highlight/screenshot
        final long waitMillis = WAIT_SECONDS * 1000L;

        String elementID = simplifyLocator(locator);

        // Adjust log message based on verification type
        String logMsg = (precision >= 0)
                ? "Verify '" + ScreenshotContextHolder.getFieldName() + "' numeric value matches '" + expectedText + "' (checked to " + precision + " decimals).<br>Locator: " + elementID
                : "Verify '" + ScreenshotContextHolder.getFieldName() + "' field contains text '" + expectedText + "'.<br>Locator: " + elementID;

        return logger.logAction(logMsg, () -> {
                    Locator element = null;
                    try {
                        String actualText = "";

                        // IMPORTANT: findElementInFrame must return a lazy Locator (page.locator(...) / frame.locator(...))
                        element = findElementInFrame(locator);

                        // Read text immediately (no waiting)
                        String tagName = element.evaluate("el => el.tagName.toLowerCase()").toString();

                        if ("input".equals(tagName) || "textarea".equals(tagName)) {
                            actualText = element.inputValue();
                        } else if ("select".equals(tagName)) {
                            Object selectedText = element.evaluate(
                                    "el => Array.from(el.selectedOptions).map(o => o.textContent.trim()).join('\\n')"
                            );
                            actualText = selectedText != null ? selectedText.toString() : "";
                        } else {
                            actualText = element.innerText();
                            if (actualText == null || actualText.trim().isEmpty()) {
                                Object rawText = element.evaluate("el => el.textContent");
                                actualText = rawText != null ? rawText.toString().trim() : "";
                            }
                        }

                        // --- Attempt to wait for visibility only for highlight/screenshot ---
                        try {
                            element.isVisible();
                            // if visible within waitMillis, highlight and capture screenshot of visible state
                            highlightElement(element);
                        } catch (PlaywrightException waitEx) {
                            // timed out or other playwrightexception while waiting for visibility
                            LogUtils.info("Element not visible within " + WAIT_SECONDS + "s; skipping highlight. Locator: " + locator);
                            // still capture screenshot of current state (without highlight)
                            capturescreenshot();
                        }


                        // --- 3. COMPARISON LOGIC ---
                        boolean isMatch = false;
                        String comparisonNote = "";

                    // CASE A: Numeric Verification
                        if (precision >= 0) {
                            try {
                                // Clean strings (remove commas)
                                String cleanExp = expectedText.replaceAll(",", "").trim();
                                String cleanAct = actualText.replaceAll(",", "").trim();

                                if (cleanExp.isEmpty() && cleanAct.isEmpty()) {
                                    isMatch = true;
                                } else if (!cleanExp.isEmpty()) {
                                    // Create BigDecimal
                                    BigDecimal expBD = new BigDecimal(cleanExp);
                                    BigDecimal actBD = new BigDecimal(cleanAct);

                                    // Apply Precision & Truncate (RoundingMode.DOWN)
                                    BigDecimal expScaled = expBD.setScale(precision, RoundingMode.DOWN);
                                    BigDecimal actScaled = actBD.setScale(precision, RoundingMode.DOWN);

                                    isMatch = (expScaled.compareTo(actScaled) == 0);

                                    // Log the values nicely (No scientific notation, no extra zeros)
                                    comparisonNote = " [Math: " + actScaled.stripTrailingZeros().toPlainString() +
                                            " == " + expScaled.stripTrailingZeros().toPlainString() + "]";
                                }
                            } catch (Exception e) {
                                // Fallback to standard text check if parsing fails
                                isMatch = containsWhole(actualText, expectedText);
                                comparisonNote = " [Non-numeric comparison]";
                            }
                        }
// CASE B: Standard Text Verification
                        else {
                            isMatch = containsWhole(actualText, expectedText);
                        }

// --- 4. Reporting ---
                        if (isMatch) {
                            String successMsg = "PASSED | Expected='" + expectedText + "' | Actual='" + actualText + "'";
                            LogUtils.info("Verification Passed: " + locator + comparisonNote);
                            return successMsg;
                        } else {
                            String failMsg = "FAILED | Expected='" + expectedText + "' | Actual='" + actualText + "'";
                            LogUtils.error("Verification FAILED: " + locator + comparisonNote);
                            if (!soft) throw new AssertionError(failMsg + comparisonNote);
                            return failMsg;
                        }

                    } catch (Exception e) {
                        String errorMsg = "ERROR verifying text for element: " + locator +
                                "\nExpected: '" + expectedText + "'\nException: " + e.getMessage();
                        LogUtils.error(errorMsg, e);
                        // try to capture whatever we can
                        try { capturescreenshot(); } catch (Exception ex) { /* ignore screenshot failures */ }
                        if (!soft) Assert.fail(errorMsg, e);
                        return errorMsg;
                    }
                }
        );
    }


    /**
     * Verifies that the given element is visible on the screen.
     * By default, this is a hard assertion and will fail the test if the element is not visible.
     * Optionally, you can set soft=true to only log the failure without failing the test.
     *
     * @param locator The selector of the element to verify.
     * @param soft    If true, uses a soft assertion; if false (default), uses a hard assertion.
     */
    public boolean verifyIsDisplayed(String locator, boolean soft) {
        String elementID = simplifyLocator(locator);
        return logger.logAction(
                "Verify element '" + ScreenshotContextHolder.getFieldName() + "' field is displayed<br>Locator: " + elementID,
                () -> {

                    try {
                        Locator element = findElementInFrame(locator);
                        highlightElement(element);

                        try {
                            assertThat(element).isVisible();
                            LogUtils.info("Verified: Element '" + locator + "' is visible on the screen.");
                            return true; // logged in ActionInfo.result
                        } catch (AssertionError ae) {
                            String errorMessage = "Verification failed: Element '" + locator + "' is NOT visible.";
                            LogUtils.error(errorMessage);
                            if (!soft) {
                                Assert.fail(errorMessage, ae);
                            }
                            return false; // still logged if soft
                        }

                    } catch (Exception e) {
                        String errorMessage = "Unexpected error while verifying visibility of element: " + locator;
                        LogUtils.error(errorMessage, e);
                        capturescreenshot();
                        if (!soft) {
                            Assert.fail(errorMessage, e);
                        }
                        return false; // logged in case of error
                    }
                }
        );
    }

    /**
     * Validates that a given element is NOT visible on the UI.
     *
     * Behavior:
     * - Test PASSES when the element is hidden or not present in the DOM.
     * - Test FAILS immediately when the element is visible on the screen.
     *
     * Assertion Type:
     * - Uses Playwright negative visibility assertion: not().isVisible()
     *
     * Soft Assertion Handling:
     * - soft = false → Hard assertion (fails test execution).
     * - soft = true  → Soft assertion (logs failure but continues execution).
     *
     * Logging & Reporting:
     * - Logs action step using framework logger.
     * - Highlights element and captures screenshot on failure.
     *
     * Use Case Example:
     * - Validating restricted rows, hidden buttons, permission-based UI elements.
     * - Example: "//tr[.//input[@value='ACCR']]"
     *
     * @param locator XPath/CSS selector of the target element.
     * @param soft Flag to enable soft assertion behavior.
     * @return true if element is NOT visible, false if element is visible (soft mode only).
     */

    public boolean verifyElementNotVisible(String locator, boolean soft) {

        String elementID = simplifyLocator(locator);

        return logger.logAction(
                "Verify element '" + ScreenshotContextHolder.getFieldName() + "' is NOT visible<br>Locator: " + elementID,
                () -> {
                    // passes as soon as no match is visible in the page or any frame (absent counts as not visible);
                    // waits up to the timeout for a visible one to go away. A broken selector is an error, not a pass.
                    String selector = locator;
                    int sep = selector.indexOf('|');
                    if (sep >= 0) {
                        selector = selector.substring(sep + 1).trim();
                    }
                    try {
                        Page page = page();
                        long deadline = System.currentTimeMillis() + timeout;
                        Locator stillVisible;
                        do {
                            stillVisible = firstVisibleMatch(page, selector);
                            if (stillVisible == null) {
                                LogUtils.info("PASS: Element '" + locator + "' is NOT visible.");
                                return true;
                            }
                            page.waitForTimeout(500); // poll interval
                        } while (System.currentTimeMillis() < deadline);

                        String errorMessage = "FAIL: Element '" + locator + "' IS visible but expected NOT visible.";
                        LogUtils.error(errorMessage);
                        highlightElement(stillVisible);
                        if (!soft) {
                            Assert.fail(errorMessage);
                        }
                        return false;
                    } catch (PlaywrightException e) {
                        String errorMessage = "ERROR while verifying NOT visible state: " + locator;
                        LogUtils.error(errorMessage, e);
                        capturescreenshot();
                        if (!soft) {
                            Assert.fail(errorMessage, e);
                        }
                        return false;
                    }
                }
        );
    }

    /** The first visible match of the selector in the page or any (attached) frame, or null. */
    private static Locator firstVisibleMatch(Page page, String selector) {
        List<Frame> allFrames = new ArrayList<>();
        collectAllFrames(page.mainFrame(), allFrames);
        for (Frame frame : allFrames) {
            if (frame.isDetached()) continue;
            Locator all = frame.locator(selector);
            int count = all.count();
            for (int i = 0; i < count; i++) {
                if (all.nth(i).isVisible()) {
                    return all.nth(i);
                }
            }
        }
        return null;
    }

    public String retrieveText(String locator, String testdata) {
        String elementID = simplifyLocator(locator);
        return logger.logAction("Retrieve text from '" + ScreenshotContextHolder.getFieldName() + "'.<br>Locator: " + elementID, () -> {
            try {
                if (testdata == null) {
                    String msg = "Invalid test data format for retrieve. Expected 'key:value', but got: '" + testdata + "'";
                    LogUtils.error(msg);
                    Assert.fail(msg);
                    return null;
                }

                Locator element = findElementInFrame(locator);
                highlightElement(element);

                String tagName = element.evaluate("el => el.tagName.toLowerCase()").toString();
                String retrievedData;

                if ("input".equals(tagName) || "textarea".equals(tagName)) {
                    retrievedData = element.inputValue();
                } else {
                    retrievedData = element.innerText();
                    if (retrievedData == null || retrievedData.trim().isEmpty()) {
                        Object rawText = element.evaluate("el => el.textContent");
                        retrievedData = rawText != null ? rawText.toString().trim() : "";
                    }
                }

                if (retrievedData == null || retrievedData.isEmpty()) {
                    String msg = "Could not retrieve any text from element: " + locator;
                    LogUtils.error(msg);
                    Assert.fail(msg);
                    return null;
                }

                // Save in DB or variable store

                LogUtils.info("Retrieved '" + retrievedData + "' from element: " + locator +
                        " and stored in variable: '" + testdata + "'");

            // Check if input matches a decimal number pattern

                return retrievedData;   // <--- returning to logger
            } catch (Exception e) {
                String errorMessage = "Failed to retrieve text from element: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
                return null;
            }
        });
    }

    /**
     * Fixed pause. Avoid it: a fixed pause is too long on a fast day and too short on a slow one.
     * Wait for the thing you need instead (findElementInFrame, waitForPageToLoad, Locator.waitFor).
     *
     * @param millis milliseconds to pause
     * @deprecated kept only for code that still calls it
     */
    @Deprecated
    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // keep the stop request of the test runner
        }
    }

    /** After paging: waits until the first table row shows other content (or the time is up) instead of a fixed pause. */
    private void waitForTableChange(Locator rows, String before, long maxMillis) {
        long end = System.currentTimeMillis() + maxMillis;
        while (System.currentTimeMillis() < end) {
            try {
                if (rows.count() > 0) {
                    String now = rows.first().textContent();
                    if (now != null && !now.trim().equals(before)) {
                        return;
                    }
                }
            } catch (PlaywrightException redrawing) {
                // the table is being redrawn: look again
            }
            page().waitForTimeout(200);
        }
    }

    public void acceptAlert() {
        Page page = page();

        page.onceDialog(dialog -> {
            LogUtils.info("Accepting alert: " + dialog.message());
            dialog.accept();
        });
    }

    /**
     * Dismisses a JavaScript alert dialog.
     */
    public void dismissAlert() {
        Page page = page();

        page.onceDialog(dialog -> {
            LogUtils.info("Dismissing alert: " + dialog.message());
            dialog.dismiss();
        });
    }


    /**
     * Sends text to a prompt-type alert dialog.
     */
    public void setTextAlert(String text) {
        Page page = page();

        page.onceDialog(dialog -> {
            LogUtils.info("Sending text to alert: " + text);
            dialog.accept(text);
        });
    }

    /**
     * Verifies if an alert is present within timeout (simulated since Playwright doesn’t poll alerts).
     */
    public boolean verifyAlertPresent(int timeoutInSeconds) {
        Page page = page();
        final boolean[] isAlertPresent = {false};

        page.onceDialog(dialog -> {
            isAlertPresent[0] = true;
            dialog.dismiss(); // Prevent blocking
        });

        // wait until the alert shows up (or the time is up) instead of always waiting the full time
        try {
            page.waitForCondition(() -> isAlertPresent[0],
                    new Page.WaitForConditionOptions().setTimeout(timeoutInSeconds * 1000.0));
        } catch (PlaywrightException timedOut) {
            // no alert within the time: reported below
        }
        if (!isAlertPresent[0]) {
            LogUtils.error("Alert NOT Present.");
        }
        return isAlertPresent[0];
    }

    /**
     * Clicks on an element, with fallback to JavaScript click if native click fails.
     *
     * @param fieldName, value
     */
    public void validateField(String fieldName, String value) {
        logger.logAction("Validate field: " + fieldName, () -> {
            try {
                logFieldInput(fieldName, value);
                checkFieldNotNullOrEmpty(fieldName, value);
                LogUtils.info("Validation successful for field: " + fieldName);
            } catch (Exception e) {
                String errorMessage = "Validation failed for field: " + fieldName;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage + "\n--- Exception Trace ---\n" + e);
            }
        });
    }

    private static void logFieldInput(String fieldName, String value) {
        LogUtils.info("validating field: " + fieldName);
        LogUtils.info("Field value: " + (value == null ? "null" : value));
    }

    private static void checkFieldNotNullOrEmpty(String fieldName, String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + "is null or empty.");
        }
    }
//Added by Onkar
    public void verifyCheckBoxIsChecked(String locator) {
        logger.logAction("verify checkbox [" + locator + "] is checked",() -> {

            try{
                Locator checkbox = findElementInFrame(locator);
                highlightElement(checkbox);
                assertThat(checkbox).isChecked();
                LogUtils.info("Success : Checkbox[" + locator + "] is checked.");
                capturescreenshot();
            } catch (Exception e) {
                String errorMessage = "Verification failed: checkbox [" + locator + "] is NOT checked. " + e.getMessage();
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage);
            }
        });
    }

    /**
     * Selects all "Confirmed" checkboxes in the Overrides table (if present).
     * Highlights the table before returning (if no checkboxes) or after selection (if checkboxes found).
     * Gracefully logs "no overrides found" when no checkboxes are present (does not throw).
     */
    public void selectAllOverridesAndCapture(String tableLocator, String checkboxSelector) {
        String simplifiedTableLocator = simplifyLocator(tableLocator);
        String simplifiedcheckboxSelector = simplifyLocator(checkboxSelector);

        logger.logAction("Select all 'Confirmed' checkboxes in Overrides table (if present)", () -> {
            try {
                // Find the Overrides table (handle if not present)
                if (!isVisibleWithin(simplifiedTableLocator, OPTIONAL_ELEMENT_WAIT_MS)) {
                    LogUtils.info("Overrides table not found. No override messages displayed. Proceeding...");
                    return; // graceful exit
                }
                Locator tableElement = findElementInFrame(simplifiedTableLocator);

                // Get all checkboxes inside the table
                List<Locator> checkboxes = tableElement.locator(simplifiedcheckboxSelector).all();

                if (checkboxes == null || checkboxes.isEmpty()) {
                    // No checkboxes present → highlight table and log message
                    highlightElement(tableElement);
                    LogUtils.info("No override checkboxes found. Proceeding without any selection.");
                    return;
                }

                //  Select all unchecked checkboxes
                int selectedCount = 0;
                for (Locator checkbox : checkboxes) {
                    if (!checkbox.isChecked()) {
                        checkbox.check(new Locator.CheckOptions().setForce(true));
                        selectedCount++;
                    }
                }

                //  Highlight the table after selection (so screenshot captures selected state)
                highlightElement(tableElement);

                String msg = "Selected " + selectedCount + " override checkbox(es) successfully.";
                LogUtils.info(msg);

            } catch (Exception e) {
                String errorMessage = "Error while selecting override checkboxes: " + e.getMessage();
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                throw new RuntimeException(errorMessage, e);
            }
        });
    }

    public boolean verifyEnabledDisabled(String locator, String state, boolean soft) {
        String elementID = simplifyLocator(locator);

        return logger.logAction(
                "Verify element '" + ScreenshotContextHolder.getFieldName() + "' is '" + state + "'"
                        + "<br>Locator: " + elementID,
                () -> {
                    Locator element = null;
                    try {
                        element = findElementInFrame(locator);
                        highlightElement(element);

                        String normalizedState = state == null ? "" : state.trim().toLowerCase();

                        // Native + ARIA disabled support
                        boolean nativeDisabled = element.isDisabled();
                        boolean ariaDisabled = "true".equalsIgnoreCase(element.getAttribute("aria-disabled"));

                        // OPTIONAL: Treat readonly as "disabled" for input-type fields
                        // (Many apps consider readonly as non-editable, similar to disabled from test perspective)
                        boolean isReadOnly = Boolean.TRUE.equals(
                                element.evaluate("el => el.hasAttribute && el.hasAttribute('readonly')")
                        );

                        boolean actual;

                        switch (normalizedState) {
                            case "disabled":
                                // Consider disabled if native disabled OR aria-disabled OR readonly
                                actual = nativeDisabled || ariaDisabled || isReadOnly;
                                break;

                            case "enabled":
                                // Enabled means: isEnabled AND not aria-disabled AND not readonly AND not native disabled
                                actual = element.isEnabled() && !ariaDisabled && !isReadOnly && !nativeDisabled;
                                break;

                            default:
                                throw new IllegalArgumentException(
                                        "Invalid state: '" + state + "'. Allowed values: 'enabled' or 'disabled'."
                                );
                        }

                        if (actual) {
                            LogUtils.info("Verified: Element '" + locator + "' is '" + normalizedState + "'.");
                            return true;
                        } else {
                            String errorMessage = "Verification failed: Element '" + locator + "' is NOT '" + normalizedState + "'.";
                            LogUtils.error(errorMessage);
                            capturescreenshot();
                            if (!soft) {
                                Assert.fail(errorMessage);
                            }
                            return false;
                        }

                    } catch (Exception e) {
                        String errorMessage = "Unexpected error while verifying '" + state + "' for element: " + locator;
                        LogUtils.error(errorMessage, e);
                        capturescreenshot();
                        if (!soft) {
                            Assert.fail(errorMessage, e);
                        }
                        return false;
                    }
                }
        );
    }
    // --- PRIVATE INNER CLASS FOR NO-OP LOGGING ---

    /**
     * A private static inner class that provides a default, "do nothing" implementation
     * of the IActionLogger. It simply executes the action without any reporting.
     */
    private static class NoOpActionLogger implements IActionLogger {
        @Override
        public <T> T logAction(String description, Supplier<T> action) {
            // Simply execute the action and return its result.
            return action.get();
        }
    }

    public static int generateRandomFourDigitNumber(int min, int max) {
        Random rand = new Random();
        return rand.nextInt(max - min + 1) + min;
    }

    /**
     * Clicks on an element, with fallback to JavaScript click if native click fails.
     *
     * @param locator  CSS/XPath of the element
     * @param filePath CSS/XPath of the element
     */
    public void uploadFile(String locator, String filePath) {
        logger.logAction("Upload file to element: " + locator, () -> {
            Locator element;
            try {
                // a file box is usually hidden (a "Click to upload" area opens it): it only has to be in the page
                element = findElementInFrame(locator, false);
                if (element.isVisible()) {
                    highlightElement(element); // optional for debugging
                }

                java.nio.file.Path file = Paths.get(filePath).toAbsolutePath();
                if (!java.nio.file.Files.isRegularFile(file)) {
                    throw new IllegalArgumentException("The file to upload does not exist: " + file);
                }
                // no JavaScript fallback: setting the value attribute of a file box uploads nothing
                element.setInputFiles(file);
                LogUtils.info("Successfully uploaded file " + file + " to element: " + locator);

            } catch (Exception e) {
                String errorMessage = "Failed to upload file to element: " + locator;
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    /**
     * This method is used to adjust date as per dayoffset
     * eg: dayOffset=1 will add day and dayOffset=-1 will subtract day
     *
     * @param inputDate
     * @param dayOffset
     * @return
     */
    public static String adjustDate(String inputDate, int dayOffset, String dateFormat) {
        if (inputDate == null || inputDate.trim().isEmpty()) {
            throw new IllegalArgumentException("No date to adjust (the date read from the screen is empty).");
        }
        try {
            SimpleDateFormat outputFormat = new SimpleDateFormat(dateFormat);
            //Do not allow duplicate
            outputFormat.setLenient(false);
            //Parse the input date
            Date date = outputFormat.parse(inputDate);
            //Use Calendar to manipulate the date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            //Apply dayoffset to input date
            calendar.add(Calendar.DAY_OF_MONTH, dayOffset);
            return outputFormat.format(calendar.getTime());
        } catch (ParseException e) {
            throw new IllegalArgumentException("'" + inputDate + "' is not a date in the format " + dateFormat, e);
        }
    }
     public void sendKeysRandom(String locator, String testdata) {
        // ⭐ NEW: Handle random patterns exactly like normal sendKeys input
        String finalTestData = generateRandomIfNeeded(testdata);

        String elementID = simplifyLocator(locator);
        logger.logAction("Enter '" + shown(locator, finalTestData) + "' in '"
                        + ScreenshotContextHolder.getFieldName() + "' textbox. Locator: " + elementID, () -> {

        Locator element;
        try {
            element = findElementInFrame(locator);

            boolean isReadOnly = Boolean.TRUE.equals(element.evaluate("el => el.hasAttribute('readonly')"));

            if (!isReadOnly) {
                element.fill(finalTestData);
            } else {
                LogUtils.warn("Element is readonly, using JS fallback.");
                setValueWithEvents(element, finalTestData);
            }

            highlightElement(element);
            LogUtils.info("Successfully entered '" + shown(locator, finalTestData) + "' into element: " + locator);

        } catch (Exception e) {
            String errorMessage = "Failed to enter text '" + shown(locator, finalTestData) + "' into element: " + locator;
            LogUtils.error(errorMessage, e);
            capturescreenshot();
            Assert.fail(errorMessage, e);
        }
    });
}

    private String generateRandomIfNeeded(String value) {
        if (value == null) return "";

        String upper = value.trim().toUpperCase();

        if (upper.startsWith("RANDOM_STRING_")) {
            int len = Integer.parseInt(upper.replace("RANDOM_STRING_", ""));
            return randomString(len);
        }

        if (upper.startsWith("RANDOM_NUMBER_")) {
            int len = Integer.parseInt(upper.replace("RANDOM_NUMBER_", ""));
            return randomNumber(len);
        }

        if (upper.equals("RANDOM_EMAIL")) {
            return "user" + System.currentTimeMillis() + "@test.com";
        }

        if (upper.equals("RANDOM_UUID")) {
            return UUID.randomUUID().toString();
        }

        return value; // normal data
    }

    private String randomString(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++)
            sb.append(chars.charAt(r.nextInt(chars.length())));
        return sb.toString();
    }

    private String randomNumber(int length) {
        String digits = "0123456789";
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++)
            sb.append(digits.charAt(r.nextInt(digits.length())));
        return sb.toString();
    }

    // added by sadi 16 december for verifying the signature id from table
    /**
     * Pages through a table until an input holding {@code signatureId} is found. Fails the step when it is not found on any page
     * (it used to only return a "FAILED" text, which callers ignored). Errors while reading the table are not hidden.
     */
    public String verifyTableCell(String tableSelector, String nextButtonSelector, String signatureId) {
        return logger.logAction("Verify table contains SignatureId '" + signatureId + "'<br>Table: " + tableSelector + " | Next: " + nextButtonSelector, () -> {
            Locator table = findElementInFrame(tableSelector);
            Locator tableRows = table.locator("tbody tr");
            Locator nextBtn = findElementInFrame(nextButtonSelector);

            bestEffort("highlight the table", () -> {
                if (table.isVisible()) {
                    highlightElement(table);
                }
            });
            bestEffort("take a screenshot", this::capturescreenshot);

            final int maxPages = 200; // safety net: a Next button that never gets disabled
            int pageCount = 1;
            while (pageCount <= maxPages) {
                LogUtils.info("Page " + pageCount + " | Row count: " + tableRows.count());

                // the input that holds the Signature Id: <input type="text" id="BLK_CIFSIG_SIGID" name="SIGID" value="...">
                Locator sigInput = table.locator("input#BLK_CIFSIG_SIGID, input[name='SIGID']");
                int inputCount = sigInput.count();
                LogUtils.info("SignatureId input count: " + inputCount);

                for (int i = 0; i < inputCount; i++) {
                    Locator input = sigInput.nth(i);
                    String val = input.getAttribute("value");
                    if (val != null && val.trim().equalsIgnoreCase(signatureId.trim())) {
                        bestEffort("highlight the matching cell", () -> highlightElement(input));
                        bestEffort("take a screenshot", this::capturescreenshot);
                        String msg = "PASSED | SignatureId '" + signatureId + "' found on page " + pageCount;
                        LogUtils.info(msg);
                        return msg;
                    }
                }

                // no Next button, or a disabled one: this was the last page
                boolean nextVisible = nextBtn.isVisible();
                boolean nextDisabled = nextVisible && nextBtn.isDisabled();
                LogUtils.info("Next visibility=" + nextVisible + " disabled=" + nextDisabled);
                if (!nextVisible || nextDisabled) {
                    LogUtils.info("Next unavailable at page " + pageCount + ". Stopping traversal.");
                    break;
                }

                String before = firstRowText(tableRows);
                nextBtn.click();
                waitForTableChange(tableRows, before, 15000);
                if (before.equals(firstRowText(tableRows))) {
                    // clicking Next again would show the same page forever
                    LogUtils.warn("Table content unchanged after Next click on page " + pageCount + ". Stopping traversal.");
                    break;
                }
                pageCount++;
            }

            bestEffort("take a screenshot", this::capturescreenshot);
            String failMsg = "SignatureId '" + signatureId + "' not found after " + pageCount + " page(s).";
            LogUtils.error(failMsg);
            Assert.fail(failMsg);
            return failMsg;
        });
    }

    private static String firstRowText(Locator rows) {
        if (rows.count() == 0) {
            return "";
        }
        String t = rows.first().textContent();
        return t == null ? "" : t.trim();
    }

    /** Runs a cosmetic action (highlight, screenshot); a failure is logged as a warning and does not stop the step. */
    private static void bestEffort(String what, Runnable action) {
        try {
            action.run();
        } catch (RuntimeException e) {
            LogUtils.warn("Could not " + what + ": " + e.getMessage());
        }
    }

    // added by sadichchha

    /**
     * Sets the state of a checkbox, leveraging a custom helper method that finds
     * the element across all frames in a performant way for complex applications.
     *
     * @param locator The Playwright selector for the checkbox input element.
     */
    public void checkCustomerDefreezeStatus(String locator) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Frozen Checkbox " + ScreenshotContextHolder.getFieldName() + " ( "+ elementID + " )", () -> {
            Locator checkboxLocator;
            try {
                checkboxLocator = findElementInFrame(locator);
                highlightElement(checkboxLocator);
                assertThat(checkboxLocator).not().isChecked();
                LogUtils.info("SUCCESS: Customer is in defreeze state, Frozen Checkbox [" + locator + "] is not checked.");
            } catch (Exception e) {
                String errorMessage = "FAIL: Still customer is in Frozen  state , Frozen checkbox [" + locator + "] still checked" + ". Reason: " + e.getMessage();
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }

    // added by sadichchha

    /**
     * Sets the state of a checkbox, leveraging a custom helper method that finds
     * the element across all frames in a performant way for complex applications.
     *
     * @param locator The Playwright selector for the checkbox input element.
     */
    public void checkFrozenCheckboxStatus(String locator) {
        String elementID = simplifyLocator(locator);
        logger.logAction("Frozen Checkbox " + ScreenshotContextHolder.getFieldName() + " ( "+ elementID + " )", () -> {
            Locator checkboxLocator;
            try {
                checkboxLocator = findElementInFrame(locator);
                highlightElement(checkboxLocator);
                assertThat(checkboxLocator).isChecked();
                LogUtils.info("SUCCESS: Checkbox [" + locator + "] is checked.");
            } catch (Exception e) {
                String errorMessage = "FAIL: Frozen checkbox [" + locator + "]" + ". Reason: " + e.getMessage();
                LogUtils.error(errorMessage, e);
                capturescreenshot();
                Assert.fail(errorMessage, e);
            }
        });
    }


}

