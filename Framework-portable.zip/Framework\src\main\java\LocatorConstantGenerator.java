import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Map;

/**
 * Generates path-based locator constants from OR JSONs.
 *
 * Input  : src/resources/objectrepo/OR_<MODULE>.json
 * Output : src/main/java/com/mashreq/automation/tcoe/constants/<MODULE>.java
 *
 * Constant format:
 *   SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 *
 * Example:
 *   CASA.ACCOUNTOPENING_COMPOSITEMISCODE -> "CASA/AccountOpening/CompositeMISCode"
 */
public class LocatorConstantGenerator {

    private static final String OR_DIR  = "src/main/resources/objectrepo/Mobile";
    private static final String OUT_DIR = "src/main/java/com/mashreq/automation/tcoe/constants/";

    public static void main(String[] args) throws Exception {
        File orFolder = new File(OR_DIR);
        if (!orFolder.isDirectory()) {
            throw new IllegalStateException("OR directory not found: " + orFolder.getAbsolutePath());
        }

        File[] files = orFolder.listFiles((dir, name) -> name.startsWith("OR_") && name.endsWith(".json"));
        if (files == null || files.length == 0) {
            System.out.println("No OR_*.json files found in: " + orFolder.getAbsolutePath());
            return;
        }

        ObjectMapper mapper = new ObjectMapper();

        for (File orFile : files) {
            // Module = OR_<module>.json → uppercased
            String module = orFile.getName()
                    .substring(3, orFile.getName().length() - 5) // strip "OR_" and ".json"
                    .toUpperCase();

            // Expect: [ { "Screen": { "Field": { ... } } } ]
            JsonNode root = mapper.readTree(orFile);
            if (!root.isArray() || root.isEmpty()) {
                System.err.println("Skipping " + orFile.getName() + " (expected non-empty JSON array).");
                continue;
            }
            JsonNode screens = root.get(0);
            if (screens == null || !screens.isObject()) {
                System.err.println("Skipping " + orFile.getName() + " (first array element must be an object).");
                continue;
            }

            StringBuilder sb = new StringBuilder(16_384);
            sb.append("package com.mashreq.automation.tcoe.constants;\n\n");
            sb.append("/**\n")
                    .append(" * AUTO-GENERATED. Do not edit manually.\n")
                    .append(" * Source: ").append(orFile.getName()).append("\n")
                    .append(" * Format: SCREEN_FIELD = \"MODULE/SCREEN/FIELD\"\n")
                    .append(" */\n");
            sb.append("public final class ").append(module).append(" {\n\n");
            sb.append("    private ").append(module).append("() {}\n\n");

            // Iterate screens → fields
            Iterator<Map.Entry<String, JsonNode>> screenIt = screens.fields();
            while (screenIt.hasNext()) {
                Map.Entry<String, JsonNode> screenEntry = screenIt.next();
                String screenName = screenEntry.getKey();
                JsonNode fields = screenEntry.getValue();
                if (fields == null || !fields.isObject()) continue;

                sb.append("    // ===== ").append(screenName).append(" =====\n");
                Iterator<Map.Entry<String, JsonNode>> fieldIt = fields.fields();
                while (fieldIt.hasNext()) {
                    Map.Entry<String, JsonNode> fieldEntry = fieldIt.next();
                    String fieldName = fieldEntry.getKey();

                    // SCREEN_FIELD → upper snake; value → MODULE/Screen/Field
                    String constName = toConst(screenName) + "_" + toConst(fieldName);
                    String pathValue = module + "/" + screenName + "/" + fieldName;

                    sb.append("    public static final String ")
                            .append(constName)
                            .append(" = ")
                            .append("\"").append(pathValue).append("\";\n");
                }
                sb.append("\n");
            }

            sb.append("}\n");

            // Write file
            File outDir = new File(OUT_DIR);
            if (!outDir.exists() && !outDir.mkdirs()) {
                throw new IllegalStateException("Failed to create output dir: " + outDir.getAbsolutePath());
            }
            File outFile = new File(outDir, module + ".java");
            try (FileWriter fw = new FileWriter(outFile, StandardCharsets.UTF_8)) {
                fw.write(sb.toString());
            }

            System.out.println("✔ Generated " + outFile.getPath());
        }
    }

    /** "AccountOpening" → "ACCOUNTOPENING"; "Composite MIS Code" → "COMPOSITE_MIS_CODE" */
    private static String toConst(String raw) {
        String s = raw.replaceAll("[^A-Za-z0-9]+", "_"); // non-alnum → _
        s = s.replaceAll("_+", "_");                     // collapse __
        s = trimUnderscore(s).toUpperCase();             // trim edges + upper
        return s.isEmpty() ? "_" : s;
    }

    private static String trimUnderscore(String s) {
        int i = 0, j = s.length();
        while (i < j && s.charAt(i) == '_') i++;
        while (j > i && s.charAt(j - 1) == '_') j--;
        return s.substring(i, j);
    }
}
