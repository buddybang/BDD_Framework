<#-- Robust percentage function: coerce nulls to 0 and handle total==0 -->
<#function percentage val total>
    <#-- coerce nulls to 0 (val!0 and total!0) -->
    <#assign v = (val!0) />
    <#assign t = (total!0) />
    <#-- use ?is_number to test numericness, and ensure t > 0 -->
    <#if (t?is_number) && (t gt 0)>
        <#return ( (v / t * 100) )?string("0.00")>
    <#else>
        <#return "0.00">
    </#if>
</#function>

<#-- Pre-calculate summary stats and give safe defaults for every field we reference -->
<#assign summary = feature.summary!{}>

<#-- Scenario-level counts (use provided values when present; otherwise default/derive) -->
<#assign totalScenarios = (summary.totalScenarios!0) />
<#assign passedScenarios = (summary.passedScenarios!0) />
<#assign failedScenarios = (summary.failedScenarios!0) />
<#-- prefer an explicit skippedScenarios if present, otherwise derive it safely -->
<#assign skippedScenarios = (summary.skippedScenarios! ( totalScenarios - passedScenarios - failedScenarios ) ) />

<#-- Step-level counts (explicit defaults) -->
<#assign totalSteps = (summary.totalSteps!0) />
<#assign passedSteps = (summary.passedSteps!0) />
<#assign failedSteps = (summary.failedSteps!0) />
<#assign skippedSteps = (summary.skippedSteps! ( totalSteps - passedSteps - failedSteps ) ) />
<#assign pendingSteps = (summary.pendingSteps!0) />
<#assign ambiguousSteps = (summary.ambiguousSteps!0) />
<#assign undefinedSteps = (summary.undefinedSteps!0) />

<#-- Now compute percentages using our safe variables -->
<#assign passedScenarioPercent = percentage(passedScenarios, totalScenarios) >
<#assign failedScenarioPercent = percentage(failedScenarios, totalScenarios) >
<#assign skippedScenarioPercent = percentage(skippedScenarios, totalScenarios) >

<#assign passedStepPercent = percentage(passedSteps, totalSteps) >
<#assign failedStepPercent = percentage(failedSteps, totalSteps) >
<#assign skippedStepPercent = percentage(skippedSteps, totalSteps) >
<#assign pendingStepPercent = percentage(pendingSteps, totalSteps) >
<#assign ambiguousStepPercent = percentage(ambiguousSteps, totalSteps) >
<#assign undefinedStepPercent = percentage(undefinedSteps, totalSteps) >

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <title>BDD Feature Report: ${feature.featureName}</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>
            /* --- existing styles preserved --- */
            * { margin: 0; padding: 0; box-sizing: border-box; }
            :root {
                --bg-page: #f4f6f8; --bg-card: #ffffff; --bg-top-bar: #eef1f4;
                --border-color: #e9ecef; --text-primary: #212529; --text-secondary: #6c757d;
                --text-link: #495057; --color-success: #28a745; --color-danger: #dc3545;
                --color-skipped: #17a2b8;
                --color-pending: #ffc107; /* Yellow */
                --color-ambiguous: #dc3545; /* Red */
                --color-undefined: #fd7e14; /* Orange */
            }
            body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: var(--bg-page); color: var(--text-primary); }
            .icon { fill: currentColor; width: 1.5em; height: 1.5em; }
            .feature-header { margin-bottom: 1.5rem; }
            .feature-header h1 { font-size: 1.2rem; font-weight: 400; color: var(--text-primary); margin-bottom: 0.75rem; }
            .feature-header h1 strong { font-weight: 600; color: var(--text-secondary); }
            .main-sections { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
            .section { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; flex-direction: column; }
            .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; flex-shrink: 0; }
            .section-title { font-size: 16px; color: #666; font-weight: 500; }
            .chart-container { display: flex; align-items: center; gap: 20px; flex: 1; }
            .chart-wrapper { position: relative; width: 140px; height: 140px; margin-left: 15px; }
            .chart-center { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; font-size: 24px; font-weight: bold; color: #333; }
            .legend { flex: 1; }
            .legend-item { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 13px; }
            .legend-label { display: flex; align-items: center; gap: 8px; }
            .legend-color { width: 12px; height: 12px; border-radius: 50%; }
            .legend-text { color: #666; }
            .legend-value { color: #333; font-weight: 500; }
            .run-info-container { flex-grow: 1; overflow-y: auto; padding-right: 10px; scrollbar-width: thin; scrollbar-color: #d1d5db #f9fafb; max-height: 132px; }
            .run-info-container::-webkit-scrollbar { width: 6px; }
            .run-info-container::-webkit-scrollbar-track { background: #f9fafb; border-radius: 10px; }
            .run-info-container::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }
            .run-info-container::-webkit-scrollbar-thumb:hover { background: #9ca3af; }
            .run-info-table { width: 100%; }
            .info-item { display: flex; justify-content: space-between; font-size: 13px; padding: 8px 0; border-bottom: 1px solid #f1f3f4; }
            .info-item:last-child { border-bottom: none; }
            .info-label { color: var(--text-secondary); font-weight: 400; }
            .info-value { color: #333; font-weight: 500; text-align: right; }
            .passed-color { background: var(--color-success); }
            .failed-color { background: var(--color-danger); }
            .skipped-color { background: var(--color-skipped); }
             /* --- NEW LEGEND COLORS --- */
            .pending-color { background: var(--color-pending); }
            .ambiguous-color { background: var(--color-ambiguous); }
            .undefined-color { background: var(--color-undefined); }
            .container { width: 90%; max-width: 1600px; margin: 0 auto; padding: 1.5rem 1rem; }
            .report-layout { display: flex; gap: 1.5rem; align-items: stretch; }
            .sidebar { flex: 0 0 35%; background: white; border-radius: 0.5rem; padding: 1rem; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04); display: flex; flex-direction: column; height: 80vh; }
            .sidebar-header { padding-bottom: 0.75rem; margin-bottom: 0.75rem; border-bottom: 1px solid var(--border-color); flex-shrink: 0; }
            .sidebar-title { font-size: 1.125rem; font-weight: 600; color: var(--text-primary); }
            .sidebar-controls { display: flex; gap: 0.5rem; margin-bottom: 1rem; align-items: center; flex-shrink: 0; }
            .search-wrapper { position: relative; flex-grow: 1; }
            .search-wrapper .icon { position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); width: 1rem; height: 1rem; color: var(--text-secondary); }
            #scenario-search { width: 100%; padding: 0.5rem 0.75rem 0.5rem 2.25rem; border-radius: 0.375rem; border: 1px solid #d1d5db; font-size: 0.875rem; }
            #scenario-search:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2); }
            .filter-container { position: relative; }
            .filter-button { background: none; border: 1px solid #d1d5db; border-radius: 0.375rem; padding: 0.5rem; cursor: pointer; display: flex; align-items: center; justify-content: center; }
            .filter-button .icon { width: 1rem; height: 1rem; color: var(--text-secondary); }
            .filter-dropdown { position: absolute; top: calc(100% + 5px); right: 0; background-color: white; border: 1px solid #d1d5db; border-radius: 0.375rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); z-index: 20; width: 150px; padding: 0.5rem; }
            .filter-option { display: flex; align-items: center; padding: 0.5rem; cursor: pointer; border-radius: 0.25rem; font-size: 0.875rem; }
            .filter-option:hover { background-color: #f3f4f6; }
            .filter-option input { margin-right: 0.75rem; width: 1em; height: 1em; }
            .sidebar-scenarios { overflow-y: auto; flex-grow: 1; }
            .scenario-link { display: flex; align-items: center; padding: 0.75rem; border-radius: 0.375rem; font-size: 0.9rem; text-decoration: none; color: #374151; margin-bottom: 0.5rem; border: 2px solid #e5e7eb; transition: background-color 0.2s, border-color 0.2s; cursor: pointer; }
            .scenario-link:hover { background-color: #f9fafb; border-color: #d1d5db; }
            .scenario-link.active { background-color: #eff6ff; border-color: #2563eb; color: #1e40af; font-weight: 600; }
            .scenario-link .status-icon { display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; margin-right: 0.75rem; flex-shrink: 0; }
            .scenario-link .status-icon.passed { color: var(--color-success); }
            .scenario-link .status-icon.failed { color: var(--color-danger); }
            .scenario-link .status-icon.skipped { color: var(--color-skipped); }
            .scenario-link-text { flex-grow: 1; min-width: 0; }
            .scenario-link-header { font-weight: 500; white-space: nowrap; }
            .scenario-link-desc { font-size: 0.85em; color: var(--text-secondary); margin-top: 2px; white-space: normal; }
            .main-content { flex: 1; display: flex; flex-direction: column; min-width: 0; }
            .scenario-placeholder { display: flex; align-items: center; justify-content: center; background: white; border-radius: 0.5rem; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04); flex-grow: 1; height: 80vh; color: var(--text-secondary); font-size: 1.1rem; text-align: center; padding: 2rem; }
            .scenario { background: white; border-radius: 0.5rem; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04); border: 1px solid var(--border-color); overflow: hidden; display: flex; flex-direction: column; flex-grow: 1; height: 80vh; }
            .scenario-header { padding: 1rem 1.5rem; flex-shrink: 0; }
            .scenario-info { flex-grow: 1; min-width: 0; }
            .scenario-header-top { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.25rem; }
            .scenario-tags { font-size: 0.675rem; color: #6b7280; }
            .scenario-title { line-height: 1.4; color: #222; font-size: 0.9rem; font-weight: normal; margin-top: 0.25rem; word-break: break-word; }
            .scenario-title strong { color: #000080; font-size: 1em; font-weight: bold; margin-right: 0.5em; }
            .scenario-meta { display: flex; align-items: center; gap: 0.75rem; flex-shrink: 0; }
            .duration-text { font-size: 0.75rem; color: #6b7280; }
            .status-badge { display: inline-flex; align-items: center; justify-content: center; width: 1.65rem; height: 1.65rem; border-radius: 50%; color: white; font-size: 0.675rem; font-weight: bold; }
            .status-badge.passed { background-color: var(--color-success); }
            .status-badge.failed { background-color: var(--color-danger); }
            .status-badge.skipped { background-color: var(--color-skipped); }
            .status-badge.pending { background-color: var(--color-pending); }
            .status-badge.ambiguous { background-color: var(--color-ambiguous); }
            .status-badge.undefined { background-color: var(--color-undefined); }
            .scenario-meta .status-badge[onclick] { cursor: pointer; transition: transform 0.2s; }
            .scenario-meta .status-badge[onclick]:hover { transform: scale(1.1); }
            @keyframes highlight-step {
                0% { background-color: rgba(255, 255, 0, 0); }
                50% { background-color: rgba(255, 255, 0, 0.4); }
                100% { background-color: rgba(255, 255, 0, 0); }
            }
            .step.step-highlighted { animation: highlight-step 2s ease-in-out; }
            .scenario-body { border-top: 1px solid var(--border-color); padding: 0; overflow-y: auto; flex-grow: 1; }
            .tabs-nav { display: flex; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; background: white; z-index: 10; padding: 0 1.5rem; }
            .tab-link { font-size: 1rem; font-weight: 500; color: #6b7280; text-decoration: none; padding: 0.6rem 0.25rem; margin-right: 1.5rem; margin-bottom: -1px; border-bottom: 2px solid transparent; cursor: pointer; transition: color 0.2s, border-color 0.2s; }
            .tab-link:hover { color: #111827; }
            .tab-link.active { color: #2563eb; border-bottom-color: #2563eb; }
            .tab-content { padding: 1rem; }
            .step { margin-bottom: 0.5rem; }
            .step-header { display: flex; align-items: center; padding: 0.55rem; background: white; border: 1px solid var(--border-color); border-radius: 0.5rem; width: 100%; text-align: left; }
            .step-header.is-expandable { cursor: pointer; transition: background-color 0.2s; }
            .step-header.is-expandable:hover { background-color: #f9fafb; }
            .step-header.is-expanded { border-bottom-left-radius: 0; border-bottom-right-radius: 0; }
            .step-chevron { width: 1rem; height: 1rem; margin-right: 0.75rem; transition: transform 0.3s ease; flex-shrink: 0; transform: rotate(0deg); }
            .step-header.is-expanded .step-chevron { transform: rotate(90deg); }
            .step-status { display: flex; align-items: center; justify-content: center; width: 1.25rem; height: 1.25rem; margin-right: 0.75rem; flex-shrink: 0; }
            .step-status.status-passed { color: var(--color-success); }
            .step-status.status-failed { color: var(--color-danger); }
            .step-status.status-skipped { color: var(--color-skipped); }
            .step-status.status-pending { color: var(--color-pending); }
            .step-status.status-ambiguous { color: var(--color-ambiguous); }
            .step-status.status-undefined { color: var(--color-undefined); }
            .step-title { font-size: 1em; color: #222; font-weight: normal; flex: 1; word-break: break-word; }
            .step-title strong { font-weight: bold; color: #000080; margin-right: 0.5em; }
            .step-argument { color: #297bde; }
            .step-duration { font-size: 0.675rem; color: #6b7280; background-color: #f3f4f6; padding: 0.2rem 0.5rem; border-radius: 0.25rem; flex-shrink: 0; margin-left: 5px; }
            .step-data-scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; margin-top: 12px; margin-left: 3.25rem; border: 1px solid #e5e7eb; border-radius: 6px; background: #fff; padding: 8px; }
            .step-data-table { display:inline-table; border-collapse:collapse; font-size:0.875rem; width:auto; box-shadow:0 1px 2px rgba(0,0,0,0.05); }
            .step-data-table th, .step-data-table td { border: 1px solid #e5e7eb; padding: 8px 12px; text-align: left; vertical-align: middle; white-space: nowrap; }
            .step-data-table th { background-color: #f9fafb; font-weight: 600; color: #374151; }
            .step-data-table .status-cell { text-align: center; width: 48px; padding: 8px; white-space: nowrap; }
            .status-cell.status-passed { color: var(--color-success); }
            .status-cell.status-failed { color: var(--color-danger); }
            .status-cell.status-skipped { color: var(--color-skipped); }
            .action-result pre, .error-details pre { white-space: pre-wrap; word-break: normal; }
            .status-cell .icon { width: 1.25em; height: 1.25em; }
            .step-actions { background-color: #f9fafb; border: 1px solid var(--border-color); border-top: none; padding: 0.75rem; padding-left: 3.25rem; border-bottom-left-radius: 0.5rem; border-bottom-right-radius: 0.5rem; }
            .action { position: relative; padding: 0.75rem 1rem 0.75rem 1.5rem; border-radius: 6px; margin-bottom: 0.5rem; overflow: hidden; }
            .action::before { content: ""; position: absolute; left: 0; top: 0; height: 100%; width: 5px; }
            .action.status-passed { background-color: #e6f7f0; }
            .action.status-passed::before { background-color: #34d399; }
            .action.status-failed { background-color: #fee2e2; }
            .action.status-failed::before { background-color: #ef4444; }
            .action-description { display: block; font-family: consolas;font-size: 0.875rem; font-weight: 500; color: #1f2937; word-break: break-all; }
            .action-description .locator-text { font-size: 0.75rem; color: #6b7280; font-weight: 400;  }
            .action-link { display: inline-block; font-size: 0.875rem; color: #2563eb; text-decoration: underline; cursor: pointer; border: none; background: none; padding: 0; margin-top: 0.25rem; margin-right: 1rem; }
            .action-link:hover { color: #1d4ed8; }
            .error-details { margin-top: 0.75rem; background-color: #f3f4f6; padding: 0.75rem; border-radius: 0.375rem; border: 1px solid #e5e7eb; }
            .error-details pre { white-space: pre-wrap; word-wrap: break-word; font-family: monospace; font-size: 0.875rem; color: #374151; }
            #logs-container video { max-width: 500px; width: 100%; height: 300px; border-radius: 0.5rem; border: 1px solid #e5e7eb; margin-top: 1rem; }
            .sidebar-scenarios, .scenario-body, .run-info-container { scrollbar-width: thin; scrollbar-color: #d1d5db #f3f4f6; }
            .sidebar-scenarios::-webkit-scrollbar, .scenario-body::-webkit-scrollbar, .run-info-container::-webkit-scrollbar { width: 8px; }
            .sidebar-scenarios::-webkit-scrollbar-track, .scenario-body::-webkit-scrollbar-track, .run-info-container::-webkit-scrollbar-track { background: #f3f4f6; border-radius: 10px; }
            .sidebar-scenarios::-webkit-scrollbar-thumb, .scenario-body::-webkit-scrollbar-thumb, .run-info-container::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }
            .sidebar-scenarios::-webkit-scrollbar-thumb:hover, .scenario-body::-webkit-scrollbar-thumb:hover, .run-info-container::-webkit-scrollbar-thumb:hover { background: #9ca3af; }
            .overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background-color: rgba(0, 0, 0, 0.75); display: flex; align-items: center; justify-content: center; z-index: 50; padding: 1rem; }
            .overlay img { max-width: 95%; max-height: 95%; object-fit: contain; border-radius: 0.5rem; }
            .footer { margin-top: 1.5rem; text-align: center; color: #6b7280; font-size: 0.875rem; }
            .hidden { display: none; }
            /* Screenshot Styles */

            .step-screenshot-container {
                margin-top: 12px;
                margin-bottom: 12px;
            }

            .step-screenshot {
                max-width: 450px;
                width: 100%;
                border: 1px solid #dcdcdc;
                border-radius: 8px;
                cursor: pointer;
                transition: transform 0.2s ease;
                background: #ffffff;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }

            .step-screenshot:hover {
                transform: scale(1.02);
            }

            .action img {
                display: block;
            }
            .history-table { width: 100%; border-collapse: collapse; font-size: 0.75rem; margin-top: 0.5rem; }
            .history-table th, .history-table td { border: 1px solid #e6e9ec; padding: 10px 12px; text-align: left; vertical-align: middle; }
            .history-table th { background: #f9fafb; color: #374151; font-weight: 600; }
            .history-status { display: inline-block; padding: 3px 8px; font-size: 11px; font-weight: bold; border-radius: 4px; text-transform: uppercase; border: 1px solid transparent; min-width: 65px; }
            .history-status.passed { background-color: #e9f7ec; color: #28a745; border-color: #a3d9b1; }
            .history-status.failed { background-color: #fceeee; color: #dc3545; border-color: #f3c6cb; }
            .history-status.skipped { background-color: #e8f6f8; color: #17a2b8; border-color: #b3e6ed; }
            .history-build {  color: #111827; }
            .history-empty { color:#6b7280; padding: 12px 0; }
        </style>
    </head>
    <body>

        <div class="container">

            <header class="feature-header">
                <h1><strong>Feature:</strong> ${feature.featureName}</h1>
            </header>

            <div class="main-sections">
                <!-- Scenarios Section -->
                <div class="section">
                    <div class="section-header"> <h2 class="section-title">Scenarios</h2> </div>
                    <div class="chart-container">
                        <div class="chart-wrapper">
                            <canvas id="scenariosChart"></canvas>
                            <div class="chart-center">${summary.totalScenarios}</div>
                        </div>
                        <div class="legend">
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color passed-color"></div><span class="legend-text">Passed</span></div>
                                <span class="legend-value">${summary.passedScenarios} [${passedScenarioPercent}%]</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color failed-color"></div><span class="legend-text">Failed</span></div>
                                <span class="legend-value">${summary.failedScenarios} [${failedScenarioPercent}%]</span>
                            </div>
                            <#if skippedScenarios gt 0>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color skipped-color"></div><span class="legend-text">Skipped</span></div>
                                <span class="legend-value">${skippedScenarios} [${skippedScenarioPercent}%]</span>
                            </div>
                            </#if>
                        </div>
                    </div>
                </div>

                <!-- Steps Section -->
                <div class="section">
                    <div class="section-header"> <h2 class="section-title">Steps</h2> </div>
                    <div class="chart-container">
                        <div class="chart-wrapper">
                            <canvas id="stepsChart"></canvas>
                            <div class="chart-center">${summary.totalSteps}</div>
                        </div>
                        <div class="legend">
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color passed-color"></div><span class="legend-text">Passed</span></div>
                                <span class="legend-value">${summary.passedSteps} [${passedStepPercent}%]</span>
                            </div>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color failed-color"></div><span class="legend-text">Failed</span></div>
                                <span class="legend-value">${summary.failedSteps} [${failedStepPercent}%]</span>
                            </div>
                            <#if ambiguousSteps gt 0>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color ambiguous-color"></div><span class="legend-text">Ambiguous</span></div>
                                <span class="legend-value">${ambiguousSteps} [${ambiguousStepPercent}%]</span>
                            </div>
                            </#if>
                            <#if undefinedSteps gt 0>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color undefined-color"></div><span class="legend-text">Not Defined</span></div>
                                <span class="legend-value">${undefinedSteps} [${undefinedStepPercent}%]</span>
                            </div>
                            </#if>
                            <#if pendingSteps gt 0>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color pending-color"></div><span class="legend-text">Pending</span></div>
                                <span class="legend-value">${pendingSteps} [${pendingStepPercent}%]</span>
                            </div>
                            </#if>
                            <div class="legend-item">
                                <div class="legend-label"><div class="legend-color skipped-color"></div><span class="legend-text">Skipped</span></div>
                                <span class="legend-value">${skippedSteps} [${skippedStepPercent}%]</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Run Info Section -->
                <div class="section">
                    <div class="section-header"> <h2 class="section-title">Run info</h2> </div>
                    <div class="run-info-container">
                        <div class="run-info-table">
                            <#list runInfo?keys as key>
                                <div class="info-item">
                                    <span class="info-label">${key?cap_first}</span>
                                    <span class="info-value">${runInfo[key]!""}</span>
                                </div>
                            </#list>
                        </div>
                    </div>
                </div>
            </div>

            <div class="report-layout">
                <aside class="sidebar">
                    <div class="sidebar-header"> <h2 class="sidebar-title">Scenarios</h2> </div>
                    <div class="sidebar-controls">
                        <div class="search-wrapper">
                            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z" clip-rule="evenodd"></path></svg>
                            <input type="search" id="scenario-search" placeholder="Search scenarios...">
                        </div>
                        <div class="filter-container">
                            <button id="filter-button" class="filter-button">
                                 <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M2.628 1.601C5.028 1.206 7.49 1 10 1s4.973.206 7.372.601a.75.75 0 01.628.74v2.288a2.25 2.25 0 01-.659 1.59l-4.682 4.683a2.25 2.25 0 00-.659 1.59v3.037c0 .684-.31 1.33-.844 1.757l-1.937 1.55A.75.75 0 018 18.25v-5.757a2.25 2.25 0 00-.659-1.59L2.659 6.22A2.25 2.25 0 012 4.629V2.34a.75.75 0 01.628-.74z"></path></svg>
                            </button>
                            <div id="filter-dropdown" class="filter-dropdown hidden">
                                <label class="filter-option"> <input type="checkbox" value="passed" checked> Passed </label>
                                <label class="filter-option"> <input type="checkbox" value="failed" checked> Failed </label>
                                <label class="filter-option"> <input type="checkbox" value="skipped" checked> Skipped </label>
                            </div>
                        </div>
                    </div>
                    <div class="sidebar-scenarios">
                        <#-- Loop through scenarios from the feature JSON -->
                        <#list feature.scenarios as scenario>
                            <#assign status = scenario.status?lower_case>
                            <#-- compute safe filename parts and pass both fileKey and UUID to JS -->
                            <#assign modulePart = (scenario.moduleName! "unknownModule")?replace('[^A-Za-z0-9-_]','_')>
                            <#assign scenarioIdPart = (scenario.scenarioId! "unknownScenario")?replace('[^A-Za-z0-9-_]','_')>
                            <#assign fileKey = modulePart + "_" + scenarioIdPart + "_" + (scenario.scenarioUUID! "no-uuid")>

                            <a class="scenario-link" data-status="${status}"
                               onclick="loadScenarioDetails('${fileKey}', '${scenario.scenarioUUID}', this)">

                                <div class="status-icon ${status}">
                                    <#if status == "passed"><svg class="icon" viewBox="0 0 18 18" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>
                                    <#elseif status == "failed"><svg class="icon" viewBox="0 0 18 18" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" /></svg>
                                    <#else><svg class="icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-1.125-9.125a.75.75 0 111.06-1.06l3.5 3.5a.75.75 0 010 1.06l-3.5 3.5a.75.75 0 01-1.06-1.06l2.22-2.22H7.75a.75.75 0 010-1.5h3.345L8.875 7.875z" clip-rule="evenodd"></path></svg></#if>
                                </div>
                                <#assign parts = scenario.scenarioName?split('|')>
                                <div class="scenario-link-text">
                                    <#if parts?size gte 3>
                                        <div class="scenario-link-header">${parts[0]?trim} : ${parts[1]?trim}</div>
                                        <div class="scenario-link-desc">${parts[2]?trim}</div>
                                    <#else>
                                        <div class="scenario-link-header">${scenario.scenarioName}</div>
                                    </#if>
                                </div>
                            </a>
                        </#list>
                    </div>
                </aside>
                <main class="main-content">
                    <div id="scenario-placeholder" class="scenario-placeholder">
                        <span>Select a scenario from the left to show details.</span>
                    </div>
                </main>
            </div>

            <footer class="footer">
                <p>Generated on <span id="current-date"></span></p>
            </footer>
        </div>

        <div id="screenshot-overlay" class="overlay hidden" onclick="hideScreenshot()">
            <img id="screenshot-image" src="" alt="Screenshot">
        </div>

        <script src="json/featureHistories.js"></script>

        <#noparse>
        <script>
            window.__currentFeatureUUID = "${feature.featureUUID}";
            document.getElementById('current-date').textContent = new Date().toLocaleString('en-US', { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: true });

            const mainContentContainer = document.querySelector('.main-content');
            const statusIcons = {
                passed: '<svg class="icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>',
                failed: '<svg class="icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" /></svg>',
                skipped: '<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm9.408-5.5a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2h-.01ZM10 10a1 1 0 1 0 0 2h1v3h-1a1 1 0 1 0 0 2h4a1 1 0 1 0 0-2h-1v-4a1 1 0 0 0-1-1h-2Z" clip-rule="evenodd"/></path></svg>',
                pending: '<svg class="icon" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM5 9a1 1 0 000 2h10a1 1 0 100-2H5z" clip-rule="evenodd" /></svg>',
                ambiguous: '<svg class="icon" viewBox="0 0 20 20" fill="currentColor"><path d="M11.983 1.904a.75.75 0 00-1.292-.782L3 10.25a.75.75 0 00.645.75h4.605l-2.853 6.85a.75.75 0 001.292.782L17 9.75a.75.75 0 00-.645-.75h-4.605l2.853-6.85z" /></svg>',
                undefined: '<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><path fill-rule="evenodd" d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm9.008-3.018a1.502 1.502 0 0 1 2.522 1.159v.024a1.44 1.44 0 0 1-1.493 1.418 1 1 0 0 0-1.037.999V14a1 1 0 1 0 2 0v-.539a3.44 3.44 0 0 0 2.529-3.256 3.502 3.502 0 0 0-7-.255 1 1 0 0 0 2 .076c.014-.398.187-.774.48-1.044Zm.982 7.026a1 1 0 1 0 0 2H12a1 1 0 1 0 0-2h-.01Z" clip-rule="evenodd"/></path></svg>'
            };

            function jumpToFirstStepOfStatus(status) {
                const selector = `.step[data-status="${status}"]`;
                const targetStep = document.querySelector(selector);
                if (!targetStep) return;
                targetStep.scrollIntoView({ behavior: 'smooth', block: 'start' });
                const header = targetStep.querySelector('.step-header');
                const actions = targetStep.querySelector('.step-actions');
                if (header && actions && header.classList.contains('is-expandable') && !header.classList.contains('is-expanded')) {
                    header.classList.add('is-expanded');
                    actions.classList.remove('hidden');
                }
                targetStep.classList.add('step-highlighted');
                setTimeout(() => targetStep.classList.remove('step-highlighted'), 2000);
            }

            function initializeStepAccordion() {
                const scenarioBody = mainContentContainer.querySelector('.scenario-body');
                if (!scenarioBody) return;
                const allStepHeaders = scenarioBody.querySelectorAll('.step-header.is-expandable');
                allStepHeaders.forEach(header => {
                    header.addEventListener('click', () => {
                        const currentStep = header.closest('.step');
                        const wasExpanded = header.classList.contains('is-expanded');
                        allStepHeaders.forEach(otherHeader => {
                            if (otherHeader !== header) {
                                otherHeader.classList.remove('is-expanded');
                                const otherActions = otherHeader.parentElement.querySelector('.step-actions');
                                if (otherActions) otherActions.classList.add('hidden');
                            }
                        });
                        const stepActions = currentStep.querySelector('.step-actions');
                        if (!wasExpanded) {
                            header.classList.add('is-expanded');
                            if (stepActions) stepActions.classList.remove('hidden');
                            setTimeout(() => {
                                const tabsNav = header.closest('.scenario').querySelector('.tabs-nav');
                                const tabsNavHeight = tabsNav ? tabsNav.offsetHeight : 0;
                                const headerTop = header.getBoundingClientRect().top;
                                const scenarioBodyTop = scenarioBody.getBoundingClientRect().top;
                                const scrollOffset = headerTop - scenarioBodyTop - tabsNavHeight - 10;
                                scenarioBody.scrollBy({ top: scrollOffset, behavior: 'smooth' });
                            }, 100);
                        } else {
                            header.classList.remove('is-expanded');
                            if (stepActions) stepActions.classList.add('hidden');
                        }
                    });
                });
            }

            function showTab(tabId, clickedTab) {
                const wrapper = clickedTab.closest('.scenario');
                wrapper.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
                wrapper.querySelectorAll('.tab-link').forEach(link => link.classList.remove('active'));
                const tabContainer = wrapper.querySelector('#' + tabId + '-container');
                if(tabContainer) tabContainer.classList.remove('hidden');
                clickedTab.classList.add('active');
            }

            function loadScenarioData(data) {
                mainContentContainer.innerHTML = buildScenarioHtml(data);
                initializeStepAccordion();
            }

            function formatRunDate(isoOrStr, runDateMillis) {
                try {
                    if (typeof runDateMillis === 'number') { return new Date(runDateMillis).toLocaleString(); }
                    if (!isoOrStr) return '';
                    const parsed = Date.parse(isoOrStr);
                    if (!isNaN(parsed)) return new Date(parsed).toLocaleString();
                    return isoOrStr;
                } catch (e) { return isoOrStr || ''; }
            }

            function formatDurationHuman(ms) {
                if (ms === null || ms === undefined) return '';
                const totalMs = Number(ms);
                if (isNaN(totalMs)) return '';
                const seconds = Math.floor(totalMs / 1000);
                const remMs = totalMs % 1000;
                const mins = Math.floor(seconds / 60);
                const secs = seconds % 60;
                return `${mins}m ${secs}s ${remMs}ms`;
            }


            function buildHistoryHtml(historyArray) {
                if (!historyArray || historyArray.length === 0) {
                    return '<div class="history-empty">No history available for this scenario.</div>';
                }
                const cloned = historyArray.slice();
                cloned.sort((a, b) => {
                    const aMillis = (a && typeof a.runDateMillis === 'number') ? a.runDateMillis : null;
                    const bMillis = (b && typeof b.runDateMillis === 'number') ? b.runDateMillis : null;
                    if (aMillis !== null && bMillis !== null) return bMillis - aMillis;
                    if (aMillis !== null) return -1;
                    if (bMillis !== null) return 1;
                    const aKey = (a && a.buildNumber) ? a.buildNumber : '';
                    const bKey = (b && b.buildNumber) ? b.buildNumber : '';
                    return bKey.localeCompare(aKey);
                });
                let html = '<table class="history-table"><thead><tr><th style="width:35%;">Build</th><th style="width:30%;">Run date</th><th style="width:15%;">Status</th><th style="width:20%;">Duration</th></tr></thead><tbody>';
                cloned.forEach((h, idx) => {
                    const build = h && h.buildNumber ? h.buildNumber : ('Run ' + (idx + 1));
                    const status = (h && h.status ? h.status : 'UNKNOWN').toLowerCase();
                    const statusClass = (status === 'passed' ? 'passed' : (status === 'failed' ? 'failed' : 'skipped'));
                    const runDate = formatRunDate(h && h.runDate ? h.runDate : null, h && h.runDateMillis ? h.runDateMillis : null);
                    const durationHuman = h && (h.durationMillis || h.durationMillis === 0) ? formatDurationHuman(h.durationMillis) : '';
                    html += `<tr><td class="history-build" title="${escapeHtml(build)}">${escapeHtml(build)}</td><td title="${escapeHtml(runDate)}">${escapeHtml(runDate)}</td><td><span class="history-status ${statusClass}">${status.toUpperCase()}</span></td><td>${escapeHtml(durationHuman)}</td></tr>`;
                });
                html += '</tbody></table>';
                return html;
            }

            function formatMillis(ms) { return `${(ms / 1000).toFixed(3)}s`; }
            function escapeHtml(text) { if (text === null || text === undefined) return ''; const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;' }; return text.replace(/[&<>']/g, m => map[m]); }
            function normalizeScreenshotPath(path) { if (!path) return null; let normalized = path.replace(/\\/g, '/'); const screenshotsIndex = normalized.indexOf('screenshots/'); return screenshotsIndex !== -1 ? normalized.substring(screenshotsIndex) : normalized; }

           function buildActionHtml(action) {

               const screenshotPath =
                   normalizeScreenshotPath(action.screenshotPath);

               const description =
                   action.action ? String(action.action) : '';

               const error =
                   action.error ? String(action.error) : null;

               const rawResult =
                   (action.result !== null && action.result !== undefined)
                       ? String(action.result).trim()
                       : null;

               const descriptionParts = description.split('<br>');

               const mainActionPart =
                   escapeHtml(descriptionParts[0]);

               let finalDescriptionHtml = mainActionPart;

               if (descriptionParts.length > 1) {

                   const locatorPart =
                       escapeHtml(descriptionParts[1]);

                   finalDescriptionHtml +=
                       `<br><span class="locator-text">${locatorPart}</span>`;
               }

               let resultHtml = '';

               if (rawResult && rawResult.length > 0) {

                   if (rawResult.includes('|')) {

                       const parts = rawResult
                           .split(/\s*\|\s*/)
                           .map(p => p.trim())
                           .filter(p => p.length > 0);

                       let expected = '';
                       let actual = '';

                       for (let i = 1; i < parts.length; i++) {

                           const token = parts[i];

                           const m = token.match(
                               /^([^=]+)\s*=\s*'([\s\S]*)'$/
                           );

                           if (!m) continue;

                           const label =
                               m[1].trim().toLowerCase();

                           const value = m[2];

                           if (label.startsWith('expected')) {

                               expected = value;

                           } else if (label.startsWith('actual')) {

                               actual = value;
                           }
                       }

                       if (expected !== '' || actual !== '') {

                           resultHtml =
                               `<div class="action-result">
                                   <pre style="
                                       margin:8px 0 0 0;
                                       padding:8px;
                                       font-family:monospace;
                                       font-size:0.875rem;
                                       background:#fff;
                                       border-radius:6px;
                                       border:1px solid #eef1f4;
                                       color:#333;
                                       white-space:pre-wrap;
                                       text-align:left;
                                   ">
           Expected =  '${escapeHtml(expected)}'
           Actual   =  '${escapeHtml(actual)}'
                                   </pre>
                               </div>`;

                       } else {

                           resultHtml =
                               `<div class="action-result">
                                   <pre style="
                                       margin:8px 0 0 0;
                                       padding:8px;
                                       font-family:monospace;
                                       font-size:0.875rem;
                                       background:#fff;
                                       border-radius:6px;
                                       border:1px solid #eef1f4;
                                       color:#333;
                                       white-space:pre-wrap;
                                       text-align:left;
                                   ">
           ${escapeHtml(rawResult)}
                                   </pre>
                               </div>`;
                       }

                   } else {

                       resultHtml =
                           `<div class="action-result">
                               <pre style="
                                   margin:8px 0 0 0;
                                   padding:8px;
                                   font-family:monospace;
                                   font-size:0.875rem;
                                   background:#fff;
                                   border-radius:6px;
                                   border:1px solid #eef1f4;
                                   color:#333;
                                   white-space:pre-wrap;
                                   text-align:left;
                               ">
           ${escapeHtml(rawResult)}
                               </pre>
                           </div>`;
                   }
               }

               const errorHtml =
                   error
                       ? `<div class="error-details">
                               <pre>${escapeHtml(error)}</pre>
                          </div>`
                       : '';

               const descHtml =
                   `<span class="action-description">
                       ${finalDescriptionHtml}
                    </span>`;

               // SCREENSHOT HTML
               const screenshotHtml =
                   screenshotPath
                       ? `
                           <div class="step-screenshot-container">

                               <a href="${screenshotPath}"
                                  target="_blank">

                                   <img src="${screenshotPath}"
                                        alt="Screenshot"
                                        class="step-screenshot"/>

                               </a>

                           </div>
                         `
                       : '';

               return `
                   <div class="action status-${(action.status || 'PASSED').toLowerCase()}">

                       ${descHtml}

                       ${resultHtml}

                       ${errorHtml}

                       ${screenshotHtml}

                   </div>
               `;
           }

            function buildStepHtml(step) {
                const status = (step.status||'skipped').toLowerCase();
                const hasActions = step.actions && step.actions.length > 0;
                const hasError = status === 'failed' && step.error;
                const isExpandable = hasActions || hasError;
                let dataTableHtml = '';
                if (step.dataTable) {
                    dataTableHtml += '<div class="step-data-scroll"><table class="step-data-table">';
                    if (step.dataTable.header) {
                        dataTableHtml += `<thead><tr><th class="status-cell"></th>`;
                        step.dataTable.header.forEach(h => dataTableHtml += `<th>${escapeHtml(h)}</th>`);
                        dataTableHtml += '</tr></thead>';
                    }
                    if (step.dataTable.rows) {
                        dataTableHtml += '<tbody>';
                        step.dataTable.rows.forEach(row => {
                            dataTableHtml += '<tr>';
                            const rowStatus = (row.status ? row.status : 'skipped').toLowerCase();
                            const statusIconHtml = statusIcons[rowStatus] || '';
                            dataTableHtml += `<td class="status-cell status-${rowStatus}">${statusIconHtml}</td>`;
                            row.data.forEach(cell => dataTableHtml += `<td>${escapeHtml(cell)}</td>`);
                            dataTableHtml += '</tr>';
                        });
                        dataTableHtml += '</tbody>';
                    }
                    dataTableHtml += '</table></div>';
                }
                const actionsHtml = hasActions ? step.actions.map(buildActionHtml).join('') : '';
                const hasActionLevelError = hasActions && step.actions.some(action => action.error);
                const stepErrorHtml = (hasError && !hasActionLevelError) ? `<div class="action status-failed"><span class="action-description">Step Error</span><div class="error-details"><pre>${escapeHtml(step.error)}</pre></div></div>` : '';
                const actionsAreVisible = status === 'failed';
                const stepTitleHtml = escapeHtml(step.text || '').replace(/"([^"]*)"/g, '<span class="step-argument">"$1"</span>');
                const headerHtml = `
                    <div class="step-header ${isExpandable ? 'is-expandable' : ''} ${actionsAreVisible ? 'is-expanded' : ''}">
                        ${isExpandable ? '<svg class="step-chevron" viewBox="0 0 24 24"><path fill="currentColor" d="M9 18l6-6-6-6v12z"/></svg>' : '<div style="width:1rem; margin-right:0.75rem;"></div>'}
                        <div class="step-status status-${status}">${statusIcons[status] || statusIcons['undefined']}</div>
                        <div class="step-title"><strong>${step.keyword || ''}</strong> ${stepTitleHtml}</div>
                        <span class="step-duration">${formatMillis(step.durationMillis||0)}</span>
                    </div>`;
                const actionsWrapperHtml = `<div class="step-actions ${actionsAreVisible ? '' : 'hidden'}">${actionsHtml}${stepErrorHtml}</div>`;
                return `<div class="step" data-status="${status}">${headerHtml}${dataTableHtml}${isExpandable ? actionsWrapperHtml : ''}</div>`;
            }


            function buildScenarioHtml(data) {
                const tagsHtml = data.tags ? `<p class="scenario-tags">${data.tags.join(' ')}</p>` : '';
                const stepsHtml = data.steps ? data.steps.map(buildStepHtml).join('') : '<div>No steps found.</div>';
                function normalizeVideoPath(path){ if (!path) return null; let normalized = path.replace(/\\/g,'/'); const videosIndex = normalized.indexOf('videos/'); return videosIndex !== -1 ? normalized.substring(videosIndex) : normalized; }
                let logsHtml = data.videoPath ? `<h3 style="font-weight:500;color:#222;">Test Execution Recording</h3><video controls><source src="${normalizeVideoPath(data.videoPath)}" type="video/webm">Your browser does not support the video tag.</video>` : '<h3 style="font-weight:500;color:#222;">No test execution recording available.</h3>';
                const historyHtml = buildHistoryHtml(data.history);
                return `
                    <div class="scenario">
                        <div class="scenario-header">
                            <div class="scenario-info">
                                <div class="scenario-header-top">
                                    ${tagsHtml}
                                    <div class="scenario-meta">
                                        <span class="duration-text">Duration: ${formatMillis(data.durationMillis||0)}</span>
                                        <span class="status-badge passed" title="${data.passedSteps||0} Passed">${data.passedSteps||0}</span>
                                        <span class="status-badge failed" onclick="jumpToFirstStepOfStatus('failed')" title="${data.failedSteps||0} Failed">${data.failedSteps||0}</span>
                                        ${(data.ambiguousSteps && data.ambiguousSteps > 0) ? `<span class="status-badge ambiguous" onclick="jumpToFirstStepOfStatus('ambiguous')" title="${data.ambiguousSteps} Ambiguous">${data.ambiguousSteps}</span>` : ''}
                                        ${(data.undefinedSteps && data.undefinedSteps > 0) ? `<span class="status-badge undefined" onclick="jumpToFirstStepOfStatus('undefined')" title="${data.undefinedSteps} Not Defined">${data.undefinedSteps}</span>` : ''}
                                        ${(data.pendingSteps && data.pendingSteps > 0) ? `<span class="status-badge pending" onclick="jumpToFirstStepOfStatus('pending')" title="${data.pendingSteps} Pending">${data.pendingSteps}</span>` : ''}
                                        <span class="status-badge skipped" onclick="jumpToFirstStepOfStatus('skipped')" title="${data.skippedSteps||0} Skipped">${data.skippedSteps||0}</span>
                                    </div>
                                </div>
                                <h2 class="scenario-title"><strong>Scenario:</strong> ${escapeHtml(data.scenarioName)}</h2>
                            </div>
                        </div>
                        <div class="scenario-body">
                            <nav class="tabs-nav">
                                <a class="tab-link active" onclick="showTab('steps', this)">Steps</a>
                                <a class="tab-link" onclick="showTab('logs', this)">Logs</a>
                                <a class="tab-link" onclick="showTab('history', this)">History</a>
                            </nav>
                            <div class="tab-content-wrapper">
                                <div id="steps-container" class="tab-content">${stepsHtml}</div>
                                <div id="logs-container" class="tab-content hidden">${logsHtml}</div>
                                <div id="history-container" class="tab-content hidden">${historyHtml}</div>
                            </div>
                        </div>
                    </div>`;
            }

            function showScreenshot(imageSrc, event) { if(event) event.stopPropagation(); const overlay = document.getElementById('screenshot-overlay'); const image = document.getElementById('screenshot-image'); image.src = imageSrc; overlay.classList.remove('hidden'); }
            function hideScreenshot() { document.getElementById('screenshot-overlay').classList.add('hidden'); }
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideScreenshot(); });

            const searchInput = document.getElementById('scenario-search');
            const filterButton = document.getElementById('filter-button');
            const filterDropdown = document.getElementById('filter-dropdown');
            const filterCheckboxes = filterDropdown.querySelectorAll('input[type="checkbox"]');
            const scenarioLinks = document.querySelectorAll('.sidebar-scenarios .scenario-link');

            function filterScenarios() {
                const searchTerm = searchInput.value.toLowerCase();
                const activeStatuses = Array.from(filterCheckboxes).filter(cb => cb.checked).map(cb => cb.value);
                scenarioLinks.forEach(link => {
                    const scenarioText = link.textContent.toLowerCase();
                    const scenarioStatus = link.dataset.status;
                    link.style.display = (scenarioText.includes(searchTerm) && activeStatuses.includes(scenarioStatus)) ? 'flex' : 'none';
                });
            }
            filterButton.addEventListener('click', (e) => { e.stopPropagation(); filterDropdown.classList.toggle('hidden'); });
            window.addEventListener('click', (e) => { if (!filterDropdown.classList.contains('hidden') && !filterDropdown.contains(e.target) && !filterButton.contains(e.target)) filterDropdown.classList.add('hidden'); });
            searchInput.addEventListener('input', filterScenarios);
            filterCheckboxes.forEach(checkbox => checkbox.addEventListener('change', filterScenarios));

            function mergeHistoryFromGlobal(scenarioObj, scenarioUUID) {
                try {
                    if (!scenarioObj || (scenarioObj.history && scenarioObj.history.length > 0)) { return; }
                    const globalHist = window.__allFeatureHistories;
                    if (!globalHist || !Array.isArray(globalHist.features)) { return; }
                    let featureEntry = window.__currentFeatureUUID ? globalHist.features.find(f => f.featureUUID === window.__currentFeatureUUID) : null;
                    let scenarioEntry = null;
                    if (featureEntry && Array.isArray(featureEntry.scenarios)) {
                        scenarioEntry = featureEntry.scenarios.find(s => s.scenarioUUID === scenarioUUID);
                    }
                    if (!scenarioEntry) {
                        for (let f of globalHist.features) {
                            if (f && Array.isArray(f.scenarios)) {
                                const s = f.scenarios.find(sc => sc.scenarioUUID === scenarioUUID);
                                if (s) { scenarioEntry = s; break; }
                            }
                        }
                    }
                    if (scenarioEntry && Array.isArray(scenarioEntry.history)) {
                        scenarioObj.history = scenarioEntry.history.slice();
                    }
                } catch (err) { console.error('mergeHistoryFromGlobal error', err); }
            }

            // fileKey: module_scenarioId_uuid  (no .js)
            // scenarioUUID: original uuid (used for history merge lookups)
            function loadScenarioDetails(fileKey, scenarioUUID, clickedLink) {
                mainContentContainer.innerHTML = `<div class="scenario-placeholder"><span>Loading scenario details...</span></div>`;
                document.querySelectorAll('.sidebar .scenario-link').forEach(link => link.classList.remove('active'));
                if (clickedLink) clickedLink.classList.add('active');

                const oldScript = document.getElementById('dynamic-scenario-script');
                if (oldScript) oldScript.remove();

                const originalLoad = window.loadScenarioData;
                let wrapped = false;
                if (typeof originalLoad === 'function') {
                    wrapped = true;
                    window.loadScenarioData = function(scenarioData) {
                        mergeHistoryFromGlobal(scenarioData, scenarioUUID);
                        originalLoad.call(this, scenarioData);
                    };
                }

                const script = document.createElement('script');
                script.id = 'dynamic-scenario-script';
                // use the new filename pattern (append .js)
                script.src = `json/scenarios/${fileKey}.js`;

                script.onload = function() {
                    try {
                        if (window.__scenarioData) {
                            const sd = window.__scenarioData;
                            mergeHistoryFromGlobal(sd, scenarioUUID);
                            (originalLoad || window.loadScenarioData || loadScenarioData)(sd);
                            delete window.__scenarioData;
                        }
                    } catch (err) {
                        console.error('Error processing loaded scenario script', err);
                    } finally {
                        if (wrapped) window.loadScenarioData = originalLoad;
                    }
                };

                script.onerror = function() {
                    mainContentContainer.innerHTML = `<div class="scenario-placeholder"><span>Failed to load scenario file: ${fileKey}.js</span></div>`;
                    if (wrapped) window.loadScenarioData = originalLoad;
                };

                document.head.appendChild(script);
            }

        </script>
        </#noparse>

            <script>
                const chartOptions = {
                    cutout: '70%',
                    plugins: {
                        legend: { display: false },
                        tooltip: { enabled: true, callbacks: { label: function(ctx) {
                            const v = ctx.raw || 0;
                            const label = ctx.chart.data.labels[ctx.dataIndex] || '';
                            return label + ': ' + v;
                        }}}
                    },
                    maintainAspectRatio: false
                };

                // Make sure the dataset order matches the legend order in the DOM above:
                const stepsLabels = ['Passed', 'Failed', 'Ambiguous', 'Not Defined', 'Pending', 'Skipped'];
                // Use ?c to prevent thousand separators (e.g., 2,645 -> 2645) ***
                const stepsData   = [${passedSteps?c}, ${failedSteps?c}, ${ambiguousSteps?c}, ${undefinedSteps?c}, ${pendingSteps?c}, ${skippedSteps?c}];

                const stepsColors = [
                    '#28a745', // Passed (green)
                    '#dc3545', // Failed (red)
                    '#8b0000', // Ambiguous (dark red) -> different from failed
                    '#fd7e14', // Not Defined (orange)
                    '#ffc107', // Pending (yellow)
                    '#17a2b8'  // Skipped (teal)
                ];

                new Chart(document.getElementById('stepsChart').getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: stepsLabels,
                        datasets: [{
                            data: stepsData,
                            backgroundColor: stepsColors,
                            borderWidth: 0
                        }]
                    },
                    options: chartOptions
                });

                // scenarios chart remains the same but add labels for clarity:
                new Chart(document.getElementById('scenariosChart').getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Passed','Failed','Skipped'],
                        //Use ?c for consistency and robustness ***
                        datasets: [{ data: [${passedScenarios?c}, ${failedScenarios?c}, ${skippedScenarios?c}], backgroundColor: ['#28a745', '#dc3545', '#17a2b8'], borderWidth: 0 }]
                    },
                    options: chartOptions
                });
            </script>
    </body>
</html>