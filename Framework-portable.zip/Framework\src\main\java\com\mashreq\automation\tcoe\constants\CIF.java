package com.mashreq.automation.tcoe.constants;

/**
 * AUTO-GENERATED. Do not edit manually.
 * Source: OR_Common.json
 * Format: SCREEN_FIELD = "MODULE/SCREEN/FIELD"
 */
public final class CIF {

    private CIF() {}

    // ===== GeneralDetails =====
    public static final String GENERALDETAILS_CUSTOMERNUMBER = "CIF/GeneralDetails/CustomerNumber";
    public static final String GENERALDETAILS_CORPORATECUSTOMERTYPE = "CIF/GeneralDetails/CorporateCustomerType";
    public static final String GENERALDETAILS_BANKCUSTOMERTYPE = "CIF/GeneralDetails/BankCustomerType";
    public static final String GENERALDETAILS_CUSTOMERPOPULATE = "CIF/GeneralDetails/CustomerPopulate";
    public static final String GENERALDETAILS_CUSTOMERFULLNAME = "CIF/GeneralDetails/CustomerFullName";
    public static final String GENERALDETAILS_CUSTOMERSHORTNAME = "CIF/GeneralDetails/CustomerShortName";
    public static final String GENERALDETAILS_CUSTOMERCATEGORY = "CIF/GeneralDetails/CustomerCategory";
    public static final String GENERALDETAILS_CATEGORYFI = "CIF/GeneralDetails/CategoryFI";
    public static final String GENERALDETAILS_ADDRESSLINE = "CIF/GeneralDetails/AddressLine";
    public static final String GENERALDETAILS_ADDRESSLINE2 = "CIF/GeneralDetails/AddressLine2";
    public static final String GENERALDETAILS_ADDRESSLINE3 = "CIF/GeneralDetails/AddressLine3";
    public static final String GENERALDETAILS_ADDRESSLINE4 = "CIF/GeneralDetails/AddressLine4";
    public static final String GENERALDETAILS_TELEPHONENO = "CIF/GeneralDetails/TelephoneNo";
    public static final String GENERALDETAILS_TELEPHONEISDCODE = "CIF/GeneralDetails/TelephoneISDCode";
    public static final String GENERALDETAILS_MBNO = "CIF/GeneralDetails/MbNo";
    public static final String GENERALDETAILS_MBISDCODE = "CIF/GeneralDetails/MbISDCode";
    public static final String GENERALDETAILS_EMAILID = "CIF/GeneralDetails/EmailId";
    public static final String GENERALDETAILS_SAMEASCORRESPONDENCEADDRES = "CIF/GeneralDetails/SameAsCorrespondenceAddres";
    public static final String GENERALDETAILS_COMMUNICATIONMODE = "CIF/GeneralDetails/CommunicationMode";
    public static final String GENERALDETAILS_ADDRESSLINEINDIVIDUAL = "CIF/GeneralDetails/AddressLineIndividual";
    public static final String GENERALDETAILS_COUNTRY = "CIF/GeneralDetails/Country";
    public static final String GENERALDETAILS_COUNTRYINDIVIDUAL = "CIF/GeneralDetails/CountryIndividual";
    public static final String GENERALDETAILS_LANGUAGE = "CIF/GeneralDetails/Language";
    public static final String GENERALDETAILS_LANGUAGEINDIVIDUAL = "CIF/GeneralDetails/LanguageIndividual";
    public static final String GENERALDETAILS_NAME = "CIF/GeneralDetails/Name";
    public static final String GENERALDETAILS_EXITCUSTOMER = "CIF/GeneralDetails/ExitCustomer";
    public static final String GENERALDETAILS_CUSTOMEROK = "CIF/GeneralDetails/CustomerOK";
    public static final String GENERALDETAILS_GENDERFORINDIVIDUAL = "CIF/GeneralDetails/GenderForIndividual";
    public static final String GENERALDETAILS_DOBFORINDIVIDUAL = "CIF/GeneralDetails/DOBForIndividual";
    public static final String GENERALDETAILS_NATIONALITYFORINDIVIDUAL = "CIF/GeneralDetails/NationalityForIndividual";
    public static final String GENERALDETAILS_DATE = "CIF/GeneralDetails/Date";

    // ===== AdditionalDetails =====
    public static final String ADDITIONALDETAILS_ADDITIONAL = "CIF/AdditionalDetails/Additional";
    public static final String ADDITIONALDETAILS_LOCATION = "CIF/AdditionalDetails/Location";
    public static final String ADDITIONALDETAILS_MEDIA = "CIF/AdditionalDetails/Media";
    public static final String ADDITIONALDETAILS_RMID = "CIF/AdditionalDetails/RMID";
    public static final String ADDITIONALDETAILS_RMNAME = "CIF/AdditionalDetails/RMName";
    public static final String ADDITIONALDETAILS_BUSINESSCODE = "CIF/AdditionalDetails/BusinessCode";
    public static final String ADDITIONALDETAILS_PURPOSECODE = "CIF/AdditionalDetails/PurposeCode";
    public static final String ADDITIONALDETAILS_SSN_NO = "CIF/AdditionalDetails/SSN_No";
    public static final String ADDITIONALDETAILS_SWIFTSELECT = "CIF/AdditionalDetails/SWIFTSelect";
    public static final String ADDITIONALDETAILS_BLACKLISTCODE = "CIF/AdditionalDetails/BlackListCode";
    public static final String ADDITIONALDETAILS_BLACKLIST = "CIF/AdditionalDetails/BlackList";

    // ===== MIS =====
    public static final String MIS_MIS = "CIF/MIS/MIS";
    public static final String MIS_CUSTOMERMISCODE = "CIF/MIS/CustomerMISCode";
    public static final String MIS_MISSEGMENT = "CIF/MIS/MISSegment";
    public static final String MIS_COMPOSITETAB = "CIF/MIS/CompositeTab";
    public static final String MIS_MISCODE = "CIF/MIS/MISCode";
    public static final String MIS_BUS_GRP = "CIF/MIS/BUS_GRP";
    public static final String MIS_CUST_SGMT = "CIF/MIS/CUST_SGMT";
    public static final String MIS_SRC_BRN = "CIF/MIS/SRC_BRN";
    public static final String MIS_GEOGRAPHY = "CIF/MIS/GEOGRAPHY";

    // ===== AccountGeneralDetails =====
    public static final String ACCOUNTGENERALDETAILS_CUSTOMERNUMBER = "CIF/AccountGeneralDetails/CustomerNumber";
    public static final String ACCOUNTGENERALDETAILS_CURRENCY = "CIF/AccountGeneralDetails/Currency";
    public static final String ACCOUNTGENERALDETAILS_ACCOUNTCLASS = "CIF/AccountGeneralDetails/AccountClass";
    public static final String ACCOUNTGENERALDETAILS_ACCOUNTFETCH = "CIF/AccountGeneralDetails/AccountFetch";
    public static final String ACCOUNTGENERALDETAILS_ACCOUNTNUMBER = "CIF/AccountGeneralDetails/AccountNumber";
    public static final String ACCOUNTGENERALDETAILS_ACCOUNTOPENDATE = "CIF/AccountGeneralDetails/AccountOpenDate";
    public static final String ACCOUNTGENERALDETAILS_PURPOSECODEUSERDEFINEDFIELDS = "CIF/AccountGeneralDetails/PurposeCodeUserDefinedFields";
    public static final String ACCOUNTGENERALDETAILS_ACCLOCATION = "CIF/AccountGeneralDetails/AccLocation";
    public static final String ACCOUNTGENERALDETAILS_ACCMEDIA = "CIF/AccountGeneralDetails/AccMedia";

    // ===== AccountMISDetails =====
    public static final String ACCOUNTMISDETAILS_MIS = "CIF/AccountMISDetails/MIS";
    public static final String ACCOUNTMISDETAILS_POOLCODE = "CIF/AccountMISDetails/PoolCode";
    public static final String ACCOUNTMISDETAILS_MISOK = "CIF/AccountMISDetails/MISOk";
    public static final String ACCOUNTMISDETAILS_COMPOSITEMISCODE = "CIF/AccountMISDetails/CompositeMISCode";
    public static final String ACCOUNTMISDETAILS_PRODUCTCODE = "CIF/AccountMISDetails/ProductCode";
    public static final String ACCOUNTMISDETAILS_BUS_GRP = "CIF/AccountMISDetails/BUS_GRP";
    public static final String ACCOUNTMISDETAILS_CUST_SGMT = "CIF/AccountMISDetails/CUST_SGMT";
    public static final String ACCOUNTMISDETAILS_SRC_BRN = "CIF/AccountMISDetails/SRC_BRN";
    public static final String ACCOUNTMISDETAILS_GEOGRAPHY = "CIF/AccountMISDetails/GEOGRAPHY";
    public static final String ACCOUNTMISDETAILS_ACCOUNTNUMBER = "CIF/AccountMISDetails/AccountNumber";

    // ===== JournalEntry =====
    public static final String JOURNALENTRY_BATCHNUMBER = "CIF/JournalEntry/BatchNumber";
    public static final String JOURNALENTRY_DESCRIPTION = "CIF/JournalEntry/Description";
    public static final String JOURNALENTRY_GLBRANCHCODE = "CIF/JournalEntry/GLBranchcode";
    public static final String JOURNALENTRY_GLACCOUNT = "CIF/JournalEntry/GLAccount";
    public static final String JOURNALENTRY_GLCURRENCY = "CIF/JournalEntry/GLCurrency";
    public static final String JOURNALENTRY_GLAMOUNT = "CIF/JournalEntry/GLAmount";
    public static final String JOURNALENTRY_GLLCYAMOUNT = "CIF/JournalEntry/GLLCYAmount";
    public static final String JOURNALENTRY_GLTRANSCODE = "CIF/JournalEntry/GLTransCode";
    public static final String JOURNALENTRY_ADDROW = "CIF/JournalEntry/Addrow";
    public static final String JOURNALENTRY_ACCOUNTSELECTOPTION = "CIF/JournalEntry/AccountSelectOption";
    public static final String JOURNALENTRY_ACBRANCHCODE = "CIF/JournalEntry/ACBranchcode";
    public static final String JOURNALENTRY_ACCOUNTNUMBER = "CIF/JournalEntry/AccountNumber";
    public static final String JOURNALENTRY_ACAMOUNT = "CIF/JournalEntry/ACAmount";
    public static final String JOURNALENTRY_ACLCYAMOUNT = "CIF/JournalEntry/ACLCYAmount";
    public static final String JOURNALENTRY_ACTRANSCODE = "CIF/JournalEntry/ACTransCode";
    public static final String JOURNALENTRY_REFERENCENUMBER = "CIF/JournalEntry/ReferenceNumber";

    // ===== LinkedEntity =====
    public static final String LINKEDENTITY_LINKEDENTITY = "CIF/LinkedEntity/LinkedEntity";
    public static final String LINKEDENTITY_ADDICONLINKEDENTITY = "CIF/LinkedEntity/addIconLinkedEntity";
    public static final String LINKEDENTITY_REMOVEICONLINKEDENTITY = "CIF/LinkedEntity/removeIconLinkedEntity";
    public static final String LINKEDENTITY_LINKEDENTITIESOK = "CIF/LinkedEntity/LinkedEntitiesOk";
    public static final String LINKEDENTITY_CUSTOMER = "CIF/LinkedEntity/Customer";
    public static final String LINKEDENTITY_CUSTOMER1 = "CIF/LinkedEntity/Customer1";
    public static final String LINKEDENTITY_CUSTOMER2 = "CIF/LinkedEntity/Customer2";
    public static final String LINKEDENTITY_RELATIONS = "CIF/LinkedEntity/Relations";
    public static final String LINKEDENTITY_RELATIONS1 = "CIF/LinkedEntity/Relations1";
    public static final String LINKEDENTITY_RELATIONS2 = "CIF/LinkedEntity/Relations2";
    public static final String LINKEDENTITY_EXITLINKEDENTITIES = "CIF/LinkedEntity/ExitLinkedEntities";
    public static final String LINKEDENTITY_CHECKKDELETEROW0 = "CIF/LinkedEntity/CheckkDeleteRow0";
    public static final String LINKEDENTITY_CUSTOMER1DESC = "CIF/LinkedEntity/Customer1Desc";
    public static final String LINKEDENTITY_CUSTOMER2DESC = "CIF/LinkedEntity/Customer2Desc";
    public static final String LINKEDENTITY_CATEGORY2 = "CIF/LinkedEntity/Category2";

    // ===== AuxiliaryDetails =====
    public static final String AUXILIARYDETAILS_AUXILIARY = "CIF/AuxiliaryDetails/Auxiliary";
    public static final String AUXILIARYDETAILS_CRSCUSTOMERTYPE = "CIF/AuxiliaryDetails/CRSCustomerType";

    // ===== HKDetails =====
    public static final String HKDETAILS_HKDETAILSTAB = "CIF/HKDetails/HKDetailsTab";
    public static final String HKDETAILS_HKDOMESTICPEP = "CIF/HKDetails/HKDomesticPEP";

    // ===== RelatedPartiesDetails =====
    public static final String RELATEDPARTIESDETAILS_CUSTOMERNAME = "CIF/RelatedPartiesDetails/CustomerName";
    public static final String RELATEDPARTIESDETAILS_IDENTIFICATIONTYPE = "CIF/RelatedPartiesDetails/IdentificationType";
    public static final String RELATEDPARTIESDETAILS_NATIONALITY = "CIF/RelatedPartiesDetails/Nationality";
    public static final String RELATEDPARTIESDETAILS_COUNTRYOFISSUE = "CIF/RelatedPartiesDetails/CountryOfIssue";
    public static final String RELATEDPARTIESDETAILS_COUNTRYRELATEDPATIES = "CIF/RelatedPartiesDetails/CountryRelatedPaties";
    public static final String RELATEDPARTIESDETAILS_POSITION = "CIF/RelatedPartiesDetails/Position";
    public static final String RELATEDPARTIESDETAILS_IDNUMBER = "CIF/RelatedPartiesDetails/IDNumber";
    public static final String RELATEDPARTIESDETAILS_IDISSUEPLACE = "CIF/RelatedPartiesDetails/IDIssuePlace";
    public static final String RELATEDPARTIESDETAILS_IDISSUEDATE = "CIF/RelatedPartiesDetails/IDIssueDate";
    public static final String RELATEDPARTIESDETAILS_IDEXPIRYDATE = "CIF/RelatedPartiesDetails/IDExpiryDate";
    public static final String RELATEDPARTIESDETAILS_EMAIL = "CIF/RelatedPartiesDetails/Email";
    public static final String RELATEDPARTIESDETAILS_PEPFPEP = "CIF/RelatedPartiesDetails/PepFpep";
    public static final String RELATEDPARTIESDETAILS_PEPFPEP_1 = "CIF/RelatedPartiesDetails/PepFpep_1";
    public static final String RELATEDPARTIESDETAILS_RELATEDPARTIESFIELD = "CIF/RelatedPartiesDetails/relatedPartiesField";
    public static final String RELATEDPARTIESDETAILS_LOVSEARCHICON = "CIF/RelatedPartiesDetails/LOVSearchIcon";
    public static final String RELATEDPARTIESDETAILS_LOVPOSITIONCODE = "CIF/RelatedPartiesDetails/LOVPositionCode";
    public static final String RELATEDPARTIESDETAILS_LOVFETCH = "CIF/RelatedPartiesDetails/LOVFetch";
    public static final String RELATEDPARTIESDETAILS_LOVFIRSTROW = "CIF/RelatedPartiesDetails/LOVFirstRow";

    // ===== SignatureDetails =====
    public static final String SIGNATUREDETAILS_SIGNATUREID = "CIF/SignatureDetails/SignatureId";
    public static final String SIGNATUREDETAILS_CUSTOMERNUMBERINSIGNATURE = "CIF/SignatureDetails/CustomerNumberINSignature";
    public static final String SIGNATUREDETAILS_SIGNATURENAME = "CIF/SignatureDetails/SignatureName";
    public static final String SIGNATUREDETAILS_SIGNATURETABLE = "CIF/SignatureDetails/SignatureTable";
    public static final String SIGNATUREDETAILS_NEXTBUTTON = "CIF/SignatureDetails/nextButton";
    public static final String SIGNATUREDETAILS_TOTALPAGESBUTTON = "CIF/SignatureDetails/totalPagesButton";

    // ===== CustomerSignatoryDetails =====
    public static final String CUSTOMERSIGNATORYDETAILS_SIGNATUREIDDETAILS = "CIF/CustomerSignatoryDetails/SignatureIdDetails";
    public static final String CUSTOMERSIGNATORYDETAILS_TABLEROW = "CIF/CustomerSignatoryDetails/TableRow";

    // ===== FATCADetails =====
    public static final String FATCADETAILS_FATCA = "CIF/FATCADetails/FATCA";
    public static final String FATCADETAILS_NATIONALITY = "CIF/FATCADetails/Nationality";
    public static final String FATCADETAILS_COUNTRYOFBIRTH = "CIF/FATCADetails/CountryOfBirth";
    public static final String FATCADETAILS_PARENTCOCOUNTRYINCOR = "CIF/FATCADetails/ParentCoCountryIncor";
    public static final String FATCADETAILS_ACTIVEORPASSIVENFFE = "CIF/FATCADetails/ActiveOrPassiveNFFE";
    public static final String FATCADETAILS_ACCOUNTCLASSIFICATION = "CIF/FATCADetails/AccountClassification";
    public static final String FATCADETAILS_FATCAOK = "CIF/FATCADetails/FATCAOK";
    public static final String FATCADETAILS_EXITFATCA = "CIF/FATCADetails/ExitFATCA";

    // ===== userDefinedFields =====
    public static final String USERDEFINEDFIELDS_FIELDS = "CIF/userDefinedFields/Fields";
    public static final String USERDEFINEDFIELDS_USERDEFINEDFIELDSOK = "CIF/userDefinedFields/UserDefinedFieldsOk";
    public static final String USERDEFINEDFIELDS_COMPLEXOWNERSHIPSTRUCTURE = "CIF/userDefinedFields/ComplexOwnershipStructure";
    public static final String USERDEFINEDFIELDS_BEARERSHARESINOWNERSHIPSTRUCTURE = "CIF/userDefinedFields/BearerSharesInOwnershipStructure";
    public static final String USERDEFINEDFIELDS_NOMINEESHAREHOLDERS = "CIF/userDefinedFields/NomineeShareHolders";

    // ===== KYCDetails =====
    public static final String KYCDETAILS_KYCDETAILS = "CIF/KYCDetails/KYCDetails";
    public static final String KYCDETAILS_KYCREFNO = "CIF/KYCDetails/KYCRefNo";
    public static final String KYCDETAILS_KYCCUSTOMERFULLNAME = "CIF/KYCDetails/KYCCustomerFullName";
    public static final String KYCDETAILS_KYCCUSTOMERNUMBER = "CIF/KYCDetails/KYCCustomerNumber";
    public static final String KYCDETAILS_KYCDESC = "CIF/KYCDetails/KYCDESC";
    public static final String KYCDETAILS_KYCCUSTOMERTYPE = "CIF/KYCDetails/KYCCustomerType";
    public static final String KYCDETAILS_KYCCRSCUSTOMERTYPE = "CIF/KYCDetails/KYCCRSCustomerType";
    public static final String KYCDETAILS_RISKLEVEL = "CIF/KYCDetails/RiskLevel";
    public static final String KYCDETAILS_CUSTOMERNO = "CIF/KYCDetails/CustomerNo";
    public static final String KYCDETAILS_ADDRISKMATRIXROW = "CIF/KYCDetails/AddRiskMatrixRow";
    public static final String KYCDETAILS_RISKMATRIXSERIALNO = "CIF/KYCDetails/RiskMatrixSerialNo";
    public static final String KYCDETAILS_RISKMATRIXLOW = "CIF/KYCDetails/RiskMatrixLow";
    public static final String KYCDETAILS_RISKMATRIXMID = "CIF/KYCDetails/RiskMatrixMid";
    public static final String KYCDETAILS_RISKMATRIXHIGH = "CIF/KYCDetails/RiskMatrixHigh";
    public static final String KYCDETAILS_CORPORATECUSTOMERTAB = "CIF/KYCDetails/CorporateCustomerTab";
    public static final String KYCDETAILS_FINANCIALCUSTOMERTAB = "CIF/KYCDetails/FinancialCustomerTab";
    public static final String KYCDETAILS_FINANCIALCUSTOMERCOUNTRY = "CIF/KYCDetails/FinancialCustomerCountry";
    public static final String KYCDETAILS_FINANCIALCUSTOMERBANKADDRESS = "CIF/KYCDetails/FinancialCustomerBankAddress";
    public static final String KYCDETAILS_PURPOSEOFACCOUNTOPENING = "CIF/KYCDetails/PurposeOfAccountOpening";
    public static final String KYCDETAILS_NATUREOFBUSINESS = "CIF/KYCDetails/NatureOfBusiness";
    public static final String KYCDETAILS_PRODUCTTRADED = "CIF/KYCDetails/ProductTraded";
    public static final String KYCDETAILS_MAINSOURCEOFFUNDS = "CIF/KYCDetails/MainSourceOfFunds";
    public static final String KYCDETAILS_PARENTCOMPANYCOUNTRYOFINCORPORATION = "CIF/KYCDetails/ParentCompanyCountryOfIncorporation";
    public static final String KYCDETAILS_TYPEOFCOMPANY = "CIF/KYCDetails/TypeOfCompany";
    public static final String KYCDETAILS_KYCAMOUNTSCURRENCY = "CIF/KYCDetails/KYCAmountsCurrency";
    public static final String KYCDETAILS_DETAILPURPOSECOMMERCIAL = "CIF/KYCDetails/DetailPurposeCommercial";
    public static final String KYCDETAILS_OWNERSHIPDETAILS = "CIF/KYCDetails/OwnershipDetails";
    public static final String KYCDETAILS_NOOFPERSONSEMPLOYED = "CIF/KYCDetails/NoOfPersonsEmployed";
    public static final String KYCDETAILS_MODEFORSALARY = "CIF/KYCDetails/ModeForSalary";
    public static final String KYCDETAILS_TRADELICENSENUMBER = "CIF/KYCDetails/TradeLicenseNumber";
    public static final String KYCDETAILS_TRADELICENSEEXPIRYDATE = "CIF/KYCDetails/TradeLicenseExpiryDate";
    public static final String KYCDETAILS_KYCCOMMENTS = "CIF/KYCDetails/KYCComments";
    public static final String KYCDETAILS_SALESANDSERVICEOFFICERS = "CIF/KYCDetails/SalesAndServiceOfficers";
    public static final String KYCDETAILS_APPROVERS = "CIF/KYCDetails/Approvers";
    public static final String KYCDETAILS_OKSAVECORPORATEPROFILE = "CIF/KYCDetails/OkSaveCorporateProfile";
    public static final String KYCDETAILS_OKSAVEFINANCIALPROFILE = "CIF/KYCDetails/OkSaveFinancialProfile";
    public static final String KYCDETAILS_SAVE = "CIF/KYCDetails/Save";
    public static final String KYCDETAILS_KYCSTATUS = "CIF/KYCDetails/KYCStatus";
    public static final String KYCDETAILS_KYCREFERENCE = "CIF/KYCDetails/KYCReference";
    public static final String KYCDETAILS_POLITICALLYEXPOSEDPERSON = "CIF/KYCDetails/PoliticallyExposedPerson";
    public static final String KYCDETAILS_INFOOKINKYCLINKING = "CIF/KYCDetails/InfoOkInKYCLinking";



}
