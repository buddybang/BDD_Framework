package com.mashreq.automation.tcoe.keywords;

import java.util.function.Supplier;

/**
 * An interface defining the contract for logging a keyword action.
 * This allows the WebUI engine to be decoupled from the specific reporting implementation.
 */
public interface IActionLogger {
    // A method to log an action that returns a value (like getText)
    <T> T logAction(String description, Supplier<T> action);

    // An overloaded method to log an action that does not return a value (like click)
    default void logAction(String description, Runnable action) {
        logAction(description, () -> {
            action.run();
            return null; // Return null for void actions
        });
    }
}