@CIF @Regression @US
Feature: This feature is to test Customer Maintenance Functionality

  @SC_001 @Day1
Scenario: CIF|SC_001|Validation of FI customer from the migrated data,MIS details, Amendment and Authorization of CIF,Closure of CIF
    # Maker - Validate migrated customer data and modify specific fields
    Given user "Maker" is logged into "FCUBS" with appropriate privileges
    When user switch to branch
    And user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user retrieves the existing customer details "CustomerNumber"
    Then user verify the following field details under "GeneralDetails" screen
      | CustomerNumber    |
      | CustomerFullName  |
      | CustomerShortName |
      | CustomerCategory  |
      | AddressLine       |
      | Country           |
      | Language          |
    When user click "Additional" under "AdditionalDetails" screen
    Then user verify the following field details under "AdditionalDetails" screen
      | Location     |
      | Media        |
      | RMID         |
      | RMName       |
      | BusinessCode |
      | PurposeCode  |
    When user click "MIS" under "MIS" screen
    Then user verify "MIS" is displayed successfully
    Then user verify the following field details under "MIS" screen
      | CustomerMISCode |
    When user click "CompositeTab" under "MIS" screen
    Then user verify the following field details under "MIS" screen
      | BUS_GRP   |
      | CUST_SGMT |
      | SRC_BRN   |
      | GEOGRAPHY |
    When user click "ExitCustomer" under "GeneralDetails" screen
    And user click "Unlock"
    Then user modifies the following field details under "GeneralDetails" screen
      | AddressLine_1 |
      | Country_1     |
      | Language_1    |
    When user click "Save"
    #Then user verify the pop up for success message "Remarks"
    When user click "RemarksOk"
    Then user verify the pop up for "success" message "Record Successfully Modified"
    When user click "InfoOk"
    And user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application
    # Checker- Authorize modified customer record
    Given user "Checker" is logged into "FCUBS" with appropriate privileges
    When user switch to branch
    And user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user retrieves the existing customer details "CustomerNumber"
    Then user verifies the modified field details under "GeneralDetails" screen
      | AddressLine_1 |
      | Country_1     |
      | Language_1   |
    When user click "Authorize"
    And user click "AuthAccept"
    Then user verify the pop up for "success" message "Record Successfully Authorized"
    When user click "InfoOk"
    Then user is able to validate customer authorization status as "Authorized"
    And user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application
  # Maker - Close CIF
    Given user "Maker" is logged into "FCUBS" with appropriate privileges
    When user switch to branch
    And user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user retrieves the existing customer details "CustomerNumber"
    And user click "Close"
    Then user verify the pop up for "success" message "Do you want to close the record ?"
    When user click "InfoOk"
    And user click "RemarksOk"
    Then user verify the pop up for "success" message "Record Successfully Closed"
    When user click "InfoOk"
    And user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application
     # Checker- Authorize close CIF
    Given user "Checker" is logged into "FCUBS" with appropriate privileges
    When user switch to branch
    And user navigates to the "Customer Maintenance" screen using "STDCIF"
    Then user verify "Customer Maintenance" is displayed successfully
    When user retrieves the existing customer details "CustomerNumber"
    And user click "Authorize"
    And user click "AuthAccept"
    Then user verify the pop up for "success" message "Record Successfully Authorized"
    When user click "InfoOk"
    Then user is able to validate the close authorization status as "Authorized"
    And user click "Exit"
    And user switch to "HomeBranch"
    Then user logout of the FCUBS application

