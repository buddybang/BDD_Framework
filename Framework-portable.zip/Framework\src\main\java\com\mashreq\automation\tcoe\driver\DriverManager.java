package com.mashreq.automation.tcoe.driver;

import com.mashreq.automation.tcoe.utils.LogUtils;

import com.mashreq.automation.tcoe.constants.FrameworkConstants;
import com.microsoft.playwright.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.Duration;

/**
 * DriverManager manages the lifecycle of Playwright objects (Playwright, Browser, Context, Page).
 * It uses a ThreadLocal approach to ensure thread safety for parallel test execution.
 * This class is designed as a singleton utility and should not be instantiated.
 */
public final class DriverManager {

    private static final ThreadLocal<Playwright> playwright = new ThreadLocal<>();
    private static final ThreadLocal<Browser> browser = new ThreadLocal<>();
    private static final ThreadLocal<BrowserContext> context = new ThreadLocal<>();
    private static final ThreadLocal<Page> page = new ThreadLocal<>();
    private static final ThreadLocal<String> globalBrowserVersion = new ThreadLocal<>();
    /** The last browser started by any thread: for the end-of-run reports, which run on a thread without a browser. */
    private static volatile String lastBrowserVersion;

    /**
     * Browser name and version of the current thread's browser (e.g. "Chrome 125.0.6422.142"); on a thread without one (the
     * reports after the run) the last browser started, or null when no browser was started.
     */
    public static String getBrowserVersion() {
        String own = globalBrowserVersion.get();
        return own != null ? own : lastBrowserVersion;
    }

    /**
     * Private constructor to prevent instantiation of this utility class.
     */
    private DriverManager() {}

    /**
     * Initializes the Playwright driver for the current thread.
     * It creates and configures Playwright, Browser, BrowserContext, and Page instances based on the provided settings.
     */
    public static void initDriver() {
        initDriver(null);
    }

    /**
     * Same as {@link #initDriver()}, in the given browser (chrome, edge, firefox, webkit) instead of BROWSER from the config.
     * Used for scenarios tagged with a browser: Lior tags a recorded test @Chrome when it was recorded in Chrome.
     * Null or blank = BROWSER from the config.
     */
    public static void initDriver(String browserForScenario) {

        // This check prevents re-initialization on the same thread.
        // If a browser instance already exists in the ThreadLocal variable for the current thread,
        // we skip the setup process to avoid creating a duplicate browser.
        if (browser.get() != null) {
            LogUtils.info(
                    "-----> DEBUG: initDriver() was called, but a browser already exists for this thread. Skipping initialization."
            );
            return;
        }
        LogUtils.info(
                "-----> DEBUG: Initializing a new browser for Thread: " + Thread.currentThread().getName()
        );

        // Read values directly from the config
        String browserName = browserForScenario != null && !browserForScenario.isBlank() ? browserForScenario.trim()
                : FrameworkConstants.BROWSER != null ? FrameworkConstants.BROWSER : "chromium";
        boolean isHeadless = FrameworkConstants.HEADLESS;
        if (!isHeadless && !hasDisplay()) {
            // a build agent / server without a screen cannot show a browser window
            LogUtils.warn("-----> No screen on this machine: the browser runs headless (HEADLESS=false in the config is ignored here).");
            isHeadless = true;
        }
        int defaultTimeout = FrameworkConstants.DEFAULT_TIMEOUT_MS;
        boolean recordVideo = FrameworkConstants.VIDEO_RECORD;

        Playwright pw = Playwright.create(createOptions(browserName));
        playwright.set(pw);
        try {
            Browser br = launchBrowser(pw, browserName, isHeadless);
            browser.set(br);

            String fullBrowserInfo = browserName.substring(0, 1).toUpperCase() + browserName.substring(1) + " " + br.version();
            globalBrowserVersion.set(fullBrowserInfo);
            lastBrowserVersion = fullBrowserInfo;

            BrowserContext ctx = createBrowserContext(br, recordVideo);
            context.set(ctx);

            Page pg = ctx.newPage();
            pg.setDefaultTimeout(defaultTimeout);
            page.set(pg);
        } catch (RuntimeException e) {
            // a browser that does not start must not leave Playwright (a Node process) running on this thread
            closeQuietly("the browser after a failed start", () -> {
                if (browser.get() != null) browser.get().close();
            });
            closeQuietly("Playwright after a failed start", pw::close);
            browser.remove();
            context.remove();
            page.remove();
            playwright.remove();
            globalBrowserVersion.remove();
            throw e;
        }
    }

    private static void closeQuietly(String what, Runnable close) {
        try {
            close.run();
        } catch (RuntimeException e) {
            LogUtils.warn("Could not close " + what + ": " + e.getMessage());
        }
    }

    /**
     * Retrieves the Page object for the current thread.
     *
     * @return The Page object. Throws an IllegalStateException if the driver is not initialized.
     */
    public static Page getPage() {
        if (page.get() == null) {
            throw new IllegalStateException("DriverManager.page is null. Please call initDriver() first.");
        }
        return page.get();
    }

    /**
     * Closes all Playwright resources in the correct order for the current thread.
     * This includes closing the context, browser, and the Playwright instance itself.
     * It also cleans up the ThreadLocal variables to prevent memory leaks.
     */
    public static Path closeDriver(String scenarioUUID) {
        Page pg = page.get();
        Video vid = null;

        // 1) Close page to finalize the video
        try {
            if (pg != null) {
                vid = pg.video();     // capture handle before closing (safer)
                pg.close();           // this triggers video finalization
            }
        } catch (Exception e) {
            LogUtils.warn("Closing the page failed (closing the rest anyway): " + e.getMessage());
        }

        // 2) Resolve source video path (only valid after close)
        Path src = null;
        if (vid != null) {
            try {
                src = vid.path();     // will throw if page wasn't closed successfully
            } catch (Exception e) {
                LogUtils.warn("The scenario video is not available: " + e.getMessage());
            }
        }

        // 3) Close context → browser → Playwright, and clear ThreadLocals
        try {
            if (context.get() != null) context.get().close();
        } catch (Exception e) {
            LogUtils.warn("Closing the browser context failed: " + e.getMessage());
        } finally {
            context.remove();
        }
        try {
            if (browser.get() != null) browser.get().close();
        } catch (Exception e) {
            LogUtils.warn("Closing the browser failed: " + e.getMessage());
        } finally {
            browser.remove();
            page.remove();
        }
        try {
            if (playwright.get() != null) playwright.get().close();
        } catch (Exception e) {
            LogUtils.warn("Closing Playwright failed: " + e.getMessage());
        } finally {
            playwright.remove();
        }

        // 4) If no video recorded, we’re done
        if (src == null) {
            return null;
        }

        // 5) Wait until the file is visible & stable on disk (handles CI/fs lag)
        try {
            waitForFileReady(src, Duration.ofSeconds(60), Duration.ofMillis(300));
        } catch (Exception e) {
            LogUtils.warn("The scenario video was not written: " + e.getMessage());
            return null;
        }

        // 6) Build destination path using scenario UUID and original extension
        try {
            Path targetDir = Paths.get("reports/latest/custom-report/videos");
            Files.createDirectories(targetDir);

            String ext = getExtensionWithDot(src.getFileName().toString()); // like ".webm" / ".mp4" or ""
            Path dest = targetDir.resolve(scenarioUUID + ext);

            Files.move(src, dest, StandardCopyOption.REPLACE_EXISTING);
            return dest;
        } catch (Exception e) {
            LogUtils.warn("Could not move the scenario video to the report: " + e.getMessage());
            return null;
        }
    }

    /** Waits until file exists and its size is stable across two consecutive polls. */
    private static void waitForFileReady(Path path, Duration timeout, Duration pollEvery) throws Exception {
        long deadline = System.nanoTime() + timeout.toNanos();
        long lastSize = -1L;
        int stableReads = 0;

        while (System.nanoTime() < deadline) {
            if (Files.exists(path)) {
                long size = Files.size(path);
                if (size > 0 && size == lastSize) {
                    stableReads++;
                    if (stableReads >= 2) return; // stable twice in a row -> good
                } else {
                    stableReads = 0;
                }
                lastSize = size;
            }
            Thread.sleep(pollEvery.toMillis());
        }
        if (!Files.exists(path)) {
            throw new java.io.IOException("Video not found within timeout: " + path);
        }
    }

    /** Returns extension including dot (".webm") or empty string if none. */
    private static String getExtensionWithDot(String filename) {
        int dot = filename.lastIndexOf('.');
        return (dot >= 0) ? filename.substring(dot) : "";
    }


    // --- Private Helper Methods ---

    private static Browser launchBrowser(Playwright playwright, String browserName, boolean headless) {
        String name = browserName.toLowerCase(java.util.Locale.ROOT).trim();
        switch (name) {
            case "firefox":
                return playwright.firefox().launch(launchOptions(headless, null));
            case "safari":
            case "webkit":
                return playwright.webkit().launch(launchOptions(headless, null));
            default:
                break;
        }
        // Chrome / Edge are the browsers installed on the machine. The other one, then Playwright's own Chromium, is used when the
        // asked one is not installed (Linux build agents, a laptop without Edge), with a warning - not a failed run.
        RuntimeException first = null;
        for (String channel : chromiumChannels(name)) {
            try {
                Browser b = playwright.chromium().launch(launchOptions(headless, channel));
                if (first != null) {
                    LogUtils.warn("-----> " + browserName + " is not installed on this machine; the test runs in "
                            + (channel == null ? "Playwright's Chromium" : channel) + " instead.");
                }
                return b;
            } catch (RuntimeException e) {
                if (!browserMissing(e)) {
                    throw e;
                }
                if (first == null) {
                    first = e;
                }
            }
        }
        throw new IllegalStateException("No browser could be started: " + browserName + " is not installed, and neither is Chrome, Edge or "
                + "Playwright's Chromium (install one, or run 'mvn exec:java -e -Dexec.mainClass=com.microsoft.playwright.CLI "
                + "-Dexec.args=\"install chromium\"' once where internet is allowed).", first);
    }

    /** The Chromium-family browsers to try, in order: the asked one first. null = Playwright's own Chromium. */
    static java.util.List<String> chromiumChannels(String browserName) {
        java.util.List<String> out = new java.util.ArrayList<>();
        switch (browserName == null ? "" : browserName.toLowerCase(java.util.Locale.ROOT).trim()) {
            case "edge":
            case "msedge":
                out.add("msedge");
                out.add("chrome");
                break;
            case "chrome":
                out.add("chrome");
                out.add("msedge");
                break;
            default: // chromium
                out.add(null);
                out.add("chrome");
                out.add("msedge");
                return out;
        }
        out.add(null);
        return out;
    }

    /** True when Playwright could not start the browser because it is not on this machine (not when the browser itself failed). */
    static boolean browserMissing(Throwable e) {
        String m = String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT);
        return m.contains("is not found at") || m.contains("distribution") && m.contains("not found")
                || m.contains("executable doesn't exist") || m.contains("please run the following command to download new browsers")
                || m.contains("looks like playwright was just installed or updated");
    }

    private static BrowserType.LaunchOptions launchOptions(boolean headless, String channel) {
        BrowserType.LaunchOptions o = new BrowserType.LaunchOptions()
                .setHeadless(headless)
                .setArgs(java.util.List.of("--start-maximized"));
        if (channel != null) {
            o.setChannel(channel);
        }
        return o;
    }

    /**
     * Playwright downloads its own browsers (about 400 MB) the first time it starts, which fails or hangs on machines without internet
     * (most client networks). Chrome and Edge are the installed ones, so for them nothing is downloaded. Set
     * PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD yourself (-D or environment) to decide it for every browser.
     */
    static Playwright.CreateOptions createOptions(String browserName) {
        String own = System.getProperty("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", System.getenv("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"));
        String n = browserName == null ? "" : browserName.toLowerCase(java.util.Locale.ROOT).trim();
        boolean installed = n.equals("chrome") || n.equals("edge") || n.equals("msedge");
        java.util.Map<String, String> env = new java.util.HashMap<>();
        if (own != null && !own.isBlank()) {
            env.put("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", own.trim());
        } else if (installed) {
            env.put("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        }
        return new Playwright.CreateOptions().setEnv(env);
    }

    /** False on a machine without a screen (Linux agent without DISPLAY / WAYLAND_DISPLAY, or java.awt.headless=true). */
    static boolean hasDisplay() {
        if (Boolean.getBoolean("java.awt.headless")) {
            return false;
        }
        String os = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT);
        if (os.contains("win") || os.contains("mac")) {
            return true;
        }
        return isSet(System.getenv("DISPLAY")) || isSet(System.getenv("WAYLAND_DISPLAY"));
    }

    private static boolean isSet(String v) {
        return v != null && !v.isBlank();
    }

    private static BrowserContext createBrowserContext(Browser browser, boolean recordVideo) {
        Browser.NewContextOptions contextOptions = new Browser.NewContextOptions()
                .setViewportSize(null) // null for maximized viewport
                .setAcceptDownloads(true)
                // test systems often use self-signed certificates; -DIGNORE_HTTPS_ERRORS=false checks certificates
                .setIgnoreHTTPSErrors(!"false".equalsIgnoreCase(
                        com.mashreq.automation.tcoe.utils.PropertiesHelpers.getValue("IGNORE_HTTPS_ERRORS")));

        if (recordVideo) {
            contextOptions.setRecordVideoDir(Paths.get("reports/latest/videos/"));
            contextOptions.setRecordVideoSize(1280, 720);
        }

        return browser.newContext(contextOptions);
    }
}